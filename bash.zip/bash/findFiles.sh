#!/bin/bash

if [[ $# -lt 1 ]]; then
    echo "Provide a file name to search for"
    exit 1
fi

allArgs=" $@"
specialArgs=''
searchArgs="$allArgs"


if [[ "$searchArgs" =~ ' -w ' ]]; then
    specialArgs="$specialArgs -w"
    searchArgs=`echo "$searchArgs" | sed 's/ -w//'`
fi
if [[ "$searchArgs" =~ ' -i ' ]]; then
    specialArgs="$specialArgs -i"
    searchArgs=`echo "$searchArgs" | sed 's/ -i//'`
fi
if [[ "$searchArgs" =~ ' -v ' ]]; then
    specialArgs="$specialArgs -v"
    searchArgs=`echo "$searchArgs" | sed 's/ -v//'`
fi
if [[ "$searchArgs" =~ ' -F ' ]]; then
    specialArgs="$specialArgs -F"
    searchArgs=`echo "$searchArgs" | sed 's/ -F//'`
fi
if [[ "$searchArgs" =~ ' -L ' ]]; then
    specialArgs="$specialArgs -L"
    searchArgs=`echo "$searchArgs" | sed 's/ -L//'`
fi

searchArgs=`echo "$searchArgs" | sed 's/^ //'`
pathToFile=''

if [[ $searchArgs == /* ]]; then
    echo "TRUE"
    pathToFile=`echo $searchArgs | rev | cut -d'/' -f2- | rev`
    cd $pathToFile
    searchArgs=`echo $searchArgs |  rev | cut -d'/' -f1 | rev`
fi

searchOutput=`find . | grep $specialArgs $searchArgs 2>/dev/null` # | sed 's@./@/@'`

for line in $searchOutput; do
    echo ${pathToFile}${line}
done

