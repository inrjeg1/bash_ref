#!/bin/bash

if [[ $# -lt 1 ]]; then
    echo "Please provide a file name"
    exit 1
fi

currentRepo=`/sdev_shared/fc062data/PTAD/scripts/bash/get_current_repository.sh`
viewName=$(cleartool pwv -short)
fileName=$1

if [[ ($currentRepo == "./") ]]; then
    echo "This script needs to be executed from a Clearcase view or BOA repo"
    exit 1
fi

if [[ $currentRepo != "./" ]]; then
    /sdev_shared/fc062data/PTAD/scripts/bash/getInterfaceForFileBOA.sh $fileName
elif [[ $viewName != "** NONE **" ]]; then
    /sdev_shared/fc062data/PTAD/scripts/bash/getInterfaceForFileClearcase.sh $fileName
fi
