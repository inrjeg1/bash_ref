#!/bin/bash

a="alpha
bravo
charlie"

for word in $a; do
    echo "word: $word"
done

dummyInput=`cat dummy_txt2.txt`
IFS='
'
for line in `echo "$dummyInput"`; do
    echo "line: $line"
done

