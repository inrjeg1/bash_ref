#!/bin/bash

patch_name=""
boa_location=""
user_name="${USER}"

while getopts "h:p:b:u:" opt
do
   case ${opt} in 
      p )
        echo "patch_name"
        patch_name=$OPTARG
        ;;
      b )
        boa_location=$OPTARG
        ;;
      u )
        user_name=$OPTARG
        ;;
      \? )
        echo "Invalid Option: -$OPTARG" 1>&2
        exit 1
        ;;
      h )
        usage
        ;;
   esac
done

shift $((OPTIND -1))

a=""
b=""

location="/exp/s2p/patch/${a}/${b}"

cd $location
echo $PWD
