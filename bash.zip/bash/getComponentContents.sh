#!/bin/bash

if [[ $# -lt 1 ]]; then
    echo "Please provide an component name"
    exit 1
fi

currentDir=$PWD
componentName=$1
cd `xcd $componentName`
cd ../xscm
scopefile=`ls BB-*internal_scope.txt.2`

lineNrTotal=0
lengthComponentScope=0
insideComponent=0
while read line; do
    if [[ $line == "component $componentName" ]]; then
        insideComponent=1
    fi
    if [[ $insideComponent -eq 1 ]]; then
        ((lengthComponentScope++))
        if  [[ $line == "}" ]]; then
            ((lineNrTotal++))
            break
        fi
    fi
    ((lineNrTotal++))
done < <(cat $scopefile)

if [[ ! $lengthComponentScope -eq 0 ]]; then
    cat $scopefile | head -$lineNrTotal | tail -$lengthComponentScope
    cd $currentDir
fi
