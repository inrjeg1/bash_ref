#!/bin/bash

current_dir=`pwd`
current_dir_base=`basename $current_dir`

if [[ (($current_dir_base == "bld") || \
         ($current_dir_base == "bld_x86lnx") || \
         ($current_dir_base == "behave") || \
         ($current_dir_base == "dd_based_python_unit_tests")) ]];then
   echo "`pwd`/../"
elif [[ ($current_dir_base == "features") ]]; then
   echo "`pwd`/../../"
elif [[ ($current_dir_base == "steps") ]]; then
   echo "`pwd`/../../../"   
else
   echo "./"
fi
