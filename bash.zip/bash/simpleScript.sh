#!/bin/bash

occurrence='KVLICOxCSxDMC_data_gen_DdConversionControlEntityIds.hpp:#include "KVLICOxCSxDMCtyp.hpp"'

fileName="KVLICOxCSxDMC_data_gen_DdConversionControlEntityIds.hpp"
oldInclude=`echo $occurrence | cut -d':' -f2`
#oldInclude='#include "KVLICOxCSxDMCtyp.hpp"'
echo $oldInclude

newInclude="#include \"KVLICOxCSxDMC/KVLICOxCSxDMCtyp.hpp\""


sed -i -e "s@${oldInclude}@${newInclude}@" $fileName
