#!/bin/bash

username=`whoami`

if [[ $# -gt 0 ]]; then
    username=$1
fi

cd /shared/nl011022_u/test_data/IURI/ibq/

alldirs=`find . -mindepth 1 -maxdepth 1 -type d -name "${username}*"`

for dir in $alldirs; do
    cd $dir
    findResults=`find . | grep -F '.html' 2>/dev/null  | sed 's@./@@'`
    
    if [[ ! -z $findResults ]]; then
        for result in $findResults; do
            echo "${dir}/${result}"
        done
    fi
    cd ..
done
