#!/bin/bash

depthToComponent=`/sdev_shared/fc062data/PTAD/scripts/bash/findDepth.sh`

pathToPrint=`pwd`
while [[ $depthToComponent > 1 ]]; do
    pathToPrint="${pathToPrint}/.."
    ((depthToComponent--))
done

if [[ $depthToComponent -eq 0 ]]; then
    current_dir=`pwd`
    current_dir_base=`basename $current_dir`

    if [[ (( $current_dir_base == "com" ) || \
        ( $current_dir_base == "xifs" ) || \
        ( $current_dir_base == "xtst" ) || \
        ( $current_dir_base == "doc" )) ]]; then
       echo "`pwd`/.."
    elif [[ (($current_dir_base == "int") || \
             ($current_dir_base == "ext")) ]]; then
       echo "`pwd`/../.. "
    elif [[ (($current_dir_base == "bin") || \
             ($current_dir_base == "dat") || \
             ($current_dir_base == "ddf") || \
             ($current_dir_base == "inc") || \
             ($current_dir_base == "lib") || \
             ($current_dir_base == "tst")) ]];then
       echo "`pwd`/../../.."
    elif [[ (($current_dir_base == "bld") || \
             ($current_dir_base == "bld_x86lnx") || \
             ($current_dir_base == "behave") || \
             ($current_dir_base == "dd_based_python_unit_tests")) ]];then
       echo "`pwd`/../../../.."
    elif [[ ($current_dir_base == "features") ]]; then
       echo "`pwd`/../../../../.."
    elif [[ ($current_dir_base == "steps") ]]; then
       echo "`pwd`/../../../../../.."   
    else
       echo "./"
    fi
else
    echo $pathToPrint
fi


