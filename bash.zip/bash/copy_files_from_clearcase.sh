#!/bin/bash

inputfile="/home/ptacken/public/input_file.txt"
currentPath=$PWD
#otherview="/view/jkrielen_at5.1.0.b_p5043_int/vobs/vb4/metro/KVIFPC/com/"
#otherview="/view/ptacken_lvl_at_qbl_LIL_v08_int/"
otherview="/view/ptacken_lvl_at_qbl_LIL_v1_2_int"


#if [[ `echo $currentPath | rev | cut -d'/' -f1 | rev` != "com" ]]; then
#    echo "Directory should be 'com'"
#fi

#if [[ "$#" -eq 0 ]]; then
#    echo "Filename required as argument"
#    exit 1
#fi

for file in `cat $inputfile`; do
    
    parentDir=`echo $file | rev | cut -d'/' -f2- | rev`
    

    cleartool co -nc $parentDir > /dev/null 2>&1
    if [[ -d ${otherview}${file} ]]; then
        cleartool mkdir -nc $file  2>&1
    elif [[ -f ${otherview}${file} ]]; then
        output="$(cleartool mkelem -nc $file 2>&1)"
        echo $output
    fi
    
    elemBase=`basename ${file}`
    
    if [[ $output =~ "Attempt to create an 'evil twin'" ]]; then
        ctLinkCommand=`echo "$output" | grep "cleartool ln" | grep $elemBase | sed -e "s@^%> @@"`
        hardlinkDestination=`echo $ctLinkCommand | sed 's@cleartool ln @@' | cut -d' ' -f1`
        echo "Hard link destination: $hardlinkDestination"
        
        ctLinkOutput="$(cleartool ln $hardlinkDestination $parentDir 2>&1)"
        echo "$ctLinkOutput"

        if [[ $ctLinkOutput =~ "It is not allowed to create duplicate hardlinks" ]]; then
            linkToBeRemoved=`echo "$ctLinkOutput" | grep "The element" | grep "already available in another location" | sed "s@'@#@g" | cut -d'#' -f2`
            linkRemoveOutput="$(cleartool rmname $linkToBeRemoved)"
            echo "$linkRemoveOutput"
            ctLinkOutput="$(cleartool ln $hardlinkDestination . 2>&1)"
            echo "$ctLinkOutput"
        fi
    fi
        
    if [[ -f $elemBase ]]; then
        echo "Copying file content to new file"
        cleartool co -nc ./${elemBase} > /dev/null 
        cat ${otherview}${file} > $file
    fi
        
done 

