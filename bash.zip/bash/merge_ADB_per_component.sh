#!/bin/bash


ccList=`ccget_buildscope | cut -d'/' -f2`
for component in $ccList; do
    echo -e "\n  ===  Merge files for $component  ===" 
    cd `xcd $component`
    ccmerge -m -nar -s ptacken_lvl_at_qbl_LIL_v07_and_64bit_fixes_int 
    
done
