#!/bin/bash

ticsFile="/home/ptacken/public/tics_180413_removed_boost_and_Eigen"

inErrorCode=0

while IFS='' read -r line || [[ -n "$line" ]]; do 
    
    if [[ "$line" =~ "item 6.8.6.4.d" ]]; then
        inErrorCode=1
    elif [[ ($inErrorCode == 1) && ("$line" =~ "http://netscanner.asml.com/nl011057/nonconf/") ]]; then
        inErrorCode=0
    fi
    
    if [[ $inErrorCode == 1 ]]; then
        echo "$line"
    fi

done < "$ticsFile"
