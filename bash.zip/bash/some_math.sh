#!/bin/bash

function addStuff
{
    echo $(($1 + $2))
}

function increment
{
    number=$1
    ## one way
    ((number++))
    echo $number
    
    ## another way
    let "number++"
    echo $number
}

function playingWithNumbers
{
    a=40
    b=3
    c=5
    
    echo $(($a * $c / $b))

}

function addSpecificNumbers
{
    alpha=8
    
    bravo=$((alpha+2))
    echo $bravo
}

addSpecificNumbers
#addStuff 3 5
#increment 9
#playingWithNumbers


