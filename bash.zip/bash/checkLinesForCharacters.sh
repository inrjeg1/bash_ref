#!/bin/bash

dummyfile='/sdev_shared/fc062data/PTAD/scripts/bash/dummy_txt.txt'

cat $dummyfile | while read -r line; do

    if [[ ($line =~ [A-Za-z]) || ("$line" =~ "\\" ) ]]; then
        echo $line

    fi

done


