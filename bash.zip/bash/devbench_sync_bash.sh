#!/bin/bash

GEM_HOME="$HOME/.gem"
PATH="$HOME/.gem/bin:$PATH"
PYTHONPATH="/boa_proj_build/ptacken/ci/jenkins-tooling/:$PYTHONPATH"

python -c 'from devbench import syncToDevbench; syncToDevbench("$1")'

#/boa_proj_build/asintots/ci/jenkins-tooling/sync_linux_devbench.sh $1

#/sdev_shared/fc062data/PTAD/scripts/bash/custom_sync.sh $1
