#!/bin/bash

if [[ $# -lt 1 ]]; then
    echo "Please give a file name as input"
    exit 1
fi

viewName=$(cleartool pwv -short)
boaRepo=`/sdev_shared/fc062data/PTAD/scripts/bash/get_current_repository.sh`
allComponents=''
inClearcase=0

if [[ $viewName != "** NONE **" ]]; then
    allComponents=`ccget_buildscope 2>/dev/null | cut -d'/' -f2`
    inClearcase=1
elif [[ $boaRepo != "./" ]]; then
    allComponents=`/sdev_shared/fc062data/PTAD/scripts/bash/allComponents.sh`
else
    echo "This script needs to be executed from a Clearcase or BOA environment"
    exit 1
fi

fileName=$1
allComponents=`/sdev_shared/fc062data/PTAD/scripts/bash/allComponents.sh`

function checkFileName()
{
    fileName=$1
    for component in $allComponents; do
        if [[ $fileName == $component ]]; then
            echo $component
            exit 0
        fi
    done
    if [[ ${#fileName} -gt 1 ]]; then
        newFileName=`echo $fileName | rev | cut -c2- | rev`
        checkFileName $newFileName
    fi
}

if [[ "$fileName" == "lib"* ]]; then
    fileName=`echo $fileName | cut -c4-`
fi

fileNameCopy=$fileName
checkFileName $fileName

### Try to find the filename outside the buildscope (Clearcase only)

function goToComponent()
{
    component=$1
    cd `xcd $component`
}

function checkFileNameOutsideBuildscope()
{
    fileName=$1
    
    output="$(goToComponent $fileName 2>&1)"
    if [[ $output != "Abbreviation not found" ]]; then
        echo $fileName
        exit 0
    fi
            
    if [[ ${#fileName} -gt 1 ]]; then
        newFileName=`echo $fileName | rev | cut -c2- | rev`
        checkFileNameOutsideBuildscope $newFileName
    fi
}

if [[ "$fileName" == "lib"* ]]; then
    fileName=`echo $fileName | cut -c4-`
fi

if [[ inClearcase -eq 1 ]]; then
    checkFileNameOutsideBuildscope $fileNameCopy
fi

echo -e "\n === Component for $fileNameCopy not found === \n"
exit 1
