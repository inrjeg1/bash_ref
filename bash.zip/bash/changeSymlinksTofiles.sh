#!/bin/bash

allComponents=`/sdev_shared/fc062data/PTAD/scripts/bash/allComponents.sh`


while read component; do

   echo -e "\n  === Changing symlinks to files in $component === "

   cd `xcd $component com int tst`
   allLinks=`find . -type l -ls | grep -v bld | grep xifs | grep VELIRFxTEST`

    echo "ALL LINKS:" 
    echo "$allLinks"

    echo "======="
    
   while read link; do
    
      if [[ -z $link ]]; then
        break
      fi
      
  
      linkPath=`echo $link | rev | cut -d" " -f1 | rev`
      file=`echo $link | rev | cut -d" " -f3 | rev`
      
      echo "Fixing symlink ${file}..."
      
      currentLocation=`pwd`
      fileLocation=`echo $file | rev | cut -d'/' -f2- | rev`
      echo "LINK: $link"
      echo "FILE: $file"
      fileName=`basename $file`

      cd $fileLocation
      
      echo "fileLoation: $fileLocation"
      echo "file: $file"
      echo "fileName: $fileName"
      
      echo "currentLocation: `pwd`"

      cleartool co -nc .
      cleartool rmname $fileName
      rm -f $fileName
      cp $linkPath .
      output="$(cleartool mkelem -nc $fileName 2>&1)"

      if [[ $output =~ "Attempt to create an 'evil twin'" ]]; then
          ctLinkCommand=`echo "$output" | grep "cleartool ln" | grep $fileName | sed -e "s@^%> @@"`

          hardlinkDestination=`echo $ctLinkCommand | sed 's@cleartool ln @@' | cut -d' ' -f1`
          ctLinkOutput="$(cleartool ln $hardlinkDestination . 2>&1)"
          echo "$ctLinkOutput"

          if [[ $ctLinkOutput =~ "It is not allowed to create duplicate hardlinks" ]]; then
              linkToBeRemoved=`echo "$ctLinkOutput" | grep "The element" | grep "already available in another location" | sed "s@'@#@g" | cut -d'#' -f2`
              linkRemoveOutput="$(cleartool rmname $linkToBeRemoved)"
              echo "$linkRemoveOutput"
              ctLinkOutput="$(cleartool ln $hardlinkDestination . 2>&1)"
              echo "$ctLinkOutput"
          fi
      fi

      cd $currentLocation

      echo
      


   done < <(echo "$allLinks")

done < <(echo "$allComponents")

