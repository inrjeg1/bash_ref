#!/bin/bash

abort()
{
   failed=$?
   
   if [ $failed -ne 0 ]; then
      echo "ERROR"
   fi
   
   exit 0
}


function do_fail
{
   exit 1
}

function do_pass
{
   exit 0
}


trap 'abort' 0

set -e

   do_pass
   do_fail

trap : 0





