#!/bin/bash

inputFile='/home/ptacken/public/conflicts_added'


for file in `cat $inputFile`; do

    output=`/sdev_shared/fc062data/PTAD/scripts/bash/compare_to_boa.sh $file`
    if [[ $output == '' ]]; then
        echo "DIFFERENT!: $file"
        
  #  else
     #   git checkout origin/master $file
    fi
done

