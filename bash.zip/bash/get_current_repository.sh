#!/bin/bash

currentDir=$PWD
boaProjectName="/boa_prd"
viewName=$(cleartool pwv -short)

if [[ $viewName != "** NONE **" ]]; then
    echo "/vobs/litho"
    exit 0
elif [[ $currentDir =~ $boaProjectName ]]; then
    depthDiff=1
    dirToCheck=$currentDir
    while [[ ! -z  $dirToCheck ]]; do
        dirToCheck=`echo $currentDir | rev | cut -d'/' -f${depthDiff}- | rev`
        if [[ -d "${dirToCheck}/.git" ]]; then
            echo $dirToCheck
            exit 0
        fi
        ((depthDiff++))
        
    done
    echo "./"
else
    echo "./"
fi

