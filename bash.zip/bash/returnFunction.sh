#!/bin/bash

function returnSomeNumber()
{
    echo 5
}

returnSomeNumber


