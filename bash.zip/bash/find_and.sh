#!/bin/bash

if [[ $# -lt 2 ]]; then
    echo "Usage: find_and.sh <pattern1> <pattern2>"
    exit 1
fi

allArgs=" $@"
currentPath=`pwd`
inBoa=0
inClearCase=0
specialArgs=''
searchArgs="$allArgs"

if [[ $currentPath =~ 'boa_prd' ]]; then
    inBoa=1

elif [[ $currentPath =~ 'vobs/litho' ]]; then
    inClearCase=1
fi

if [[ "$searchArgs" =~ ' -w ' ]]; then
    specialArgs="$specialArgs -w"
    searchArgs=`echo "$searchArgs" | sed 's/ -w//'`
fi
if [[ "$searchArgs" =~ ' -i ' ]]; then
    specialArgs="$specialArgs -i"
    searchArgs=`echo "$searchArgs" | sed 's/ -i//'`
fi
if [[ "$searchArgs" =~ ' -v ' ]]; then
    specialArgs="$specialArgs -v"
    searchArgs=`echo "$searchArgs" | sed 's/ -v//'`
fi
if [[ "$searchArgs" =~ ' -F ' ]]; then
    specialArgs="$specialArgs -F"
    searchArgs=`echo "$searchArgs" | sed 's/ -F//'`
fi
if [[ "$searchArgs" =~ ' -L ' ]]; then
    specialArgs="$specialArgs -L"
    searchArgs=`echo "$searchArgs" | sed 's/ -L//'`
fi

searchArgs=`echo "$searchArgs" | sed 's/^ //'`
firstSearchArg=`echo $searchArgs | cut -d' ' -f1`
secondSearchArg=`echo $searchArgs | cut -d' ' -f2`

firstOutput=`/sdev_shared/fc062data/PTAD/scripts/bash/find_grep.sh $specialArgs $firstSearchArg`
filesFirstOutput=`echo "$firstOutput" | cut -d" " -f1 | sort | uniq`

for file in $filesFirstOutput; do
    secondOutput=`grep $specialArgs $secondSearchArg $file`
    if [[ ! -z "$secondOutput" ]]; then
        echo $file    
    fi
done

