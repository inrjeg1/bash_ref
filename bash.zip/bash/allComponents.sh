#!/bin/bash

#configFile=`/sdev_shared/fc062data/PTAD/scripts/bash/get_current_repository.sh`/.boa/config.yml

configFile="/boa_prd/ptacken/d/d/d/lil-1/.boa/config.yml"


if [[ ! -e $configFile ]]; then
    exit 0
fi

#configFile="/boa_prd/ptacken/d/d/d/lil-1/.boa/config.yml"

inListToUse=0

cat $configFile | while read line; do

    if [[ $line =~ 'synced_components' ]]; then
        inListToUse=1
    
    elif [[ ( $inListToUse == 1 ) &&  ( $line =~ '- ' ) ]]; then
         echo $line | cut -d' ' -f2
    fi
done
