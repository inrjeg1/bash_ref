#!/bin/bash

if [ $# -lt 1 ]; then
    echo "Give review number as argument"
    exit 1
fi

reviewNumber=$1
changeListFile1="/home/ptacken/Userdata/code_collab/change_list.lst1"
changeListFile2="/home/ptacken/Userdata/code_collab/change_list.lst2"
changeListFile3="/home/ptacken/Userdata/code_collab/change_list.lst3"

cclst_changes -S | grep -v "inc/boost/" | grep -v "Eigen/src/" > $changeListFile1
echo -n "" > $changeListFile2

while IFS='' read -r line || [[ -n "$line" ]]; do

    fileName=`echo $line | cut -d" " -f1`
    if [[ -f $fileName ]]; then
        echo "$line" >> $changeListFile2
    fi
    
done < "$changeListFile1"

cat "$changeListFile2" | xargs cleartool ls -s | sed 's/@@/ /' | awk '{print $0 " " $NF}' | sed 's|/[0-9]*$|/0|' > $changeListFile3
cat "$changeListFile3" | ccollab addversions $reviewNumber
