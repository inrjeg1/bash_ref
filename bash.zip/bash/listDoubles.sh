#!/bin/bash

inputText=$@
sortedInputText=`echo "$inputText" | sort -u`
previousLine="--NONE--"
currentCount=1

while read line; do
    
    if [[ "$line" == "$previousLine" ]]; then
        ((currentCount++))
    else
        if [[ $previousLine != "--NONE--" ]]; then
            if [[ $currentCount -ne 1 ]]; then
                echo -e "$currentCount\t$previousLine"
            fi
            
        fi
        currentCount=1
    fi
    previousLine=$line

done < <(cat $sortedInputText)

if [[ $currentCount -ne 1 ]]; then
    echo -e "$currentCount\t$previousLine"
fi

