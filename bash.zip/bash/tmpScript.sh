#!/bin/bash

allComponents=`ccget_buildscope | cut -d'/' -f2`

for comp in $allComponents; do
    echo "component: $comp"
    
    cd `xcd $comp com int tst`
    allShFiles=`/sdev_shared/fc062data/PTAD/scripts/bash/findFiles.sh "\.sh"`
    ls -lF -rt $allShFiles
    
done



    
