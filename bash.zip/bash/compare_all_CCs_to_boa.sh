#!/bin/bash

filesOnly=0

if [[ $# -gt 0 ]]; then
    if [[ $1 == 'h' ]]; then
        echo "Usage: $0 [optional: f]"
        exit 0
    elif [[ $1 == 'f' ]]; then
        filesOnly=1
    fi
fi


for cc in `/sdev_shared/fc062data/PTAD/scripts/bash/allComponents.sh`; do
    
    echo "============ $cc ============"
    cd `xcd $cc com`

    if [[ $filesOnly == 0 ]]; then
        /sdev_shared/fc062data/PTAD/scripts/bash/compare_to_boa.sh 20
    else
        /sdev_shared/fc062data/PTAD/scripts/bash/compare_to_boa.sh 20 | egrep -e '(============)|(FILENAME)' | grep -v '============='
    fi

done


