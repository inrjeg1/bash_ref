#!/bin/bash

cpp_found=0


function findFilesThatIncludeThisOne {
    included_file=$1
    relative_path=$2

    #declare file_list=$(/sdev_shared/fc062data/PTAD/scripts/tcsh/find_grep $included_file | grep include | cut -d" " -f1 | sort | uniq) 
    
    
    # Much faster:
    #declare file_list=$(git grep $included_file | grep include | sed "s/:/  /" | cut -d" " -f1 | sort | uniq)
    declare file_list=$(/sdev_shared/fc062data/PTAD/scripts/bash/find_grep.sh $included_file | grep include | sed "s/:/  /" | cut -d" " -f1 | sort | uniq)
    
    
    for file in $file_list; do
       if [[ ( `echo $file | rev | cut -c-4 | rev` ==  ".cpp" ) && ( $cpp_found == 0 ) ]]; then
          #cpp_found=1
          echo ${relative_path}/${file}
       fi
    done
    
    if [[ $cpp_found == 0 ]]; then
        for file in $file_list; do
           if [[ (`echo $file | rev | cut -c-4 | rev` ==  ".hpp" ) && ( $cpp_found == 0 ) ]]; then
              file_name=`echo $file | rev | cut -d/ -f1 | rev`
              findFilesThatIncludeThisOne $file_name $relative_path
           fi
        done
    fi
}


if [ $# -lt 1 ]; then
    echo "Header file expected as argument"
fi

header_file=`echo $1 | rev | cut -d'/' -f1 | rev`
current_path=`pwd`
current_dir=`echo $current_path | rev | cut -d'/' -f1 | rev`
above_dir=`echo $current_path | rev | cut -d'/' -f2 | rev`
relative_path='.'

if [ $above_dir == "int" ] || [ $current_dir == "ext" ]; then
   cd ..
   relative_path='..'
elif [ $above_dir == "ext" ]; then
   cd ../..
   relative_path='../..'
fi

findFilesThatIncludeThisOne $header_file $relative_path

