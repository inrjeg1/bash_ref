#!/bin/bash

if [[ $1 =~ ^[0-9]+$ ]]; then
    number=$1
    if [[ $number -gt 100 ]]; then
        ls -lF -rt | grep $number
    else
        ls -lF -rt | tail -${number}
    fi
elif [[ $# > 0 ]]; then
    searchString=$1
    ls -lF -rt | grep $searchString
else
    ls -lF -rt | tail
fi
