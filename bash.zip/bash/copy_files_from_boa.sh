#!/bin/bash

boaDir="/boa_prd/ptacken/lil-development"
#boaDir="/boa_prd/ptacken/lil-development-2"
#boaDir="/boa_prd/ptacken/lil-development-3"
#boaDir="/boa_prd/ptacken/lil-development-SP08"
#boaDir="/boa_prd/ptacken/ifpc-development-sync"

currentDir=`pwd`
currentDirBase=`basename $currentDir`
dirDepth=`/sdev_shared/fc062data/PTAD/scripts/bash/findDepth.sh`
componentName=`echo $currentDir | rev | cut -d'/' -f${dirDepth} | rev`
pathToDir=`echo $currentDir | rev | cut -d'/' -f-${dirDepth} | rev`
tmpDir="/home/ptacken/public/"
allFilesBOA=`find ${boaDir}/${pathToDir}/ -maxdepth 10 -mindepth 1 | grep -v gitignore | grep -v '/bld' | grep -v '/bld_x86lnx' | grep -v Makefile | grep -v targets.mk | grep -v xifs_ | grep -v '\.pyc' | grep -v 'KVLICOconverters.zip' | grep -v '.valgrindrc'`


function createElement
{
    elemName=$1
    elemType=$2
    
    pathToNewElem=`echo "./${elemName}" | rev | cut -d'/' -f2- | rev`
    
    elemBase=`basename ${elemName}`

    cleartool co -nc ${pathToNewElem} > /dev/null 2>&1
    
    cd $pathToNewElem
    
    if [[ $elemType == "dir" ]]; then
        output="$(cleartool mkdir -nc $elemBase 2>&1)"
        #echo $output
        
    elif [[ $elemType == "file" ]]; then
        if [[ $elemBase == "makefile" ]]; then
            output="$(cccreate_makefile 2>&1)"
            #echo $output
        else
            output="$(cleartool mkelem -nc $elemBase 2>&1)"
            #echo $output
        fi
    elif [[ $elemType == "link" ]]; then
        linkDestination=`ls -lF ${boaDir}/${pathToDir}/${elemName} | cut -d'>' -f2`
        output="$(cleartool ln -s $linkDestination $elemBase 2>&1)"
        #echo "$output"
    else
        output="=== Unknown element type ==="
        exit 1
    fi
    echo "$output"

    if [[ $output =~ "Attempt to create an 'evil twin'" ]]; then
        ctLinkCommand=`echo "$output" | grep "cleartool ln" | grep $elemBase | sed -e "s@^%> @@"`

        hardlinkDestination=`echo $ctLinkCommand | sed 's@cleartool ln @@' | cut -d' ' -f1`
        ctLinkOutput="$(cleartool ln $hardlinkDestination . 2>&1)"
        echo "$ctLinkOutput"

        if [[ $ctLinkOutput =~ "It is not allowed to create duplicate hardlinks" ]]; then
            linkToBeRemoved=`echo "$ctLinkOutput" | grep "The element" | grep "already available in another location" | sed "s@'@#@g" | cut -d'#' -f2`
            linkRemoveOutput="$(cleartool rmname $linkToBeRemoved)"
            echo "$linkRemoveOutput"
            ctLinkOutput="$(cleartool ln $hardlinkDestination . 2>&1)"
            echo "$ctLinkOutput"
        fi
    fi
      
    if [[ (( $elemType == "file" ) && \
           ( -f $elemBase )) ]]; then
        echo "Copying BOA content to new file"
        cleartool co -nc ./${elemBase} > /dev/null 
        cat ${boaDir}/${pathToDir}/${elemName} > ./${elemBase}
    fi

    cd $currentDir
}


IFS=''
while read elementName; do

    newElemName=`echo ${elementName} | sed "s@${boaDir}/${pathToDir}/@@"`

    if [[ ! (( -e  ${newElemName} ) ||
            ( -L  ${newElemName} )) ]]; then

        if [[ -d ${elementName} ]]; then
            echo "Creating directory $newElemName"
            createElement ${newElemName} "dir"
        #elif [[ -L ${elementName} ]]; then
#            echo "Creating link $newElemName"
#            createElement ${newElemName} "link"
        elif [[ (-f ${elementName} ) || (-L ${elementName}) ]]; then
            echo "Creating file $newElemName"
            createElement ${newElemName} "file"
        fi
    fi
    
done < <(echo $allFilesBOA)

