#!/bin/bash

set -e   # abort on error

for filename in ./*; do

   echo "$filename" 
   a=false
   
   if "$a"; then
      echo "true"
   fi

done

