#!/bin/bash

if [[ $# -lt 1 ]]; then
    echo "Please provide an input file with check_libref issues"
    exit 1
fi

viewName=$(cleartool pwv -short)

if [[ $viewName == "** NONE **" ]]; then
    echo "This script needs to be executed from a Clearcase view"
    exit 1
fi

currentActivity=`cleartool lsact -cact`

if [[ -z $currentActivity ]]; then
    echo "Please create a Work Instruction"
    exit 1
fi

allScopefiles=`/sdev_shared/fc062data/PTAD/scripts/bash/getAllScopefilesInBuildscope.sh | grep -v test_scope`
allCheckouts=`cleartool lsco -avobs -cview -s`

function getScopefileContainingLine()
{
    line=$1
    for scopefile in $allScopefiles; do
        grepOutput=`grep -n $line $scopefile`
        if [[ ! -z $grepOutput ]]; then
            echo $scopefile
            return
        fi
    done
}

function getScopefileContainingComponent()
{
    component=$1
    getScopefileContainingLine "component $component"
}

function getScopefileContainingInterface()
{
    interface=$1
    getScopefileContainingLine "interface $interface"
}

function checkoutFile()
{
    fileName=$1
    fileNameWithoutPath=`echo $fileName | rev | cut -d'/' -f1 | rev`
    if [[ ! $allCheckouts =~ $fileNameWithoutPath ]]; then
        cleartool co -nc $fileName
        allCheckouts="${allCheckouts}$fileName"
    fi
}

function addRequiredInterfaceToInterface()
{
    interfaceOfFileToCheck=$1
    interfaceOfNotFoundFile=$2 
    scopefile=$3
    
    lineOfInterfaceOfFileToCheck=`grep -n -w "interface $interfaceOfFileToCheck" $scopefile | cut -d':' -f1`
    lineNrToInsertTo=$((lineOfInterfaceOfFileToCheck+2))
    checkoutFile $scopefile
    
    echo -e "--> Adding interface $interfaceOfNotFoundFile to interface $interfaceOfFileToCheck\n"
    sed -i "${lineNrToInsertTo}i   requires   $interfaceOfNotFoundFile" $scopefile
}

function addRequiredInterfaceToComponent()
{
    componentOfFileToCheck=$1
    interfaceOfNotFoundFile=$2 
    scopefile=$3

    lineOfComponentOfFileToCheck=`grep -n "component $componentOfFileToCheck" $scopefile | cut -d':' -f1`
    lineNrToInsertTo=$((lineOfComponentOfFileToCheck+2))

    checkoutFile $scopefile
    
    echo -e "--> Adding interface $interfaceOfNotFoundFile to component $componentOfFileToCheck\n"
    sed -i "${lineNrToInsertTo}i   requires   $interfaceOfNotFoundFile" $scopefile
}

#function moveInterfaceToExternalIfNeeded()
#{  
#    scopefileOfFileToCheck=$1
#    interfaceOfNotFoundFile=$2
#
#    scopefileNotFoundFile=`getScopefileContainingInterface $interfaceOfNotFoundFile`
#    
#    if [[ -z $scopefileNotFoundFile ]]; then
#        echo "Unable to find scopefile for interface $interfaceOfNotFoundFile"
#        return
#    fi
#    
#    if [[ $scopefileNotFoundFile =~ "_internal_scope.txt.2" ]]; then
#    
#        if [[ $scopefileOfFileToCheck != $scopefileNotFoundFile ]]; then
#        
#            echo -e "--> Moving interface $interfaceOfNotFoundFile from internal to external scope"
#            
#            interfaceContents=`/sdev_shared/fc062data/PTAD/scripts/bash/getInterfaceContents.sh $interfaceOfNotFoundFile`
#
#            externalScopefile=`echo $scopefileNotFoundFile | sed 's/internal/external/'`
#
#            if [[ ! -f $externalScopefile ]]; then
#                echo "Unable to find external scopefile '$externalScopefile' that matches internal scopefile $scopefileNotFoundFile"
#            else
#            
#                # Remove the contents from the internal scopefile
#                echo "   --> Removing interface $interfaceOfNotFoundFile from $scopefileNotFoundFile"
#                checkoutFile $scopefileNotFoundFile
#
#                interfaceContentsSpecial=`echo "$interfaceContents"` #| sed 's@/@\\\/@g'`
#              #  sed -i "/${interfaceContentsSpecial}/d" $scopefileNotFoundFile
#                sed -i 's@$interfaceContentsSpecial@@' $scopefileNotFoundFile
#                
#                # Add the contents to the external scopefile
#
#                echo -e "   --> Adding interface $interfaceOfNotFoundFile to $externalScopefile\n"
#                
#                lineNrOfClosingBracket=`ls | grep -n '}' $externalScopefile | head -1 | cut -d':' -f1`
#                lineNrToInsertTo=$((lineNrOfClosingBracket+1))
#                
#                checkoutFile $externalScopefile
#                
#              #  sed -i "${lineNrToInsertTo}i ${interfaceContentsSpecial}" $externalScopefile
#            fi
#        fi
#    fi
#}


inputFile=$1
componentName=''
fileToCheck=''
scopefilesChanged=0

IFS='
'
for line in `cat $inputFile`; do
    if [[ $line =~ "check_libref:ERRORS" ]]; then
        componentName=`echo $line | rev | cut -d'/' -f2 | rev`
    fi
    
    if [[ $line =~ "Checking 'bld" ]]; then
        fileToCheck=`echo $line | cut -d'/' -f2 | cut -d"'" -f1`
    fi
    if [[ $line =~ "WARNING: Not found:" ]]; then
        notFoundFile=`echo $line | cut -d"'" -f2`
        interfaceOfFileToCheck=`/sdev_shared/fc062data/PTAD/scripts/bash/getInterfaceForFileClearcase.sh $fileToCheck`
        interfaceOfNotFoundFile=`/sdev_shared/fc062data/PTAD/scripts/bash/getInterfaceForFileClearcase.sh $notFoundFile`
        
        if [[ -z $interfaceOfNotFoundFile ]]; then
            echo "unable to find the interface for file $notFoundFile"
        else
            if [[ ! -z $interfaceOfFileToCheck ]]; then
                echo "Interface $interfaceOfFileToCheck needs $interfaceOfNotFoundFile"
                
                scopefileOfFileToCheck=`getScopefileContainingInterface $interfaceOfFileToCheck`
                if [[ ! -z  $scopefileOfFileToCheck ]]; then
                    interfaceContents=`/sdev_shared/fc062data/PTAD/scripts/bash/getInterfaceContents.sh $interfaceOfFileToCheck`
                    if [[ ! "$interfaceContents" =~ $interfaceOfNotFoundFile ]]; then
                        addRequiredInterfaceToInterface $interfaceOfFileToCheck $interfaceOfNotFoundFile $scopefileOfFileToCheck
                        scopefilesChanged=1
                    else
                        echo -e "--> Interface $interfaceOfFileToCheck already contains interface $interfaceOfNotFoundFile\n"
                    fi
                fi
            else
                componentOfFileToCheck=`/sdev_shared/fc062data/PTAD/scripts/bash/getComponent.sh $fileToCheck`
                if [[ -z $componentOfFileToCheck ]]; then
                    echo "Unable to find the component for file $fileToCheck"
                else
                    echo "Component $componentOfFileToCheck needs $interfaceOfNotFoundFile"

                    scopefileOfFileToCheck=`getScopefileContainingComponent $componentOfFileToCheck`
                    if [[ -z $scopefileOfFileToCheck ]]; then
                        echo "Unable to find scopefile for component $componentOfFileToCheck"
                        continue
                    fi
                    componentContents=`/sdev_shared/fc062data/PTAD/scripts/bash/getComponentContents.sh $componentOfFileToCheck`
                    if [[ ! "$componentContents" =~ $interfaceOfNotFoundFile ]]; then
                        addRequiredInterfaceToComponent $componentOfFileToCheck $interfaceOfNotFoundFile $scopefileOfFileToCheck
                        scopefilesChanged=1
                    else
                        echo -e "--> Component $componentOfFileToCheck already contains interface $interfaceOfNotFoundFile\n"
                    fi
                fi
            fi

           # if [[ ! -z $scopefileOfFileToCheck ]]; then
                #moveInterfaceToExternalIfNeeded $scopefileOfFileToCheck $interfaceOfNotFoundFile
           # fi
        fi
    fi    
done

if [[ $scopefilesChanged -eq 1 ]]; then
    echo -e "\n--> Running ccrscope -p"
    ccrscope -p

    echo -e "\n--> Running ccupdate_scope -a"
    ccupdate_scope -a

    echo -e "\n--> Running ccmake interfaces"
    ccmake interfaces

    echo -e "\n--> Done!"
else
    echo "No scopefiles have been changed"
fi
