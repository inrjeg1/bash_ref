#!/bin/bash

viewName=$(cleartool pwv -short)

if [[ $viewName == "** NONE **" ]]; then
    echo "This script needs to be run from a Clearcase view"
    exit 1
fi

newScopefilesPath="/tmp/LIL_scope/"

for scopefile in `cat /tmp/LIL_scopefiles_full_path.lst`; do

    scopeFileWithoutPath=`echo $scopefile | rev | cut -d'/' -f1 | cut -d'.' -f2- | rev`
    newScopefileWithPath="${newScopefilesPath}${scopeFileWithoutPath}"
    
    bcompare $scopefile $newScopefileWithPath
    
done

