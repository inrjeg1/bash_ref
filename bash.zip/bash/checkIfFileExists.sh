#!/bin/bash


function checkIfFileExists()
{
    full_path=$1
    search_word=`basename $1`

    searchResult=`find . | grep $search_word`

    if [[ -z $searchResult ]]; then
        echo "   === NOT FOUND: $full_path ==="
        NotExistingFilesFound=1
    fi
}

