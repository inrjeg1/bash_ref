#!/bin/bash

viewName=$(cleartool pwv -short)

if [[ $viewName == "** NONE **" ]]; then
    echo "This script needs to be run from a Clearcase view"
    exit 1
fi

startTimeSeconds=`date +%s`
startTimeNanoSeconds=`date +%N | cut -c-1`

nrOfFilesFirstCheck=`cleartool lsco -avobs -cview -s | wc -l`

if [[ $nrOfFilesFirstCheck -eq 0 ]]; then
    echo "=== No files are checked out, exiting now ==="
    exit 1
fi

secondTimeSeconds=`date +%s`
secondTimeNanoSeconds=`date +%N | cut -c-1`

diffSeconds=$(($secondTimeSeconds - $startTimeSeconds))

if [[ $diffSeconds -gt 5 ]]; then
    diffNano=$(($secondTimeNanoSeconds - $startTimeNanoSeconds))

    if [[ $diffNano -lt 0 ]]; then
        diffNano=$(($diffNano + 10))
        diffSeconds=$(($diffSeconds - 1))
    fi
    while [[ $diffNano -gt 1 ]]; do
        sleep 0.05
        secondTimeSeconds=`date +%s`
        secondTimeNanoSeconds=`date +%N | cut -c-1`
        diffSeconds=$(($secondTimeSeconds - $startTimeSeconds))
        diffNano=$(($secondTimeNanoSeconds - $startTimeNanoSeconds))
        if [[ $diffNano -lt 0 ]]; then
            diffNano=$(($diffNano + 10))
            diffSeconds=$(($diffSeconds - 1))
        fi        
    done
else
    while [[ ! $diffSeconds -gt 5 ]]; do
        sleep 0.1
        secondTimeSeconds=`date +%s`
        secondTimeNanoSeconds=`date +%N | cut -c-1`
        diffSeconds=$(($secondTimeSeconds - $startTimeSeconds))
        diffNano=$(($secondTimeNanoSeconds - $startTimeNanoSeconds))
        if [[ $diffNano -lt 0 ]]; then
            diffNano=$(($diffNano + 10))
            diffSeconds=$(($diffSeconds - 1))
        fi
    done
fi

nrOfFilesSecondCheck=`cleartool lsco -avobs -cview -s | wc -l`

if [[ $nrOfFilesSecondCheck -eq 0 ]]; then
    echo "=== No files are checked out anymore, exiting now ==="
    exit 1
fi

diffBetweenChecks=$(($nrOfFilesFirstCheck - $nrOfFilesSecondCheck))

if [[ $diffBetweenChecks  -lt 1 ]]; then
    echo "=== Checking in does not seem to be in progress... ==="
    exit 1
fi

totalNrOfSecondsRemaining=$(($nrOfFilesSecondCheck * $diffSeconds / $diffBetweenChecks))
nrHours=$(($totalNrOfSecondsRemaining / 3600))
totalNrOfSecondsRemaining=$(($totalNrOfSecondsRemaining % 3600))
nrMinutes=$(($totalNrOfSecondsRemaining / 60))
totalNrOfSecondsRemaining=$(($totalNrOfSecondsRemaining % 60))

nrSeconds=$totalNrOfSecondsRemaining

if [[ $nrHours -gt 0 ]]; then
    echo -n "$nrHours hour(s), $nrMinutes minute(s), "
elif [[ $nrMinutes -gt 0 ]]; then
    echo -n "$nrMinutes minute(s), "
fi
echo "$nrSeconds second(s) remaining"
