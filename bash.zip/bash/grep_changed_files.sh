#!/bin/bash

bigFile="/home/ptacken/Userdata/code_collab/change_list2.lst"
echo -n "" > "filteredFile.txt"


while IFS='' read -r line || [[ -n "$line" ]]; do

    fileName=`echo $line | cut -d" " -f1`
    if [[ ($fileName =~ "makefile") || ($fileName =~ ".") ]]; then

        if grep -q $fileName "/home/ptacken/Userdata/code_collab/files_only" ; then
            if ! grep -q $fileName "filteredFile.txt"; then
               echo "$line" >> "filteredFile.txt"
            fi
        fi
    fi
    
done < "$bigFile"
    
    
