#!/bin/bash

function printHello() {
    echo "Hello"
}
