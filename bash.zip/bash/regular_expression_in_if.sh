#!/bin/bash

while read line; do

if [[ $line =~  "bc"$ ]]; then
	echo $line
fi



done <`echo dummy_txt.txt`

