#!/bin/bash

if [[ $# -lt 1 ]]; then
    echo "Please provide an interface name"
    exit 1
fi

viewName=$(cleartool pwv -short)
if [[ "$viewName" == "** NONE **" ]]; then
    echo "This script needs to be executed from a Clearcase view"
    exit 1
fi

interfaceName=$1
allScopefiles=`/sdev_shared/fc062data/PTAD/scripts/bash/getAllScopefilesInBuildscope.sh`

if [[ $# -eq 2 ]]; then
    allScopefiles=$2
fi

for scopefile in $allScopefiles; do
    lineNrTotal=0
    lengthInterfaceScope=0
    insideInterface=0
    while read line; do
        if [[ $line == "interface $interfaceName" ]]; then
            insideInterface=1
        fi
        if [[ $insideInterface -eq 1 ]]; then
            ((lengthInterfaceScope++))
            if  [[ $line == "}" ]]; then
                ((lineNrTotal++))
                break
            fi
        fi
        ((lineNrTotal++))
    done < <(cat $scopefile)
    if [[ ! $lengthInterfaceScope -eq 0 ]]; then
        cat $scopefile | head -$lineNrTotal | tail -$lengthInterfaceScope
        break
    fi
done
