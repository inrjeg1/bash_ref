#!/bin/bash

pythonFuncToExecute=$1

firstPart=`echo $pythonFuncToExecute | cut -d'.' -f1`
secondPart=`echo $pythonFuncToExecute | cut -d'.' -f2- | cut -d' ' -f1`

if [[ $# -gt 1 ]]; then
    arguments='"'`echo "${@:2}"`'"'
else
    arguments=''
fi

python -c "import ${firstPart}; print ${firstPart}.${secondPart}( ${arguments} )"
