#!/bin/bash

if [[ "$viewName" == "** NONE **" ]]; then
    echo "Not in a Clearcase view, exiting now"
    exit 1
fi

bbList=''
ccList=`ccget_buildscope 2>/dev/null | cut -d'/' -f2`

for component in $ccList; do
    
    cd `xcd $component .. xscm`
    currentDir=$PWD
    if [[ ! $bbList =~ $currentDir ]]; then
        echo BB-*ternal_scope.txt.2 BB-*_test_scope.txt.2 | tr ' ' '\n' | sed -e "s@^@${currentDir}/@"
        bbList="${currentDir}${bbList}"
    fi
done
