#!/bin/bash

ticsFile="/home/ptacken/public/tics_9547_180508/tics.log"

inEigen=0

while IFS='' read -r line || [[ -n "$line" ]]; do 
    
    if [[ ("$line" =~ "Analyzing") && (("$line" =~ "/inc/Eigen/src/") || ("$line" =~ "boost_python")) ]]; then
        inEigen=1
    elif [[ ($inEigen == 1) && ("$line" =~ "end analysis") ]]; then
        inEigen=0   
    elif [[ $inEigen == 0 ]]; then
        echo "$line"
    fi

done < "$ticsFile"
