#!/bin/bash

cat /sdev_shared/fc062data/PTAD/data/file1 | sort > /sdev_shared/fc062data/PTAD/data/file1_sorted
cat /sdev_shared/fc062data/PTAD/data/file2 | sort > /sdev_shared/fc062data/PTAD/data/file2_sorted

kdiff3 /sdev_shared/fc062data/PTAD/data/file1_sorted /sdev_shared/fc062data/PTAD/data/file2_sorted &
