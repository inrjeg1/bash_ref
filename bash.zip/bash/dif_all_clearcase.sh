#!/bin/bash

allCheckedOutFiles=`cleartool lsco -avobs -cview -s`

for checkedOutfile in $allCheckedOutFiles; do
    /sdev_shared/fc062data/PTAD/scripts/bash/dif_clearcase.sh $checkedOutfile
done
