#!/bin/bash

currentDir=`pwd`
#otherCCDir="/view/ptacken_lvl_at_qbl_LIL_v08_int"
#otherCCDir="/view/ptacken_lvl_at_qbl_LIL_v08b_int"
#otherCCDir="/view/ptacken_lvl_at_qbl_LIL_v08b"
#otherCCDir="/view/ptacken_at6.3.0.b_p9356_int"
#otherCCDir="/view/gsmeets_lvl_at_qbl_LIL_v08_int"
#otherCCDir="/view/ptacken_lvl_at_qbl_LIL_v08"
#otherCCDir="/view/ptacken_at5.1.0.b_p5043_int"
#otherCCDir="/view/scifuent_at5.1.0.b_p5043_int"
#otherCCDir="/view/jkrielen_lvl_at_qbl_LIL_v08_int"
#otherCCDir="/view/ptacken_at6.3.0.b_p9356_int"
#otherCCDir="/view/pub_at5.1_int"
#otherCCDir="/view/bescholt_at_qbl_LIL_TPT_gov_int"
#otherCCDir="/view/ptacken_lvl_at_qbl_LIL_v1_2_int"
#otherCCDir="/view/ptacken_lvl_at_qbl_LIL_v1_2b_int"
#otherCCDir="/view/xcao_lvl_at_qbl_IFPC_diagnostics_li"
otherCCDir="/view/gsmeets_lvl_at_qbl_LIL_v1_2_int"


searchDepth=1
do_copy=0

if [[ "$#" -gt 0 ]]; then
    
    if [[ "$@" =~ "DO_COPY" ]]; then
        do_copy=1
    fi
    anyNumber='^[0-9]+$'
    if [[ $1 =~ $anyNumber ]]; then
        searchDepth=$1
    else
        fileName=$1
        #if [[ -e $fileName ]]; then
            if [[ $do_copy == 1 ]]; then
                echo -n "Copying changes from ${otherCCDir}/${currentDir}/${fileName} ..."
                cleartool co -nc ./${fileName} > /dev/null 2>&1
                cat ${otherCCDir}/${currentDir}/${fileName} > ./${fileName}
                cleartool ci -nc ./${fileName} > /dev/null 2>&1
                echo "done!"
            else
                fileNotFound=0
                if [[ ! -e ${otherCCDir}/${currentDir}/${fileName} ]]; then
                    echo "ERROR: File not found: ${otherCCDir}/${currentDir}/${fileName}"
                    fileNotFound=1
                fi
                if [[ ! -e ${fileName} ]]; then
                    echo "ERROR: File not found:  ${fileName}"
                    fileNotFound=1
                fi
                if [[ $fileNotFound -eq 1 ]]; then
                    exit 1
                fi
                
                diffOutput=`diff ${otherCCDir}/${currentDir}/${fileName} ${fileName}`
                if [[ ! -z $diffOutput ]]; then
                    #kdiff3 ${otherCCDir}/${currentDir}/${fileName} ${fileName}
                    bcompare ${otherCCDir}/${currentDir}/${fileName} ${fileName}
                else
                    echo "  === File $fileName is equal to $otherCCDir ==="
                fi
            fi
            exit 0
        #elif [[ $do_copy == 0 ]]; then
#            echo "=== Invalid argument ==="
#            exit 1
#        fi
        
    fi
fi


#allFilesOtherCC=`find ${otherCCDir}/${currentDir}/ -maxdepth $searchDepth | grep -v '/bld' | grep -v '/bld_x86lnx' | grep -v '\.contrib' | grep -v '\.cmake.state'`
#allFilesCurrentCC=`find . -maxdepth $searchDepth | grep -v '/bld' | grep -v '/bld_x86lnx' | grep -v '\.contrib' | grep -v '\.cmake.state'`

allFilesOtherCC=`find -L ${otherCCDir}/${currentDir}/ -maxdepth $searchDepth`
allFilesCurrentCC=`find -L . -maxdepth $searchDepth`


## CHECK FOR DIFFS BETWEEN CURRENT CLEARCASE AND OTHER CLEARCASE PER FILE

diffsPerFileLinePrinted=0

function printDiffsPerFileLine()
{
    echo "============================================"
    echo "=              DIFFS PER FILE              ="
    echo "============================================"
    diffsPerFileLinePrinted=1
}

filesNotPresentInCurrentCC=""
filesNotPresentInOtherCC=""

IFS=''
while read fileName; do

    if [[ $fileName =~ "genmakefile" ]]; then
        echo -n ''
        #do nothing

    elif [[ -e ${otherCCDir}/${currentDir}/${fileName} || \
            -L ${otherCCDir}/${currentDir}/${fileName} ]]; then
        
        echo -n ''

        ##check if file is a file (iso e.g. a link)
        if [[ -L ${otherCCDir}/${currentDir}/${fileName} ]]; then
            
            if [[ ! -L ${fileName} ]]; then
                filesNotPresentInCurrentCC=`echo -e "${filesNotPresentInCurrentCC}\n== ${fileName} is a link in the other CC view! =="`
            fi
        fi

        if [[ -f ${otherCCDir}/${currentDir}/${fileName} ]]; then  

            diffOutput=`diff --strip-trailing-cr ./${fileName} ${otherCCDir}/${currentDir}/${fileName}`

            if [[ ! -z $diffOutput ]]; then
                if [[ $diffsPerFileLinePrinted -eq 0 ]]; then
                    printDiffsPerFileLine
                fi
            
                echo -e "\n=== FILENAME: ${fileName} ==="
                
                if [[ $do_copy == 1 ]]; then
                    echo -n "Copying changes from ${otherCCDir}/${currentDir}/${fileName} ..."
                    cleartool co -nc ./${fileName} > /dev/null 2>&1
                    cat ${otherCCDir}/${currentDir}/${fileName} > ./${fileName}
                    cleartool ci -nc ./${fileName} > /dev/null 2>&1
                    echo "done!"
                else
                    echo "$diffOutput"
                    echo -e "=========================================\n"
                fi
            fi
        fi
    else
        filesNotPresentInOtherCC=`echo -e "${filesNotPresentInOtherCC}\n${fileName}"`
    fi
done < <(echo $allFilesCurrentCC)


## SHOW FILES PRESENT IN CLEARCASE BUT NOT IN BOA

if [[ ! -z $filesNotPresentInOtherCC ]]; then
    echo "============================================"
    echo "=         FILES NOT PRESENT IN OTHER CC    ="
    echo "============================================"
    
    echo -e "$filesNotPresentInOtherCC\n"
fi


## CHECK FOR FILES MISSING IN CLEARCASE

IFS=''
while read fileName; do

    newFileName=`echo ${fileName} | sed "s@${otherCCDir}/${currentDir}@.@"`
    
    if [[ ! (( -e  ${newFileName} ) ||
            ( -L  ${newFileName} )) ]]; then
               
        filesNotPresentInCurrentCC=`echo -e "${filesNotPresentInCurrentCC}\n${newFileName}"`
        
        if [[ -d ${fileName} ]]; then
            filesNotPresentInCurrentCC="${filesNotPresentInCurrentCC}/"
        fi
        
        
    fi
done < <(echo $allFilesOtherCC)


if  [[ ! -z $filesNotPresentInCurrentCC ]]; then
    echo "============================================"
    echo "=      FILES NOT PRESENT IN THIS CC       ="
    echo "============================================"
    
    echo -e "$filesNotPresentInCurrentCC\n"
fi

