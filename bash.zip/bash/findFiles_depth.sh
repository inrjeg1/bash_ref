#!/bin/bash

if [[ $# -lt 2 || $1 == '-h' ]]; then
    echo "Usage: $0 <depth> [options] <pattern>"
    exit 1
fi

allArgs=" $@"
specialArgs=''
searchArgs="$allArgs"


if [[ "$searchArgs" =~ ' -w ' ]]; then
    specialArgs="$specialArgs -w"
    searchArgs=`echo "$searchArgs" | sed 's/ -w//'`
fi
if [[ "$searchArgs" =~ ' -i ' ]]; then
    specialArgs="$specialArgs -i"
    searchArgs=`echo "$searchArgs" | sed 's/ -i//'`
fi
if [[ "$searchArgs" =~ ' -v ' ]]; then
    specialArgs="$specialArgs -v"
    searchArgs=`echo "$searchArgs" | sed 's/ -v//'`
fi
if [[ "$searchArgs" =~ ' -F ' ]]; then
    specialArgs="$specialArgs -F"
    searchArgs=`echo "$searchArgs" | sed 's/ -F//'`
fi
if [[ "$searchArgs" =~ ' -L ' ]]; then
    specialArgs="$specialArgs -L"
    searchArgs=`echo "$searchArgs" | sed 's/ -L//'`
fi

searchArgs=`echo "$searchArgs" | sed 's/^ //'`
depth=`echo $searchArgs | cut -d' ' -f1`
searchArgs=`echo "$searchArgs" | cut -d' ' -f2-`
pathToFile=''

searchOutput=`find . -maxdepth $depth | grep $specialArgs $searchArgs 2>/dev/null` # | sed 's@./@/@'`

for line in $searchOutput; do
    echo ${pathToFile}${line}
done

