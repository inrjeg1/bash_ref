#!/bin/bash

maxDepth=1

if [[ $# -gt 0 ]]; then
    maxDepth=$1
fi

find . -mindepth 1 -maxdepth $maxDepth -type d 2>/dev/null
