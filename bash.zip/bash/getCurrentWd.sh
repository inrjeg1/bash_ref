#!/bin/bash

echo ${PWD}
