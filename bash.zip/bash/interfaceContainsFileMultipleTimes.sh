#!/bin/bash

boaDir="/boa_prd/ptacken/lil-development-2"
allComponents=`/sdev_shared/fc062data/PTAD/scripts/bash/allComponents.sh`
#allComponents="KM"


for component in $allComponents; do
    buildDepFile="${boaDir}/${component}/buildDependencies.gradle"
    previousLine=''
    echo "COMPONENT: $component"
    while read line; do
        if [[ ! -z $previousLine ]]; then
            if [[ $line != "}" ]]; then
                if [[ "$line" == "$previousLine" ]]; then
                    echo "$line"
                fi
            fi
        fi
        previousLine=$line
    
    done < <(cat ${buildDepFile})

    

done


