#!/usr/bin/env python

import targetStore

def printAlpha():
    print "Alpha"
    
def printBravo():
    print "Bravo"
    
def printCharlie():
    print "Charlie"

def printDelta(andMore):
    print "Delta", andMore

def printEcho():
    print "Echo"

def printArgument(argument):
    print argument

