#!/bin/bash

current_user=`whoami`

if [[ $current_user == "atl.1001" ||  $current_user == "atl.IP83" ]]; then
   cp /home/ptacken/Userdata/nedit_settings/nedit.rc /usr/asm/${current_user}/.nedit/nedit.rc
fi

