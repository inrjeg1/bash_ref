#!/bin/bash


if [[ ($1 == "-h") || ($1 == "--help") ]]; then
    echo "Usage: $0 <review id> <files to upload>"
    exit 0
fi

if [[ ! ($1 =~ ^[0-9]+$) ]]; then
    echo "The first argument needs to be the review ID"
    exit 1
fi

if [[ $# -lt 2 ]]; then
    echo "Please provide at least one filename as input"
    exit 1
fi

reviewId=$1
fileNames=`echo "${@:2}" | tr " " "\n"`

cleartool ls -s `echo $fileNames` | sed 's/@@/ /' | awk '{print $0 " " $NF}' | sed 's|/[0-9]*$|/0|' | ccollab addversions $reviewId

