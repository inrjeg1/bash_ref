#!/bin/bash

if [[ $# < 1 ]];then
    echo "Provide a stream to merge from"
    exit 1
fi

sourceStream=$1

ccList=`ccget_buildscope | cut -d'/' -f2`

for component in $ccList; do
    echo -e "\n  ===  Merging component $component  ===" 
    cd `xcd $component`
    ccmerge -m -s $sourceStream
done

echo -e "\n==== Merging all scopefiles ====\n"

allScopefiles=`/sdev_shared/fc062data/PTAD/scripts/bash/getAllScopefilesInBuildscope.sh`
ccmerge -m -s $sourceStream -e $allScopefiles
