#!/bin/bash

inputfile='/home/ptacken/public/changelist_original'
outputfile='/home/ptacken/public/changelist_output'

if [[ $# == 0 ]]; then
    echo "==> Taking file $inputfile as input"
else
    inputfile=$1
fi

echo -n "" > $outputfile

IFS='
'
for fileName in `cat $inputfile`; do
    if [[ -f $fileName ]]; then
        echo $fileName >> $outputfile
    fi
done

echo "=== Output is written to $outputfile ==="
