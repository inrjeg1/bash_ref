#!/bin/bash

new_arg_list=""
nr_files=0

for to_open_file in $@; do
    if [[ -e $to_open_file ]]; then
        if [[ ! -d $to_open_file ]]; then
            new_arg_list="$new_arg_list $to_open_file"
            ((nr_files++))
        else
            echo "  ==== $to_open_file is a directory ===="
        fi
    else
        aliasFile="/home/ptacken/.cshrc"
        lineContainingAlias=`cat $aliasFile | grep "alias $to_open_file '" | head -1`
        whichMessage=`which $to_open_file 2>/dev/null`
        if [[ ! -z $lineContainingAlias ]]; then
            fileName=`echo $lineContainingAlias | rev | cut -d\' -f2 | cut -d' ' -f1 | rev`
            if [[ -e $fileName ]]; then
                new_arg_list="$new_arg_list $fileName"
                ((nr_files++))
            else
                $0 $fileName
            fi
        elif [[ ! -z $whichMessage ]]; then
            fileName=$whichMessage
            new_arg_list="$new_arg_list $fileName"
            ((nr_files++))
        else
            echo "  ==== File $to_open_file does not exist ===="
        fi
    fi
done

if [[ $nr_files -gt 0 ]]; then
    nedit $new_arg_list &
else
    if [[ $# -eq 0 ]]; then
        nedit &
    fi 
fi
