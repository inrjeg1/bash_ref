#!/bin/bash

alpha=0
bravo=0
charlie=0
delta=0
foxtrott=0



while getopts abcdf option; do
case "$option" in
    a) alpha=1;;
    b) bravo=2;;
    c) charlie=3;;
    d) delta=4;;
    f) foxtrott=5;;
esac
done


echo "alpha: $alpha"
echo "bravo: $bravo"
echo "charlie: $charlie"
echo "delta: $delta"
echo "foxtrott: $foxtrott"

