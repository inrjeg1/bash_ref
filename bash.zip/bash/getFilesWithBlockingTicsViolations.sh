#!/bin/bash

if [[ $# -lt 1 ]]; then
    echo "Usage: $0 <tics report file>"
    exit 1
fi

ticsReport=$1
previousLine=""
insideViolations=0
fileNamePrinted=0
titleLine=""
levelLimit=7

while read line; do
    
    if [[ $line == Analyzing* ]]; then
        fileName=`echo $line | rev | cut -c4- | cut -d' ' -f1 | rev`
        fileNamePrinted=0    
    fi
    
    if [[ $line =~ "----+--" ]]; then
        if [[ ($previousLine =~ "RULE ID") &&
              ($previousLine =~ "LEVEL") && 
              ($previousLine =~ "#") ]]; then
            insideViolations=1
            titleLine=$previousLine
        else
            insideViolations=0
        fi
        
    elif [[ $insideViolations == 1 ]]; then
        level=`echo $line | cut -d'|' -f2 | sed 's/ //'`
        if [[ $line =~ '| BLOCKING |' ]]; then
        #if [[ $level -lt $levelLimit ]]; then
            if [[  ! $fileNamePrinted -eq 1 ]]; then
                echo -e "\n=== $fileName ==="
                echo "$titleLine"
                
                fileNamePrinted=1
            fi
            
            echo "$line"
        
        fi
    fi
    previousLine=$line
    
    if [[ $line == "SUMMARY" ]]; then
        exit 0
    fi

done < <(cat $ticsReport)

