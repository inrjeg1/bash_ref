#!/bin/bash

fileName="/boa_prd/ptacken/lil-development/KMLIWA/com/ext/inc/duract_SplitCowaMeasurementFactory.hpp"

echo $fileName
result=`cat $fileName | egrep -e '#include' | cut -d' ' -f2 | sed -r 's/\"//g'`
#| sed "s/</\'/g" | sed "s/>/\'/g"`

echo $result | tr ' ' '\n'
  
