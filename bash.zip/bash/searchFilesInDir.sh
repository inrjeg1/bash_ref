#!/bin/bash

dirName=$1
fileName=$2

dirsToSearch=`find . -mindepth 1 -maxdepth 1 -type d | grep $dirName`
parentDir=`pwd`

while read dir; do
    
    cd $dir
    findresult=`find . | grep $fileName`
    while read resultLine; do
        if [[ ! -z $resultLine ]]; then
            echo "${parentDir}/${dir}/${resultLine}"
        fi
    done < <(echo "$findresult")
    
    cd $parentDir

done < <(echo "$dirsToSearch")

