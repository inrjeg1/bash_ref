#!/bin/bash

declare -a VELIRFxTESTSCRIPTS=( 
"behave_tests.sh"
"ddPythonTests.sh"
"execution_environment.sh"
"pythonLibraries.sh"
"pythonTests.sh"
"run_behave_tests.sh"
"run_ddPythonTests.sh"
"run_local_tests.sh"
"run_pythonTests.sh"
"run_unit_tests.sh"
"unit_tests.sh"
)


for file in "${VELIRFxTESTSCRIPTS[@]}"; do

    echo "f: $file"

done

