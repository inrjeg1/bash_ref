#!/bin/bash

startTimeNanoSeconds=`date +%N | cut -c-1`
sleep 0.2
secondTimeNanoSeconds=`date +%N | cut -c-1`

diffNano=$(($secondTimeNanoSeconds - $startTimeNanoSeconds))

if [[ $diffNano -lt 0 ]]; then
    diffNano=$(($diffNano + 10))
fi
while [[ $diffNano -gt 1 ]]; do
    echo "DIFF: $diffNano"
    sleep 0.05
    
    secondTimeNanoSeconds=`date +%N | cut -c-1`
    diffNano=$(($secondTimeNanoSeconds - $startTimeNanoSeconds))
    if [[ $diffNano -lt 0 ]]; then
        diffNano=$(($diffNano + 10))
    fi
done
