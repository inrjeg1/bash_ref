#!/bin/bash

myString="3c743314 (<johan.krielen@asml.com> 2019-04-08 11:40:38 +0200  22)      cat  bla"

echo $myString | awk -F '>' '{print $2$1">"}' | sort | awk -F '(
