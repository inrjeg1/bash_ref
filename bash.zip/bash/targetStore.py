
lildevTargetStore = \
    '/boa_prd/lil_ci/promoted_targets_store/lil-development'


def getFoxtrott():
    def anotherFunc():
        print "AnotherFunc"
    return "Foxtrott Golf Hotel"


getFoxtrott()
