#!/bin/bash

declare -a devbench_list=`devbench lnxlist -U jenkins | grep jenkins_lil_ci | grep passive | cut -d" " -f3`

for jenkins_devbench in $devbench_list
do
   /boa_proj_build/asintots/ci/jenkins-tooling/remove_devbench.sh $jenkins_devbench
done

