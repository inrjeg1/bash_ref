# Copyright (c) 2016, ASML Holding B.V. (including affiliates).
# All rights reserved

import unittest
import os

import KMXAxSD
import KMXAxLOTxSD
import KMXAxLOTxDATAxPRD
import MEXAxLOTINFO

import DDXA
import ERXA
from WPxCHUCK import chuck_id_enum
import TAUT
import KMLIEX_integration_test_facilities
import KMLIEXxSPM
import KMLIEXSPxMEXA
import KRXAxWAMxSD
import LZLAxSCAN
import LZDRxSCAN
import LZDRxSPOT
import SMXA

from KMLIEX import Mexa
from mdl import MdlFile, getMdlFilename
from MdlTags import MdlDataTag
from er import extractErForCurrentTest
from tpt import ThroughputTrace

MDL_PATH = '/usr/asm/data.0000/output_informal_diagnostics/ME'

KMXAxSD = KMXAxSD.KMXAxSD("KMLIEX")
KMXAxLOTxSD = KMXAxLOTxSD.KMXAxLOTxSD("KMLIEX")

class LotProductionTestCaseBase(unittest.TestCase):
    mdlName = None

    def getMdlName(self):
        if not self.mdlName:
            self.mdlName = KMLIEX_integration_test_facilities.createMdlName(self._testMethodName)
        return self.mdlName

    def start_lot(self, mdl_name=None, lot_data=None, lot_info=None, lot_retry=False):
        if mdl_name is None:
            mdl_name = self.getMdlName()
        if lot_data is None:
           lot_data = KMXAxLOTxDATAxPRD.lot_data_t()
        if lot_info is None:
           lot_info = MEXAxLOTINFO.lot_info()
        
        KMXAxLOTxSD.lot_start_prd(mdl_name, lot_data, lot_info, lot_retry)

    def measure_wafer(self,
                      wafer_nr=1,
                      chuck_nr=1,
                      wafer_load_offset=None,
                      wafer_seq_nr=1,
                      is_production_wafer=True,
                      first_wafer=False,
                      next_wafer_is_first_wafer_of_lot=False,
                      chuck_successfully_exposed_in_lot=False,
                      do_recovery=False,
                      overrule_enc_fly_lvl=False):

        chuck_dic = KMLIEX_integration_test_facilities.create_chuck_dict()
        if not wafer_load_offset :
            wafer_load_offset = DDXA.Object('xyavect')

        KMXAxSD.measure_wafer(wafer_nr,
                              chuck_dic[chuck_nr],
                              wafer_load_offset,
                              wafer_seq_nr,
                              is_production_wafer,
                              first_wafer,
                              next_wafer_is_first_wafer_of_lot,
                              chuck_successfully_exposed_in_lot,
                              do_recovery,
                              overrule_enc_fly_lvl)

    def finish_lot(self, on_failure=False):
        return KMXAxSD.lot_finish(on_failure)

    def run_one_wafer_lot(self, chuck_nr=1):
      self.start_lot()
      self.measure_wafer(first_wafer=True)
      self.finish_lot()

    def run_two_wafer_lot(self, mdl_name=None):
      self.start_lot(mdl_name)
      self.measure_wafer(chuck_nr=1, first_wafer=True,  wafer_nr=1, wafer_seq_nr=1)
      self.measure_wafer(chuck_nr=2, first_wafer=False, wafer_nr=2, wafer_seq_nr=2)
      self.finish_lot()
#=== Test Execution ===

class TestStartEndTestProtocol(LotProductionTestCaseBase):
   def setUp(self):
      KMLIEX_integration_test_facilities.setUpTest(self.id())

   def tearDown(self):
      KMLIEX_integration_test_facilities.tearDownTest(self.id())

   def test_start_lot_called_twice(self):
      self.start_lot()

      with self.assertRaises(ERXA.Error):
         self.start_lot()

      self.finish_lot()
      
      erFile = extractErForCurrentTest(self.id())
      erFile.assertContainsException('SYSTEM ERROR: KM-0604',
         withMessage="std::runtime_error: Invalid call - Violation of state machine protocol")

   def test_finish_lot_called_twice(self):
      self.run_one_wafer_lot()

      with self.assertRaises(ERXA.Error):
         self.finish_lot()
     
      erFile = extractErForCurrentTest(self.id())
      erFile.assertContainsException('SYSTEM ERROR: KM-0604',
         withMessage="std::runtime_error: Invalid call - Violation of state machine protocol")
 
   def test_finish_lot_without_measure(self):
      self.start_lot()
      self.finish_lot()

   def test_finish_lot_without_start(self):
      with self.assertRaises(ERXA.Error):
         self.finish_lot()

   def test_measure_without_start(self):
      with self.assertRaises(ERXA.Error):
         self.measure_wafer(chuck_nr=1)


class TestFunctionalMeasureWafer(LotProductionTestCaseBase):
   def assertTptTags(self):
       self.tpt.assertContainsTag('KV-9310')  # KVLIWMxTPT:MODEL_STROKE2WAM_REMOVE_DUPLICATIONS
       self.tpt.assertContainsTag('KV-9320')  # KVLIWMxTPT:MODEL_STROKE2WAM_CONSTRUCT_FIELD_WAMS
       self.tpt.assertContainsTag('KV-9330')  # KVLIWMxTPT:MODEL_STROKE2WAM_REGRID
       self.tpt.assertContainsTag('KV-9340')  # KVLIWMxTPT:MODEL_STROKE2WAM_CONVERT_EXTENDED_WZM_TO_STANDARD_WZM
       self.tpt.assertContainsTag('KV-9350')  # KVLIWMxTPT:MEASURE_WZM_STROKE

   def setUp(self):
      self.tpt = ThroughputTrace()
      KMLIEX_integration_test_facilities.setUpTest(self.id())

   def tearDown(self):
      KMLIEX_integration_test_facilities.tearDownTest(self.id())
    
   def test_good_weather_one_wafer_lot(self):
      self.run_one_wafer_lot()
      self.assertTptTags()

   def test_good_weather_two_wafer_lot(self):
      self.run_two_wafer_lot()

   def test_good_weather_two_lots(self):
      self.run_two_wafer_lot(self.getMdlName() + 'Lot1')
      self.run_two_wafer_lot(self.getMdlName() + 'Lot2')


class TestProcessKRLIES(LotProductionTestCaseBase):
   def setUp(self):
      self.mdlName = None

   def test_LIL_variant_KRXAxWAMxSD_det_wam_ids_called_correctly(self):
      self.mdlName = self.getMdlName()
      mexa = Mexa.Mexa()
      mexa.lookup()
      mexa.openFile(self.mdlName)

      nr_images = 2
      image_data = self.createTwoImages()

      wam_ids = self.KRXAxWAMxSD.KRXAxWAMxSD("KRLIES").det_wam_ids(nr_images, image_data)

      mexa.closeFile(self.mdlName, 0)
      
      mdlFile = MdlFile(getMdlFilename(self.mdlName))
      expectedTag = MdlDataTag('KV-C8E9', 'KMLIEXxECPxLOG:krxaxwamxsd_det_wam_ids')
      
      foundTags = mdlFile.find(expectedTag.tag)
      self.assertEqual(1, len(foundTags))
      self.assertEqual(2, len(foundTags[0].dat.input.images.data[0].exposures))
      self.assertEqual(2, len(foundTags[0].dat.input.images.data[1].exposures))
      
      self.assertTrue(foundTags[0].dat.output_is_valid)
      self.assertEqual(2, len(foundTags[0].dat.output.wam_ids))
      self.assertEqual(2, len(foundTags[0].dat.output.wam_ids[0]))
      self.assertEqual(2, len(foundTags[0].dat.output.wam_ids[1]))


   def createTwoImages(self):
      image_data = DDXA.Struct('KRXAxWAM:max_images_t')
      nr_images = 2
      
      image1 = DDXA.Struct('KRXAxWAM:image_t')

      image_exposure1 = DDXA.Struct('KRXAxWAM:image_exposure_t')
      image_exposure1.position.x = 0.000000e+00
      image_exposure1.position.y = 1.600000e-02 
      image_exposure2 = DDXA.Struct('KRXAxWAM:image_exposure_t')
      image_exposure2.position.x = 1.800000e-02
      image_exposure2.position.y = -1.600000e-02 

      image1.exposures.append(image_exposure1)
      image1.exposures.append(image_exposure2)

      image2 = DDXA.Struct('KRXAxWAM:image_t')

      image_exposure3 = DDXA.Struct('KRXAxWAM:image_exposure_t')
      image_exposure3.position.x = -2.300000e-02
      image_exposure3.position.y = 2.600000e-02 
      image_exposure4 = DDXA.Struct('KRXAxWAM:image_exposure_t')
      image_exposure4.position.x = 1.900000e-02
      image_exposure4.position.y = -1.600000e-02 

      image2.exposures.append(image_exposure3)
      image2.exposures.append(image_exposure4)

      image_data.data[0] = image1
      image_data.data[1] = image2   

      return image_data

if __name__ == '__main__':
   unittest.main()
