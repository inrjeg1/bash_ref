#!/bin/bash


#set -e   # abort on error

nr_args="$#"

echo $nr_args

if [ $# -gt 1 ]; then  #gt: greater than
  echo "MORE THAN 1"
else
  echo "NOT more than 1"
fi



passing_function.sh && 
passing_function.sh && 
failing_function.sh &&  
passing_function.sh




