class LotProductionTestCaseBase(unittest.TestCase):
    mdlName = None

    def getMdlName(self):
        if not self.mdlName:
            self.mdlName = KMLIEX_integration_test_facilities.createMdlName(self._testMethodName)
        return self.mdlName

    def start_lot(self, mdl_name=None, lot_data=None, lot_info=None, lot_retry=False):
        if mdl_name is None:
            mdl_name = self.getMdlName()
        if lot_data is None:
           lot_data = KMXAxLOTxDATAxPRD.lot_data_t()
        if lot_info is None:
           lot_info = MEXAxLOTINFO.lot_info()
        
        KMXAxLOTxSD.lot_start_prd(mdl_name, lot_data, lot_info, lot_retry)
