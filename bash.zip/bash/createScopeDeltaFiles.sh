#!/bin/bash

gem install scopeset

export GEM_HOME="$HOME/.gem"
export PATH="$HOME/.gem/bin:$PATH"

viewName=$(cleartool pwv -short)

if [[ "$viewName" == "** NONE **" ]]; then
    echo "Run this script from a Clearcase view"
    exit 1
fi

if [[ $# -lt 1 ]]; then
    echo "Give path to BOA based on sync tag as argument"
    exit 1
fi

boaDir=$1
tmpDir="/tmp/LIL_scope"
scopeDeltaFile="/tmp/scope_delta.txt"
scopeFileList="/tmp/LIL_scopefiles.lst"
fullPathList="/tmp/LIL_scopefiles_full_path.lst"

## BOA stuff
cd $boaDir

cadenv -r 4.2 gradle
cadenv -r 1.8.0.45 jdk

#scopeset delta -d . -f $scopeDeltaFile -w /tmp/scope_warnings.txt

## Clearcase stuff

mkdir $tmpDir
ccrscope -F -d $scopeDeltaFile -o $tmpDir -O write_touched_only
ls -1 $tmpDir > $scopeFileList
/vobs/litho/scm/scopecontrol/interfaces/int/tst/scope_file_list.pl | grep -f $scopeFileList > $fullPathList
sed -i 's/.txt$/.txt.2/' $fullPathList
cleartool co -nc `cat $fullPathList`

echo -e "Done!\n--> Manual actions: merge the scopefiles in $tmpDir and filenames in $fullPathList"
