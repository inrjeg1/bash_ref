#!/bin/bash

echo "Node name: $NODE_NAME"
echo "Executor number: $EXECUTOR_NUMBER"
