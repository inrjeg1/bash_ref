#!/bin/bash

current_dir=`pwd`
current_dir_base=`basename $current_dir`
tmp_makefile='/home/ptacken/public/tmp_makefile'


function changeMakfiles()
{
    for makefile in `ls | grep -e ^makefile`; do

        echo -n '' > $tmp_makefile

        makefileNeedsChanges=0
        messagePrinted=0

        isLinuxTarget=0
        CppflagsLine=''
        srcsLine=0
        srcsLinePassed=0

        while IFS= read -r line; do

            if [[ ( $makefileNeedsChanges == 1 ) &&  ( $messagePrinted == 0 ) ]]; then
                echo "Makefile $makefile needs to be changed"
                messagePrinted=1
            fi

            if [[ ( $isLinuxTarget == 1 ) ]]; then

                if [[ $line =~ "CPPFLAGS" ]]; then

                    if [[ ( $srcsLinePassed == 0 ) ]]; then
                        CppflagsLine="$line"
                        makefileNeedsChanges=1
                    else
                        echo "$line" >> $tmp_makefile
                    fi
                else 
                    if [[ ( $srcsLinePassed == 1 ) && ! ( $line =~ [A-Za-z] ) ]]; then

                        echo "$CppflagsLine" >> $tmp_makefile
                        echo "$line" >> $tmp_makefile
                        
                        srcsLinePassed=0
                    else
                        echo "$line" >> $tmp_makefile
                    fi
                fi
            else
                echo "$line" >> $tmp_makefile

            fi


            if [[ $line =~ "X86CPPTARGET" ]]; then
                isLinuxTarget=1
            elif [[ ! $line =~ [A-Za-z] ]]; then
                isLinuxTarget=0
                srcsLinePassed=0
            elif [[ ($line =~ "SRCS") && ($isLinuxTarget == 1) ]]; then
                srcsLine=1
            fi
            if [[ ( ( $srcsLine == 1) && ! ($line =~ '\'  ) ) ]]; then
                srcsLinePassed=1
                srcsLine=0
            fi

        done < <(cat "$makefile"; echo)
        
        if [[ $makefileNeedsChanges == 1 ]]; then
            cat $tmp_makefile > $makefile
        fi

    done
}


for cc in `/sdev_shared/fc062data/PTAD/scripts/bash/allComponents.sh`; do

    echo "  == Changing makefiles in $cc =="

    cd `/sdev_shared/fc062data/PTAD/scripts/bash/go_to_component.sh $cc`
    cd com/ext/lib
    
    changeMakfiles

    cd ../../int/lib
    
    changeMakfiles
    
    cd ../tst
    
    changeMakfiles

done
