#!/bin/bash


do_commit="NO_COMMIT"

if [ "$#" -gt 0 ]; then
   do_commit=$1
fi

sortingDone=0
allBuildDependenciesFiles=`find . | grep "buildDependencies.gradle"`
buildDepsArray=()

for buildDepFile in $allBuildDependenciesFiles; do
    
    sortedBuildDepFile="${buildDepFile}.sorted"
    
    /home/ptacken/bin/sortBuildDependencies.py $buildDepFile $sortedBuildDepFile
    nr_diff_lines=`diff $buildDepFile $sortedBuildDepFile | wc -l`

    if [ $nr_diff_lines -gt 0 ]; then
       echo -n "$buildDepFile needs sorting..."
       \mv $sortedBuildDepFile $buildDepFile
       buildDepsArray+=($buildDepFile)
       sortingDone=1
       echo "done!"
    else
       \rm $sortedBuildDepFile
    fi

done


if [ $sortingDone -eq 1 ]; then
    if [ $do_commit = "commit" ]; then
        echo -n "Commiting sort action..."
        for buildDepFile in $buildDepsArray; do
            git add "$buildDepFile"
            git commit -m 'sorted buildDependencies.gradle'
            echo "done!"
        done
    fi
fi
