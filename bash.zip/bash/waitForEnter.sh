#!/bin/bash

echo "Hello"

read

echo "World"



