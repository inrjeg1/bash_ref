#!/bin/bash

allScopefiles=`/sdev_shared/fc062data/PTAD/scripts/bash/getAllScopefilesInBuildscope.sh`
listNonExistingFilesCmd="/sdev_shared/fc062data/PTAD/scripts/bash/listNonExistingTargetsInScopefiles.sh"

IFS=$'\n'
for scopefile in $allScopefiles; do
    nonExistingFiles=`eval ${listNonExistingFilesCmd} $scopefile | grep "NOT FOUND" | grep -v pyc | grep -v MKGT | grep -v "KM/com"`

    echo " --> Cleaning up $scopefile"
    

    for line in `echo "$nonExistingFiles"`; do
        fileName=`echo "$line" | sed 's/   === NOT FOUND: //' | sed 's/===//' | sed -e 's@/@\\\/@g'`
        
        #echo $fileName

        sed -i "/$fileName/d" $scopefile
        
    done
done


