function installGtest() {
    cadenv -r 1.7.0.a_32 gtest
}

function installGmock() {
    cadenv -r 1.7.0.a_32 gmock
}
function installRuby() {
    cadenv -r 2.3.0.b ruby
}

function installClang() {
    cadenv -r 6.0.0 clang
}

function installBullseye() {
    cadenv -r 8.15.23 bullseye
}

function installBCompare() {
    cadenv -r 4.2.9 bcompare
}

function installGemSources() {
    gem sources -a http://boa-arm.asml.com:8081/artifactory/api/gems/rubygems-all/
    gem sources -r https://rubygems.org/
    gem sources -r http://rubygems.org/
}

function installPackaging() {
    if [ "${GEM_HOME}" ]
    then
        ruby
        gemSources
        gem install packaging
    fi
}

function installWrwb_boa() {
    cadenv wrwb_boa
}

function setup_boa_env() {
    cs_boa_setup
}

function installLibxml2() {
    cadenv -r 2.9.4 libxml2
}

function installTestarena() {
    cadenv -r 2.7.14 python
}


for package in "$@"
do
    # Check if the function exists - bash specific
    if declare -f "${package}" > /dev/null
    then
      # call arguments verbatim
      echo "Installing package '${package}'" >&2
      "${package}"
    else
      # Show a helpful error
      echo "'${package}' is not a known package" >&2
      exit 1
    fi
done
