#!/bin/bash

#allChars=`cat dummy_txt.txt`
#
#
#function echoChar
#{
#    echo $1
#}
#
#
#IFS=''
#while read character; do
#
#    echoChar $character
#
#
#
#done < <(cat "dummy_txt.txt")
#
#IFS=''
#for charA in `echo $allChars`; do
#    echo "char: $charA"
#
#done


a=0
b=0

while (( $(echo "$b < 10"| bc -l) )); do
    echo "b: $b"
    b=$(($b + 1))
    if [ $b -eq 2 ]; then
        echo "equal"
        a=1
    fi
    
done

echo $a


