#!/bin/bash

ccList=`ccget_buildscope | cut -d'/' -f2`
viewName=$(cleartool pwv -short)

if [[ "$viewName" == "** NONE **" ]]; then
    echo "Not in a Clearcase view, exiting now"
    exit 1
fi

allPaths="ext/ddf
ext/inc
ext/lib
int/ddf
int/inc
int/lib
int/bin
int/tst"

for component in $ccList; do

    echo "Adding interface name from include for $component"
    
    ## Just check the BOA components
    allBoaComponents=`/sdev_shared/fc062data/PTAD/scripts/bash/allComponents.sh`
    for  boaComponent in $allBoaComponents; do
    
        if [[ ($boaComponent == $component &&
               $component != "KM" &&
               $component != "KR") ]]; then
        
            for path in $allPaths; do
                cd `xcd $component com $path`
                /sdev_shared/fc062data/PTAD/scripts/bash/addInterfacesNameToIncludes.sh
            done
        fi
    done
done
