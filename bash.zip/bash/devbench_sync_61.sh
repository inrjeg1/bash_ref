#!/bin/bash

#-----------------------------------------------------------------------------#
#                                                                             #
#       Copyright (c) 2015, ASML Holding N.V. (including affiliates).         #
#                         All rights reserved                                 #
#                                                                             #
#-----------------------------------------------------------------------------#

#--- Failure interception part -----------------------------------------------#

abort()
{
  echo "=== ERROR DETECTED"

  exit 1
}
trap 'abort' 0    # traps the 0 (exit) signal and calls abort function
set -e

#--- Main body of script -----------------------------------------------------#

echo "=== Installing/Updating packager..."
cadenv ruby
GEM_HOME="$HOME/.gem"
PATH="$HOME/.gem/bin:$PATH"
gem sources -a http://boa-arm.asml.com:8081/artifactory/api/gems/rubygems-all/
gem sources -r https://rubygems.org/
gem install activesupport -v "4.2.5"
gem uninstall packaging --force -x
gem install packaging -v 1.5.5
hash -r

echo "=== Creating sync..."
packager create_sync --machine-type hybrid_a --trace 


echo "=== Activating devbench..."
devbench lnxactivate -o $1 # -o for opening no terminal

echo "=== Syncing to devbench..."
/boa_proj_build/boa_tooling/devbench sync -t -l 

#--- Stopping failure interception -------------------------------------------#
trap : 0    # stop trapping

