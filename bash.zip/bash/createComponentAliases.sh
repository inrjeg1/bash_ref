#!/bin/bash

clearcaseAliasFile='/sdev_shared/fc062data/PTAD/data/ccAliases/clearcaseAliases'
boaAliasFile='/sdev_shared/fc062data/PTAD/data/ccAliases/boaAliases'

function goToComponent()
{
    component=$1
    cd `xcd $component`
}

function createAlias()
{
    component=$1
    aliasFile=$2
    if [[ ! `grep "alias $component " $aliasFile` ]]; then
        lowerCaseName=`echo $component | tr '[:upper:]' '[:lower:]'`
        echo "alias $component 'cd \`/sdev_shared/fc062data/PTAD/scripts/bash/go_to_component.sh $component\`'" >> $aliasFile
        echo "alias $lowerCaseName 'cd \`/sdev_shared/fc062data/PTAD/scripts/bash/go_to_component.sh $component\`'" >> $aliasFile
    fi
}

function createClearcaseAliases()
{
    allComponents=`ccget_buildscope | cut -d'/' -f2`
    for component in $allComponents; do
        if [[ ! $component == 'full' ]]; then
            createAlias $component $clearcaseAliasFile
        fi
    done
}

function createBoaAliases()
{
    allComponents=`/sdev_shared/fc062data/PTAD/scripts/bash/allComponents.sh`
    for component in $allComponents; do
        createAlias $component $boaAliasFile
    done
}

viewName=$(cleartool pwv -short)
boaRepo=`/sdev_shared/fc062data/PTAD/scripts/bash/get_current_repository.sh`
if [[ $# -gt 0 ]]; then
    if [[ "$viewName" != "** NONE **" ]]; then
        for component in $@; do
            output="$(goToComponent $component 2>&1)"
            if [[ $output != "Abbreviation not found" ]]; then
                createAlias $component $clearcaseAliasFile
            else
                echo "=== Component $component does not exist ==="
            fi
        done
    else
        echo "=== You need to be in a view to add component aliases ==="
    fi
elif [[ "$viewName" != "** NONE **" ]]; then
    createClearcaseAliases
elif [[ $boaRepo != "./" ]]; then
    createBoaAliases
fi
