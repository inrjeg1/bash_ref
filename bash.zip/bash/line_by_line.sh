#!/bin/bash



function readLines()
{
    for line in (`cat 'buildDependencies.gradle'`)

        

    done
        

}


readLines



