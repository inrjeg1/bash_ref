#!/bin/bash

if [[ $# -lt 1 ]]; then
    echo "Usage: $0 <username>"
    exit 1
fi

username=$1

cd /shared/nl011022_u/test_data/TWINRUNR/SYSTEM

alldirs=`find . -mindepth 1 -maxdepth 1 -type d`

for dir in $alldirs; do
    if [[ $dir == "./m"???? ]]; then
        cd $dir
        findResults=`ls -a | grep $username`
        if [[ ! -z $findResults ]]; then
            for result in $findResults; do
                echo "${dir}/$result"
            done
        fi
        cd ..
    fi
done
