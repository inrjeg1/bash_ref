#!/bin/bash

source ../`basename "$PWD"`/printHello.sh

printHello
