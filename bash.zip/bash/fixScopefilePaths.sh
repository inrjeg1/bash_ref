#!/bin/bash


if [[ $# < 1 ]]; then
    echo "Please provide a scopefile"
    exit 1
fi


outputFile="/home/ptacken/public/tmpd/scopefileOutput.txt"

echo -n '' > $outputFile

componentName="EMPTY"
interfaceIsNSLIB=0

IFS=''
while read line; do

    
    if [[ $line =~ "interface "  ]]; then
        componentName=`echo $line | rev | cut -d' ' -f1 | rev | cut -d'x' -f1`
        echo "$line" >> $outputFile

        if [[ $line =~ "xNSLIB" ]]; then
            interfaceIsNSLIB=1
        else
            interfaceIsNSLIB=0
        fi

    elif [[ $line =~ ".ddf" && !($line =~ "com/ext") ]]; then
            fileName=`echo $line | rev | cut -d' ' -f1 | rev`
            echo "$line" | sed "s/${fileName}/${componentName}\/com\/ext\/ddf\/${fileName}/" >> $outputFile
            
    elif [[ ($line =~ "typ.h" ||  $line =~ "met.h") &&  !($line =~ "com/ext") ]]; then
            fileName=`echo $line | rev | cut -d' ' -f1 | rev`
            echo "$line" | sed "s/${fileName}/${componentName}\/com\/ext\/inc\/bld\/${fileName}/" >> $outputFile
         
    elif [[ ($line =~ ".hpp" || $line =~ ".h"$ ) &&  !($line =~ "com/ext") ]]; then
            fileName=`echo $line | rev | cut -d' ' -f1 | rev`
            echo "$line" | sed "s/${fileName}/${componentName}\/com\/ext\/inc\/${fileName}/" >> $outputFile
        
    elif [[ $line =~ ".cpp" && $line =~ ".so" &&  !($line =~ "com/ext") ]]; then
            fileName=`echo $line | rev | cut -d' ' -f1 | rev`   
            
            if [[ $interfaceIsNSLIB == 0 ]]; then
                echo "$line" | sed "s/${fileName}/${componentName}\/com\/ext\/inc\/bld\/${fileName}/" | sed "s/.cpp.x86lnx.so/.cpp.so/"  >> $outputFile
            else
                echo "$line" | sed "s/${fileName}/${componentName}\/com\/ext\/lib\/bld_x86lnx\/${fileName}/" | sed "s/.cpp.x86lnx.so/.cpp.so/" >> $outputFile
            fi
     
     elif [[ $line =~ ".so" &&  !($line =~ "com/ext") ]]; then       
            fileName=`echo $line | rev | cut -d' ' -f1 | rev`
            
            if [[ $line =~ ".x86lnx.so" ]]; then 
                : #do nothing
            else
                echo "$line" | sed "s/${fileName}/${componentName}\/com\/ext\/inc\/bld\/${fileName}/" >> $outputFile
            fi

    elif [[ $line =~ ".im" &&  !($line =~ "com/ext") ]]; then
            fileName=`echo $line | rev | cut -d' ' -f1 | rev`   
            echo "$line" | sed "s/${fileName}/${componentName}\/com\/ext\/lib\/${fileName}/" >> $outputFile

    elif [[ $line =~ ".himp" || $line =~ ".hddd" ]]; then
            : #do nothing

    else
        echo "$line" >> $outputFile
    fi
  
done <`echo $1`


echo "Output saved to $outputFile"
