#!/bin/bash

sed 's/  / /g' $argv | tr ' ' '\n'
