#!/bin/bash

### RUN FROM CLEARCASE VIEW ###


boa_root="/boa_proj_build/ptacken/tmp_master_changes/"
this_component=`pwd | rev | cut -d/ -f1 | rev`


#declare -a components=( KMLIEX
#                        KVLICO
#                        KVLIHS
#                        KVLIVT
#                        KVLIWC
#                        KVLIWM
#                        VELIRF
#)
                       
function compare_nr_of_files {
   cc_path=$1
   boa_path=$2
   
   nr_files_cc=`ls -lF $cc_path | wc -l`
   
   if [ -d $boa_path ]; then
      echo -e "\nPATH: "$boa_path
      nr_files_boa=`ls -lF $boa_path | wc -l`

      if [ $nr_files_cc -ne $nr_files_boa ]; then
         echo "UNEQUAL NUMBER OF FILES"
      fi

      for file in `ls -1 $cc_path`; do

         occs_boa=`ls $boa_path | grep $file | wc -l` 
         if [ $occs_boa -eq 0 ]; then
            echo "NOT IN BOA:" $file
         else

            if [[ -f $file ]]; then
               if [[ `diff --strip-trailing-cr ${cc_path}/${file} ${boa_path}${file} | wc -l` -gt 0 ]]; then
                  echo "FILES ARE DIFFERENT: " $file
               fi
            fi
         fi
      done

      for file in `ls -1 $boa_path`; do
      occs_boa=`ls $cc_path | grep $file | wc -l` 
      if [ $occs_boa -eq 0 ]; then
         echo "NOT IN CC:" $file
      fi
      done

   fi
   
   
}


function go_through_dirs {
   
   cc_path=$1
   boa_path=$2
   directories=`ls -lF $ccpath |  grep -v '\->' | rev  | cut -d' ' -f1 | grep '/' | rev | grep -v bld/ | grep -v bld_x86lnx/`
   for dir in ${directories[@]}
   do
      if [[ $dir != "bld" ]]; then 
         cd $dir
         boa_path_old="$2"
         boa_path="${2}${dir}"
         compare_nr_of_files `pwd` ${boa_path}
         go_through_dirs `pwd` ${boa_path}
         boa_path="${boa_path_old}"
         cd ..
      fi
   done
   
   
}
cd com
boa_path="${boa_root}${this_component}/com/"
go_through_dirs `pwd` "$boa_path"

#
#for comp in ${components[@]}
#do
#   cd $comp
#   cd com
#   go_through_dirs
#   cd ../..
#    
#done








