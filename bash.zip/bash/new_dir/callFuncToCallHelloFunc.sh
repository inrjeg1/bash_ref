#!/bin/bash

../callFuncFromDifferentDir.sh


