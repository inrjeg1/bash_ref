#!/bin/bash

failed=0


if [ $1 -eq 2 ]; then
   failed=0
else
   failed=1
fi

exit $failed
