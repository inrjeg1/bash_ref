#!/bin/bash

if [[ $# -lt 1 ]]; then
    echo "Please provide an input file"
    exit 1
fi

inputFile=$1
diffOutput=`cleartool diff -pred ${inputFile}`

if [[ $diffOutput == "Files are identical" ]]; then
    echo "File ${inputFile} is identical to predecessor"
else
    export CLEARCASE_USE_DIFF=becompare

    /opt/rational/clearcase/bin/cleartool diff -g -pred $inputFile
fi
