#!/bin/bash


function executeCommand()
{
    command_to_execute=$@
    echo "command: $command_to_execute"
    
    output=`eval $command_to_execute`
    echo "output: $output"
}

command1='call_python.sh some_python_functions.printDelta bla'
command2='get_python_var.sh targetStore.lildevTargetStore'


command3='call_python.sh targetStore.getFoxtrott'

executeCommand $command3

