#!/bin/bash

for line in `cat alphabet.txt`; do
    echo $line
    
    if [[ $line =~ "foxtrott" ]]; then
        continue
    fi
    
    echo "BETWEEN"
done

