#-----------------------------------------------------------------------------#
#                                                                             #
#       Copyright (c) 2016, ASML Holding B.V. (including affiliates).         #
#                         All rights reserved                                 #
#                                                                             #
#-----------------------------------------------------------------------------#

class MdlTag(object):
    def __init__(self, tag):
        super(MdlTag, self).__init__()
        self.tag = tag

class MdlMarker(MdlTag):
    def __init__(self, tag, markerText, times = None):
        super(MdlMarker, self).__init__(tag)
        self.markerText = markerText
        self.times = times

class MdlDataTag(MdlTag):
    def __init__(self, tag, dataType, path=None, value=None, values=None, times=None):
        """ `value` is a list of values found by following `path` for each logged tag
        which (optionally) must be logged exactly `times` times.

        Following a path can result in more than one value if the path contains
        an array, in which case the path is continued for each value of the array.

        Alternatively, `values` is a list of a list of values; exactly one list
        per logged tag, where the elements in the list must be equal to the values
        found by following `path` for a logged tag.
        """
        assert (value is None and times is None) or values is None
        super(MdlDataTag, self).__init__(tag)
        self.dataType = dataType
        self.path = path
        self.value = value
        self.values = values
        self.times = times
