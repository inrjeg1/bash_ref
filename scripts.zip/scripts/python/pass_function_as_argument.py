#!/usr/bin/env python

import tempfile

def function_a():
   function_b(tempfile.mkdtemp())


def function_b(tmp_path):
   print tmp_path
   

function_a()    


