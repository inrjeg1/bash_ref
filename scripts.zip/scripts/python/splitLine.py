#!/usr/bin/env python

def splitLine():
    myLine = ['AT_9.9.9.d-20190523_000000_lvl_at_qbl_NPI_sp14_integration_190603_172729-20190603_195335.tgz', 'AT_9.9.9.d-20190523_000000_lvl_at_qbl_NPI_sp14_integration_190603_172729-20190604_101821.tgz', 'AT_9.9.9.d-20190523_000000_lvl_at_qbl_NPI_sp14_integration_190603_172729-20190604_104906.tgz']

    print myLine[-1]

def splitMultiple():
    myLine = "alphaBRAVOcharlieDELTABRAVOECHOFOXTROTT"
    newLine = myLine.split("BRAVO", 1)[1]
    print newLine

#splitMultiple()
#splitLine()

def selectMultipleFields():
    myLine = "a/b/c/d/e"
    newLine = myLine.split('/')[0:1][0]
    print newLine
    
def allButLastElement():
    myLine = "a/b/c/d/e"
    newLine = "/".join(myLine.split('/')[:-1])
    print newLine
  #  anotherWay = myLine.rsplit(' ', 1)[0]
  #  print anotherWay
 
def allButFirstElement():
    myLine = "a/b/c/d/e"
    newLine = "/".join(myLine.split('/')[1:])
    print newLine
 
 
def multiLineString():
    myLine = """alpha
bravo
charlie"""
    myLine = myLine.split('\n')

    for line in myLine:
        print "l:", line
        
def customLine():
    oldPatchName = "exp/s2p/patch/scifuent/lvl_at_qbl_NPI_SP13_integration_120100_115224/AT_9.9.9.d-20190328_000000_lvl_at_qbl_NPI_SP13_integration_190430_115404-2019003841_103242.tgz"
    
    #projectName:  lvl_at_qbl_NPI_SP13_int
    projectName = "".join(oldPatchName.split("_integration")[0].split('/')[-1]) + "_int"
    
    print projectName


def fromNthElement():
    myString = "/alpha/bravo/charlie/delta/echo/foxtrott/golf/hotel"
    print "/".join(myString.split("/")[3:])
    

def splitSpecial():
    myString = "abc'def'ghi'jkl'mno'pqr'stu'vwx'yz"
    print myString.split('\'')[3]
    print myString.split('\'')[4]


splitSpecial()
#fromNthElement()
    
#customLine()
#allButLastElement()

