#-----------------------------------------------------------------------------#
#                                                                             #
#       Copyright (c) 2016, ASML Holding B.V. (including affiliates).         #
#                         All rights reserved                                 #
#                                                                             #
#-----------------------------------------------------------------------------#

from MdlTags import MdlMarker, MdlDataTag

class LilMdlTags:
    # The start start test message contains an entity id between parenthesis.
    # Since the id is different for every run, only the starting ( is included here
    startTestMarkers = [MdlMarker('KM-C111', 'START - START TEST - MEASURE ('),
                        MdlMarker('KM-C113', 'END - START TEST - MEASURE')]

    finishTestMarkers = [MdlMarker('KM-C114', 'START - FINISH TEST - MEASURE'),
                         MdlMarker('KM-C115', 'END - FINISH TEST - MEASURE')]

    # The start start lot message contains an entity id between parenthesis.
    # Since the id is different for every run, only the starting ( is included here
    startLotMarkers = [MdlMarker('KM-C101', 'START - START LIL LOT - MEASURE ('),
                       MdlMarker('KM-C103', 'END - START LIL LOT - MEASURE')]

    finishLotMarkers = [MdlMarker('KM-C104', 'START - FINISH LIL LOT - MEASURE'),
                        MdlMarker('KM-C105', 'END - FINISH LIL LOT - MEASURE')]

    # The start start test message contains an entity id between parenthesis.
    # Since the id is different for every run, only the starting ( is included here
    measureWaferMarkers = [MdlMarker('KM-C201', 'START - START LIL WAFER - MEASURE ('),
                           MdlMarker('KM-C203', 'END - START LIL WAFER - MEASURE')]
    
    finishMeasureWaferMarkers = [MdlMarker('KM-C204', 'START - FINISH LIL WAFER - MEASURE'),
                                 MdlMarker('KM-C205', 'END - FINISH LIL WAFER - MEASURE')]
                           
    emsiMarkers = [MdlMarker('KM-C210', 'START - INLINE SPM CALIBRATION'),
                   MdlMarker('KM-C211', 'END - INLINE SPM CALIBRATION')]

    performStrokeMarkers = [MdlMarker('KV-C88D', 'START - PERFORM WM STROKE'),
                            MdlMarker('KV-C88F', 'END - PERFORM WM STROKE')]

    strokeToWamMarkers = [MdlMarker('KV-C58D', 'START - MODEL WZM'),
                          MdlMarker('KV-C58E', 'END - MODEL WZM')]
                  
    captureMarkers = [MdlMarker('KM-C216', 'START - CAPTURE'),
                      MdlMarker('KM-C217', 'END - CAPTURE')]

    horizontalStrokeMarkers = [MdlMarker('KM-CD41', 'START - HORIZONTAL STROKE'),
                               MdlMarker('KM-CD42', 'END - HORIZONTAL STROKE')]

    # Todo: Check for 'Start Test' : 'KM-C121' once MDL logging for this tag is fixed
    lsscStartTest = [MdlDataTag('KM-C121', 'kmliexxxtxlsscxlevel_start_test')]
    
    lsscMeasureWafer = [MdlDataTag('KM-C218', 'kmliexxxtxlsscxlevel_measure_wafer')]
    
    extCallConvertSetpointsWaferCapture = [MdlDataTag('KV-C8D0', 'kdxaxlevel_det_wafer_capture_params')]
    
    extCallRequestCapture = [MdlDataTag('KV-C8D2', 'lzlaxscan_request_capture')]
    
    extCallGetResultCapture = [MdlDataTag('KV-C8D3', 'lzlaxscan_get_result_capture')]
    
    extCallConvertSetpointsHorizontalStroke = [MdlDataTag('KV-C8D1', 'kdxaxwafermap_det_stroke_params_for_horizontal_stroke')]
    
    extCallRequestSpotToSpot = [MdlDataTag('KV-CDC0', 'lzlaxscan_request_spot_to_spot')]
    
    extCallGetHeightDataSpotToSpot = [MdlDataTag('KV-CDC1', 'lzdrxscan_get_height_data_spot_to_spot')]
    
    extCallGetResultSpotToSpot = [MdlDataTag('KV-CDC2', 'lzlaxscan_get_result_spot_to_spot')]
                               
    extCallRequestZmap = [MdlDataTag('KV-C8DA', 'lzlaxscan_request_zmap')]
    
    extCallGetResultZmap = [MdlDataTag('KV-C8DB', 'lzlaxscan_get_result_zmap')] 
    
    extCallGetDataZmap = [MdlDataTag('KV-C8DC', 'lzdrxscan_get_data_zmap')]
    
    extCallRequestApproveWaferForImmersion2 = [MdlDataTag('KV-C285', 'ihclximm_request_approve_wafer_for_immersion_2')]
    
    extCallGetFiwaZValue = [MdlDataTag('KV-C287', 'kvliwa_get_fiwa_z_value')]
    
    extCallGetGlobalWaferWedge = [MdlDataTag('KV-C288', 'kvliwa_get_global_wafer_wedge')]
    
    extCallGetBestGlobalWaferWedge = [MdlDataTag('KV-C289', 'kvliwa_get_best_global_wafer_wedge')]
    
    extCallSetMeasureSequenceEntityId = [MdlDataTag('KV-C28A', 'kvliwa_setMeasureSequenceEntityId')]

    extCallPutStrokePdgcData = [MdlDataTag('KV-C730', 'lzlaxscan_request_set_composed_pdgc_table_data'),
                                MdlDataTag('KV-C739', 'lzlaxscan_get_result_set_composed_pdgc_table_data')]
    
    extCallsPdgcApplication = [MdlDataTag('KV-C735', 'lzlaxscan_request_load_pdgc_table'),
                               MdlDataTag('KV-C736', 'lzlaxscan_get_result_load_pdgc_table'),
                               MdlDataTag('KV-C737', 'lzlaxscan_get_pdgc_data')]
  
    dataTagsForLevelingDomain = [MdlDataTag('KV-C11E', 'NominalUVLSGeometry'),
                                 MdlDataTag('KV-C11F', 'CalibratedUVLSGeometry'),
                                 MdlDataTag('KV-C120', 'CenterLSSpotToAAOffset'),
                                 MdlDataTag('KV-C121', 'WaferArea'),
                                 MdlDataTag('KV-C122', 'LevelingArea'),
                                 MdlDataTag('KV-C123', 'ServoingArea')]
                                 
    dataTagsForCaptureDomain = [
        MdlDataTag('KV-C8D5', 'CapturePlan'),
        MdlDataTag('KV-C8D8', 'CaptureMeasurementResult'),
        MdlDataTag('KV-C8E7', 'Capture'),
        MdlDataTag('KV-C8E8', 'CaptureMeasurement')
                                ]
    
    dataTagsForCaptureDomainForSosiSequence = [
        MdlDataTag('KV-C8D4', 'ExpectedCaptureZ'),
        MdlDataTag('KV-C8D6', 'CaptureStartPosition'),
        MdlDataTag('KV-C8D7', 'CaptureEndPosition'),
        MdlDataTag('KV-C8D9', 'CaptureGWW')
        ]
                                
    dataTagsForLsscDomain = [MdlDataTag('KV-CDCA', 'HorizontalStrokeMeasurement'),
                             MdlDataTag('KV-CDC3', 'HorizontalStrokeLookupTable'),
                             MdlDataTag('KV-CDC4', 'LSDriftCorrectionsModelingOptions'),
                             MdlDataTag('KV-CDC5', 'HorizontalStroke'),
                             MdlDataTag('KV-CDC6', 'HorizontalStrokePlan'),
                             MdlDataTag('KV-CDC7', 'HorizontalStrokeMeasurementResult'),
                             MdlDataTag('KV-CDC8', 'ModeledLevelSensorRy'),
                             MdlDataTag('KV-CDC9', 'LevelSensorDriftCorrection')]
                             
    dataTagsForPDS2SODomain = [MdlDataTag('KV-CDCB', 'PDS2SOModelingOptions'),
                               MdlDataTag('KV-CDCC', 'PDS2SOCorrections'),
                               MdlDataTag('KV-CDCD', 'PDS2SOStrokeOptionsMcs')]

    dataTagsForTwinscanCoreDomain = [MdlDataTag('KV-C125', 'Task'),
                                     MdlDataTag('KV-C209', 'LogicalWafer'),
                                     MdlDataTag('KV-C20A', 'Chuck')]
    
    dataTagsForMeasureSequenceDomain = [MdlDataTag('KV-C207', 'MeasureSequence'),
                                        MdlDataTag('KV-C208', 'MeasureWaferRequest')]
    
    dataTagsForMeasureSequenceDomainForSosiSequence = [MdlDataTag('KV-C20B', 'MeasurementActionFlags')]
                                     
    dataTagsForRecipeDomain = [MdlDataTag('KV-C126', 'ImageSettings'),
                               MdlDataTag('KV-C127', 'ProductImageSettings'),
                               MdlDataTag('KV-C128', 'ReticleImageSettings'),
                               MdlDataTag('KV-C129', 'FieldSettings'),
                               MdlDataTag('KV-C12A', 'CdFec'),
                               MdlDataTag('KV-C12B', 'Rec'),
                               MdlDataTag('KV-C12C', 'Lsc'),
                               MdlDataTag('KV-C12D', 'FwolSettings')]
                               
    dataTagsForWafermapDomain = [MdlDataTag('KV-C8DD', 'Wafermap'),
                                 # MdlDataTag('KV-C8DE', 'WzmStrokesPlan'), //TODO: should be fixed by LM-22
                                 MdlDataTag('KV-C8DF', 'WzmStartPosition'),
                                 MdlDataTag('KV-C8E0', 'WzmEndPosition'),
                                 MdlDataTag('KV-C8E1', 'WafermapStrokeMeasurement'),
                                 MdlDataTag('KV-C8E2', 'WzmStrokeScanRequest'),
                                 MdlDataTag('KV-C8E3', 'WafermapStrokeMeasurementResult'),
                                 MdlDataTag('KV-C8E4', 'WafermapMeasurement'),
                                 MdlDataTag('KV-C8F2', 'PeriodJumpDetection3Mcs'),
                                 MdlDataTag('KV-C8F3', 'GwwMcs'),
                                 MdlDataTag('KV-C8F4', 'LILWZMStrokesOptions'),
                                 MdlDataTag('KV-C8F5', 'WzmStrokeGww'),
                                 MdlDataTag('KV-C8F7', 'WzmStrokePositions'),
                                 MdlDataTag('KV-C8F9', 'Stroke'),
                                 MdlDataTag('KV-C8FA', 'StrokeDefinitionInfo'),
                                 MdlDataTag('KV-C8FB', 'MeasurementGrid'),
                                 MdlDataTag('KV-C8FC', 'ServoSpotSwitchTable'), 
                                 MdlDataTag('KV-C8FD', 'MeasurementSpotSwitchTable') 
                                 ]
    
    dataTagsForStrokeToWamDomain = [MdlDataTag('KV-C8E5', 'MeasuredWam'),
                                    MdlDataTag('KV-C8E6', 'Wam'),
                                    # MdlDataTag('KV-C8F1', 'WafermapGww'), logging not triggered by the integration test
                                    # MdlDataTag('KV-C8EC', 'LsDataCheckMcs'), we don't instantiate this entity yet
                                    MdlDataTag('KV-C8ED', 'ConstructFieldWamsMcs'),
                                    MdlDataTag('KV-C8EE', 'CalculateMeanFieldMcs'),
                                    MdlDataTag('KV-C8EF', 'WafermapInfo'),
                                    # MdlDataTag('KV-C8F8', 'PDCorrectionMap'), we don't instantiate this entity yet
                                    MdlDataTag('KV-C8F0', 'EflResult')
                                    ]

    dataTagsForWaferSafetyCheckDomain = [MdlDataTag('KV-C004', 'MirrorBlockMcs'),
                                         MdlDataTag('KV-C005', 'ImmersionHoodHoveringMcs'),
                                         MdlDataTag('KV-C8EB', 'WaferHeightRange')]
                                         
    dataTagsForWaferAlignmentDomain = [# MdlDataTag('KV-C904', 'FiwaMeasurementRequest'), we don't instantiate this entity yet
                                       MdlDataTag('KV-C905', 'FiwaInFocusMcs')
                                       ]
                                        
    dataTagsForStageAlignmentDomain = [MdlDataTag('KV-C314', 'ParisPlateShapeMeasurementMcs'),
                                       MdlDataTag('KV-C315', 'ZeroJumpDetection'),
                                       MdlDataTag('KV-C316', 'StageAlignmentMeasurement'),
                                       MdlDataTag('KV-C317', 'StageAlignmentMeasurementRequest')]

    dataTagsForStageAlignment = [MdlMarker('KM-C304', 'QUEUE STAGE LEVEL (iVSA) SCAN', times = 1),
                                 MdlMarker('KM-C41C', 'QUEUE PARIS STAGE ALIGNMENT (PSA) SCAN'),
                                 MdlDataTag('KM-C323', 'KMSAxLOG:seq_info_t', 
                                       path='dat.level.scans_array[*].expected', 
                                       value=[0, 0, 3]),
                                 MdlDataTag('KM-C323', 'KMSAxLOG:seq_info_t', 
                                       path='dat.level.scans_array[*].queued', 
                                       value=[0, 0, 3]),
                                 MdlDataTag('KM-C323', 'KMSAxLOG:seq_info_t', 
                                       path='dat.level.scans_array[*].retrieved', 
                                       value=[0, 0, 3]),
                                 MdlDataTag('KM-C323', 'KMSAxLOG:seq_info_t', 
                                       path='dat.level.scans_array[*].stored', 
                                       value=[0, 0, 3]),
                                 MdlDataTag('KM-C323', 'KMSAxLOG:seq_info_t', 
                                       path='dat.level.scans_array[*].cleaned', 
                                       value=[0, 0, 0]),
                                 MdlDataTag('KM-C323', 'KMSAxLOG:seq_info_t', 
                                       path='dat.level.modeled', 
                                       value='TRUE'),
                                 MdlDataTag('KM-C323', 'KMSAxLOG:seq_info_t', 
                                       path='dat.psa.scans.expected'),
                                 MdlDataTag('KM-C323', 'KMSAxLOG:seq_info_t', 
                                       path='dat.psa.scans.queued'),
                                 MdlDataTag('KM-C323', 'KMSAxLOG:seq_info_t', 
                                       path='dat.psa.scans.retrieved'),
                                 MdlDataTag('KM-C323', 'KMSAxLOG:seq_info_t', 
                                       path='dat.psa.scans.stored'),
                                 MdlDataTag('KM-C323', 'KMSAxLOG:seq_info_t', 
                                       path='dat.psa.scans.cleaned', 
                                       value=0),
                                 MdlDataTag('KM-C323', 'KMSAxLOG:seq_info_t', 
                                       path='dat.psa.modeled', 
                                       value='TRUE'),
                                 MdlDataTag('KM-C323', 'KMSAxLOG:seq_info_t', 
                                       path='dat.xlevel.scans_array[*].queued', 
                                       value=[0,0]),
                                 MdlDataTag('KM-C323', 'KMSAxLOG:seq_info_t', 
                                       path='dat.align.scans_array[*].queued', 
                                       value=[0,0]),
                                 MdlDataTag('KM-C323', 'KMSAxLOG:seq_info_t', 
                                       path='dat.xalign.scans_array[*].queued', 
                                       value=[0,0]),
                                 MdlDataTag('KM-C323', 'KMSAxLOG:seq_info_t', 
                                       path='dat.psm.scans.queued', 
                                       value=0)
                                 ]
    
    dataTagsForStageAlignmentWithZeroJump = [
                                 MdlMarker('KM-C304', 'QUEUE STAGE LEVEL (iVSA) SCAN'),
                                 MdlMarker('KM-C41C', 'QUEUE PARIS STAGE ALIGNMENT (PSA) SCAN')
                                 #TODO: Check proper tags with FT            
                                 ]
    
    dataTagsForCustomStrokes = [MdlDataTag('KV-C130', 'CustomStrokesPlan'),
                                MdlDataTag('KV-C131', 'PerformanceResult'),
                                MdlDataTag('KV-C132', 'CustomStrokeMeasurementResult'),
                                MdlDataTag('KV-C11E', 'NominalUVLSGeometry'),
                                MdlDataTag('KV-C121', 'WaferArea')
                                ]

    dataTagsForPdgc = [MdlDataTag('KV-C731', 'HorizontalStrokePdgm'),
                       MdlDataTag('KV-C732', 'FieldPdgm'),
                       MdlDataTag('KV-C733', 'CorrectionIdentifier'),
                       MdlDataTag('KV-C734', 'PdgcApplication')
                       #TODO: This tag should be enabled by LM-46
#                        MdlDataTag('KV-C738', 'VerticalStrokePDGM')
                       ]

    tagsForLSSC = (startTestMarkers +
                  finishTestMarkers +
                  measureWaferMarkers +
                  finishMeasureWaferMarkers +
                  emsiMarkers +
                  captureMarkers +
                  horizontalStrokeMarkers +
                  lsscMeasureWafer +
                  extCallConvertSetpointsHorizontalStroke +
                  extCallRequestCapture +
                  extCallGetResultCapture +
                  extCallRequestSpotToSpot +
                  extCallGetResultSpotToSpot +
                  extCallGetHeightDataSpotToSpot +
                  dataTagsForLevelingDomain +
                  dataTagsForCaptureDomain +
                  dataTagsForTwinscanCoreDomain +
                  dataTagsForMeasureSequenceDomain +
                  dataTagsForLsscDomain)

    tagsForLot = (startLotMarkers +
                 finishLotMarkers + 
                 measureWaferMarkers +
                 finishMeasureWaferMarkers +
                 emsiMarkers +
                 captureMarkers +
                 performStrokeMarkers +
                 strokeToWamMarkers +
                 extCallConvertSetpointsWaferCapture +
                 extCallRequestCapture +
                 extCallGetResultCapture +
                 extCallRequestZmap +
                 extCallGetResultZmap +
                 extCallGetDataZmap +
                 extCallRequestApproveWaferForImmersion2 +
                 extCallGetFiwaZValue +
                 extCallGetGlobalWaferWedge +
                 extCallSetMeasureSequenceEntityId +
#                  extCallPutStrokePdgcData +
                 extCallGetBestGlobalWaferWedge +
                 dataTagsForLevelingDomain +
                 dataTagsForCaptureDomain +
                 dataTagsForCaptureDomainForSosiSequence +
                 dataTagsForTwinscanCoreDomain +
                 dataTagsForMeasureSequenceDomain +
                 dataTagsForMeasureSequenceDomainForSosiSequence +
                 dataTagsForRecipeDomain +
                 dataTagsForWafermapDomain +
                 dataTagsForWaferSafetyCheckDomain +
                 dataTagsForStrokeToWamDomain +
                 dataTagsForWaferAlignmentDomain +
                 dataTagsForPDS2SODomain +
#                  dataTagsForPdgcDomainForEveryLot +
                 dataTagsForStageAlignmentDomain)
    
    tagsForCustomStrokes = (dataTagsForCustomStrokes +
                            dataTagsForTwinscanCoreDomain)
