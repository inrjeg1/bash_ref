#!/usr/bin/env python

def checkBool():
    a = False
    b = True
    
    if not a:
        print "NOT a"
    if a:
        print "a"
    if not b:
        print "NOT b"
    if b:
        print "b"

checkBool()
