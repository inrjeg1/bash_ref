

def  createStuctWithValues():
    my_struct = (34, 324, 2397)
    
    
    print my_struct
    


createStuctWithValues()


