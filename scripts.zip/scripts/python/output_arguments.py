#!/usr/bin/env python


def change_inputs(a, b):
   a = 5
   b = 8
   
   
def call_with_inputs():
   c = 0
   d = 0
   change_inputs(c, d)
   print "a: ", c, "b: ", d
   
   
call_with_inputs()


