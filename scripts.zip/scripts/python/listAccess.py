
def createList():

    a = list()
    a.append(4)
    a.append(6)
    
    print(a[1])
    
    message = "ABCDEF"
    
    print message
    
createList()


