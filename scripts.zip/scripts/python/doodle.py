#!/usr/bin/env python

import os



def get_view_name():
    """
    Returns the view-name, if we are in the view context
    If outside the view context an empty string.
    """
    return os.environ.get('CLEARCASE_ROOT','').replace('/view/','')

print get_view_name()
