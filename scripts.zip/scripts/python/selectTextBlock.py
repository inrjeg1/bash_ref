#!/usr/bin/env python

import re

f = open('dummy.txt', 'r+')

content = f.read()

target = re.search('X86CPPTARGET.*\n\nX86CPPTARGETSOL', content, re.DOTALL)

a = target.string[target.start():target.end()].split('\n\n')

print a[0]
