#!/usr/bin/env python

def appendToListOfTuples(tupleList, argument):
    tupleList.append(argument)
    return tupleList

def createListOfTuples():
    return []

myList = createListOfTuples()
myArg1 = ("alpha", 1)
myArg2 = ("bravo", 2)
myList = appendToListOfTuples(myList, myArg1)
myList = appendToListOfTuples(myList, myArg2)

print myList


b = {}

print b

