#!/usr/bin/env python

import re

def testRawInput():
    myString = "  The quick brown     fox  jumps    "
    newString =  re.sub('\s+', ' ', myString)
    print "NEW STRING:", newString
    
    if "The quick brown fox jumps" == re.sub('\s+', ' ', myString).rstrip():
        print "EQUAL"
    else:
        print "NOT EQUAL"

    if newString == myString:
        print "EQUAL"
    else:
        print "NOT EQUAL"

if __name__ == "__main__":
    testRawInput()
