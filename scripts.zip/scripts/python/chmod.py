#!/usr/bin/env python

import os, stat

def makeWritable():
    os.chmod('dummy.txt', 0775)


makeWritable()

