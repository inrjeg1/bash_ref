#!/usr/bin/env python

def check_if_last_line_is_empty():
   with open("file_last_line_NOT_empty.mk_copy") as makefile:
      i = 0
      for line in makefile:
         i += 1
         pass
      print i
      last_line = line
      
      print last_line
   
      if not last_line.strip():
         print "EMPTY"
      else:
         print "NOT EMPTY"

      if "\n" in last_line:
         print "OK"
      else:
         print "NOT OK"


check_if_last_line_is_empty()

