#!/usr/bin/env python


class myClass():
    def __init__(self, myListArg = []):
        self.myList = myListArg
        
    def run(self):
        self.myList.append('x-ray')
        

someList = []
myClass(someList).run()
print someList


