#!/usr/bin/env python

from common import addItemToDictionary

def parseScopefile():
    interfaceContentsClearcase = {}
    with open ("scopefilePart.txt") as f:
        lines = f.readlines()
        insideInterfaceOrComponent = False
        for line in lines:
            if "interface " in line or "component " in line:
                   insideInterfaceOrComponent = True
                   interfaceOrComponentName = line.strip().split()[1]
            if insideInterfaceOrComponent:
                if '}' in line:
                    insideInterfaceOrComponent = False
                elif ("contains" in line or 
                     "source" in line or 
                     "requires" in line):
                        containsSourceRequires = line.strip().split()[0]
                        target = line.strip().split()[1]
                        addItemToDictionary(interfaceContentsClearcase, interfaceOrComponentName, (containsSourceRequires, target))
    for interfaceOrComponent in interfaceContentsClearcase:
        print "\n===",interfaceOrComponent, "==="
        for (contains, target) in interfaceContentsClearcase[interfaceOrComponent]:
            if (contains  == "requires"):
                print contains, target



if __name__ == "__main__":
    parseScopefile()
