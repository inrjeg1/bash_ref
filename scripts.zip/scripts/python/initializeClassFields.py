#!/usr/bin/env python

from collections import namedtuple

def functionToPassTo(someMcs):
    print someMcs.charlie
    

def initializeClassFields():
    class MCs : pass
    mcs = MCs()
    mcs.alpha = 2
    mcs.bravo = 3
    mcs.charlie = 4
    mcs.delta = 5

    functionToPassTo(mcs)


if __name__ == "__main__":
    initializeClassFields()


