#!/usr/bin/env python


def listOperations():
   myList = []
   print dir(myList)

 #  for i in range (0, 10):
 #     myList.append(returnThree(i))

   print myList
   print len(myList)
   
   a = [1, 2, 3]
   b = ["abc", "de", "fgh"]
   c = []
   c += a
   c += b
   c.append("alpha")
  # c.append(b)
   print (c)
#   print (c[1])
#   print (c[1][1])

def returnThree(number):
   if number > 5:
      return 3
   
def returnFive():
   return 5

def createList():
    a = ['a', 'b']
    print a
    if (not 'c' in a and
        not 'd' in a):
        print "Yes"


def appendToList():
    a = []
    a.append("ALPHA")
    a.append('c')
    print a
    for item in a:
        print item

def createDictionary():
    a = {}
    a['alpha'] = 'a'
    a['bravo'] = 'b'
    a['charlie'] = 'c'
    a['delta'] = 'd'
    a['echo'] = 'e'
    
    for key in a:
        print "key: ", key
        print  "value: ", a[key]        
    

def getListSize():
    a = [u'atNXT2000_advanced_IFPC_integration_180514_012424', u'at_qblr007_integration_180509_161350']
    print a[len(a) -1]


def checkListContains():
    myList = [0.0, 0.0, 2.8, 9.3, 0.02, 0.0, 0.3]
    myList2 = [
      -1.9646031711374205e-06,
      6.8993392811561808e-08,
      4.2078397613957817e-09,
      3.9481064519979515e-06,
      -1.7390665513607787e-09,
      3.807103423984856e-10,
      -1.3772010699328338e-07,
      -7.5560324389239883e-09,
      -2.7421936051675319e-06,
      -6.8415100112571161e-10,
      -1.2623921453351957e-10,
      1.35036777239727e-08,
      1.4281465932048333e-09,
      7.677311701045143e-08,
      6.4664845031871422e-09,
      8.0748980840137438e-07,
      7.6989327849331186e-10,
      -5.764322966397062e-10,
      0.0,
      2.1247874614779992e-09
    ]
    
    #print len([x for x in myList if not x == 0.0])
    #print len([x for x in myList2 if not x == 0.0])
    
    myList3 = ["alpha", "bravo", "charlie"]
    if "alpha" in myList3:
        print "alpha is present"
    if "al" in myList3:
        print "al is present"
    else:
        print "al is not present"
    
    
def addByReference(a):
    a.append("alpha")


def callAddByReference():
    a = []
    addByReference(a)
    print a
    

def printListItems(someList):
    for i in someList:
        print i

def passListAsArgument():
    myList = ['alpha', 'bravo', 'charlie']
    printListItems(myList)


def createListFromFile():
    myList = []
    filePath = './dummy.txt'
    with open(filePath, "r") as f:
        for line in f:
            myList.append(line.strip())
    print myList


def checkWhetherListIsEmpty():
    myList = []
    myList.append("a")
    myList.append("b")
    
    if myList:
        print "Not empty\n", myList
    else:
        print "Empty"    
    

def addIfRequirementIsMet():
    mySet = set({})
    myList = ["alpha", "bravo", "charlie", "delta", "echo", "foxtrott", "golf", "hotel", "india", "juliet", "kilo", "lima", "mike", "november", "oscar", "papa", "quebec", "romeo", "sierra", "tango", "uniform", "victor", "whisky", "x-ray", "yankee", "zulu"]
    
    for item in myList:
        print "item", item
        listItems = [char for char in item if char is not "a"]
        print "listItems", listItems
        for i in listItems:
            print "i:", i
            mySet.add(i)
        print "mySet:", mySet
    print mySet
    

def checkIfListIsEmpty():
    #from clearcase import exec_shell_command
    #allCheckouts = exec_shell_command('cleartool lsco -avobs -cview -s')
    #if allCheckouts:
    #    print "\nERROR: There are still checkouts in your view!"
    #    print " --> " + "\n --> ".join(allCheckouts) + "\n"
    myList = []
    print bool(myList)
    

def removeEmptyStringFromList():
    myList = []
    myList.append('alpha')
    myList.append('bravo')
    myList.append('')
    print myList
    myList = filter(None , myList)
    print myList
    
 
def appendIfNotEmpty():
    myString = "alpha\nbravo\ncharlie\n"
    print myString  
    myList = [line for line in myString.split('\n') if not(line == '')]
    print myList
    
    
def stringToList():
    myString = ("alpha bravo\n"
                "charlie delta")
    print myString
    print myString.splitlines()
    

def checkSameListMultipleTimes():
    myList = ['uniform', 'victor', 'whisky', 'x-ray', 'yankee', 'zulu']
    
    print any('x' in item for item in myList) and not(any('q' in item for item in myList))
    for item in myList:
        print "I2:", item

def checkSomeOtherListMultipleTimes():
    with open ("/home/ptacken/public/ccdeliver_complete_output_tmp") as f:
        myList = [line.strip() for line in f.readlines()]
        print myList
        if not (any("cccheck_scope: Exitcode: 0" in x for x in myList) and
               any("ccupd_bldenv: Exitcode: 0" in x for x in myList)):
            print "NOT"



removeEmptyStringFromList()
#checkSomeOtherListMultipleTimes()
#checkSameListMultipleTimes()
#stringToList()
#appendIfNotEmpty()
#removeEmptyStringFromList()
#checkIfListIsEmpty()
#addIfRequirementIsMet()
#checkWhetherListIsEmpty()
#createListFromFile()
#passListAsArgument()
#callAddByReference()
#checkListContains()
#listOperations()
#createList()
#appendToList()
#createDictionary()
#getListSize()
