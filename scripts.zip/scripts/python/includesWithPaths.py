#!/usr/bin/env python

import os

class fileLocator(object):

    def getCCRootPath(self, path):
        if '/' in path:
            return path.split('/')[0]
        else:
            return None

    def getIncludePathsForCC(self, component):
        ccIncLocations = ['com/ext/inc', 'com/ext/inc/bld', 'com/ext/lib',
                          'com/int/inc', 'com/int/inc/bld', 'com/int/lib',
                          'com/int/tst']
        bla =  [os.path.join(component, l) for l in ccIncLocations]
        print "INCLUDE PATHS: "
        print bla

    def fileLocation(self, fileName, potentialLocationDirectories):
        potentialLocations = [os.path.join(d, fileName)
                              for d in potentialLocationDirectories]
        for location in potentialLocations:
            if os.path.exists(location):
                print ('Location found:', location)
                return location
        return None

    def findFile(self, fileName, path):
        print ('findFile', ' File: ' + fileName + ' Path: ' + path)
        rootCC = self.getCCRootPath(path)
        if rootCC:
            searchDirectories = self.getIncludePathsForCC(rootCC)

        location = self.fileLocation(fileName, [path])
        if not location:
            print "HERE2"
            location = self.fileLocation(fileName, ['build/xifs-global'])
            if not location:
                print "HERE1"
                rootCC = self.getCCRootPath(path)
                if rootCC:
                    searchDirectories = self.getIncludePathsForCC(rootCC)
                    location = self.fileLocation(fileName, searchDirectories)
                    if not location:
                        print(fileName + ' FILE NOT FOUND')
                        return None
                else:
                    print(fileName + ' FILE NOT FOUND')
                    return None

        return location


class statics:
    boaComponents = []
    locator = fileLocator()
    verbose = False



includesOfInterest = [
"KMLIWAxEXCEPTION/duract_FunctionalExceptions.hpp",
"KMLIWAxEXCEPTION/duract_FunctionalExceptions.hpp",
"duract_SplitCowaMeasurement.hpp"]

def printIncludesWithPaths(fileName):
    includesWithPaths = [statics.locator.findFile(i, os.path.dirname(fileName))
                         for i in includesOfInterest]
    print "includes with paths:"
    print includesWithPaths                 
                         
printIncludesWithPaths("KMLIWA/com/ext/inc/duract_SplitCowaMeasurementFactory.hpp")

