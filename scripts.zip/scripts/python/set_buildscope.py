#!/usr/bin/env python

import logging
import re
import subprocess
import time


def exec_shell_command(cmd, view=None, raise_error=True):
   """ Execute a command in shell environment and return its output as array of strings
   Raises an exception if the exit status != 0
   Logs the output.
   
   :param cmd   The command to execute. Should not contain double quotes...
   :param view  If a view is given, the command is echo'ed and piped to ccset_view, to be executed in view.
   """
   output = []

   if "\'" in cmd:
      raise SystemError("command should not contain single quotes. "+str(cmd))

   if view:
      cmd = "echo '{}' | ccset_view {}".format(cmd, view)
   logging.getLogger(__file__).debug("Exec: "+cmd)

   ansi_escape_re = re.compile(r'\x1B\[[0-?]*[ -/]*[@-~]')
   process = subprocess.Popen(cmd,
                           shell=True,
                           stdout=subprocess.PIPE,
                           stderr=subprocess.STDOUT
                           )

   for line in iter(process.stdout.readline,''):
      line = line.strip()
      line = ansi_escape_re.sub('', line)
      # problematic log statement: it can generate ~1GB of data
#      logging.getLogger(__file__).debug(line)
      output.append(line)
      time.sleep(0) # yield to other thread

   returncode = process.wait()
   if raise_error and returncode != 0:
      raise SystemError("Error executing: " +cmd + " Output: " + str(output))
   return output


def get_buildscope(view_name=None, raw_format=False, parent=False):
    """ Returns the buildscope of the given view.
        ### from /sdev_shared/sics/DT/lib/asml/clearcase/clearcase.py

        :param view_name:        (Optional) The name of the view to get the
                                 buildscope from. If none given it expects that
                                 it is in a view_name.
        :type view_name:         str
        :param raw_format:       Raw output of ccget_buildscope is requested
        :type raw_format:        bool
        :return: buildscope:     The buildscope of the given view
        :rtype:                  str
    """
    
    cmd = 'ccget_buildscope'

    if parent:
        cmd = cmd + ' -p'
    if raw_format:
        cmd = cmd + ' -r'

    output = exec_shell_command(cmd, view_name)

    if raw_format:
        buildscope = "".join(output)
    else:
        buildscope = [x.split('/')[-1] for x in output]
    
    print buildscope
    return buildscope


def go_to_component(view, component):
    cmd = "cd `xcd " + component +"`"
    cmd = "echo '{}' | ccset_view {}".format(cmd, view)
    return subprocess.call(cmd, 
                           shell=True,  
                           stdout=subprocess.PIPE,
                           stderr=subprocess.STDOUT)


def filter_buildscope(view, buildscope, parent_buildscope):
    logging.getLogger(__file__).info("Filtering buildscope for view {}".format(" ".join(view)), view)
    newBuildscope = []
    for component in buildscope:
        if component in parent_buildscope and go_to_component(view, component) == 0:
            newBuildscope.append(component) 
            print newBuildscope
    return newBuildscope


#buildscope = get_buildscope('ptacken_lvl_at_qbl_IFPC_phase2_int', False)
buildscope = ['CMIM', 'EGTPEX', 'EMLPEN', 'EMTDMI', 'EMWC']
buildscope_parent = get_buildscope('ptacken_at7.3_dumbo_setBuildscope_int', parent = True)

buildscope = filter_buildscope('ptacken_at7.3_dumbo_setBuildscope_int', buildscope, buildscope_parent)
print "NEW BUILDSCOPE PARENT"
print buildscope


