#!/usr/bin/env python

class colors():
    TITLE = '\033[47m'
    FAILURE = '\033[31m'
    SUCCESS = '\033[42m'
    ERROR = '\033[43m'
    NEUTRAL = '\033[0m'


print colors.FAILURE
print "EXAMPLE"

print colors.NEUTRAL

