#!/usr/bin/env python

import sh
from common import printOutput, printPhase, getCurrentUserName, gem
import subprocess

def checkReturnCode():
    cmd = sh.Command('ls')
    try:
        output = cmd('-j')
        
    except Exception as e:
        print "error code", e
        print "output", output
        #pass
    #output = cmd('-1', '-a', _out=printOutput, _err="hello")


checkReturnCode()
