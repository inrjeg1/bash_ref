#!/usr/bin/env python

def goThroughForLoop():
    myList = ["ALPHA BRAVO CHARLIE", "DELTA ECHO FOXTROTT", "GOLF HOTEL INDIA"]
    for item in myList:
        print "ITEM: ", item
        for word in item.split(' '):
            
            if "B" in word:
                continue
            if "D" in word:
                return word
            print "word:", word
    
   
goThroughForLoop()
