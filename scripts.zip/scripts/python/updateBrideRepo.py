#!/usr/bin/env python

from urllib import 
import urllib2


def updateBridgeRepo():
    url = "http://nleidr087.sn-eu.asml.com:8080/job/LIL-dev-LDL_qualify_test/build"
        
    

updateBridgeRepo()
