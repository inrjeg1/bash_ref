#!/usr/bin/env python

import sh
import subprocess

from clearcase import exec_shell_command
from datetime import datetime
from common import  workingDirectory, printOutput, installFromCadenv


import json
import httplib
import time
import urllib
 
def dummyPost():
  #  r = requests.post("http://nleidr087.sn-eu.asml.com:8080/job/reposyncer_sync/buildWithParameters", data={'components':'KVLIPG%2CKVLIVT', 
#                                                                                                            'git_uri':'ssh%3A%2F%2Fgit%40boa-srm-eid%2Fmetlev%2Ftest_bridge_repo.git',
#                                                                                                            'callback_id':'12345','project_name':'METLEV','repository_name':'test_bridge_repo','notify':'gaston.smeets%40asml.com','reference':'myref','viewname':'EID%3Agsmeets_at_qblr007_dumbo_update_bridge_repo_int'})
   
#    params = urllib.urlencode({'components':'KVLIPG%2CKVLIVT', 
#                               'git_uri':'ssh%3A%2F%2Fgit%40boa-srm-eid%2Fmetlev%2Ftest_bridge_repo.git',
#                               'callback_id':'12345',
#                               'project_name':'METLEV',
#                               'repository_name':'test_bridge_repo',
#                               'notify':'gaston.smeets%40asml.com',
#                               'reference':'myref',
#                               'viewname':'EID%3Agsmeets_at_qblr007_dumbo_update_bridge_repo_int'})
#    headers={"Jenkins-Crumb": "78d2338105d9cff2aefeeb60bebb62cc", "Content-Type": "application/x-www-form-urlencoded"}

#    connection = httplib.HTTPConnection("nleidr084.sn-eu.asml.com")
   
    components = ','.join(['KVLIPG','KVLIVT'])
    print components
   
    params ={"git_uri":"ssh://git@boa-srm-eid/metlev/test_bridge_repo.git",
             "viewname":"EID:gsmeets_at_qblr007_dumbo_update_bridge_repo_int",
             "components":components,
             "project_name":"METLEV",
             "repository_name":"test_bridge_repo",
             "reference":"sync-tag-20180524.153258"}

    headers={"Host":"boa-srm.asml.com",
             "Content-Type":"application/json",
             "Authorization":"Basic Z3NtZWV0czpUZWFyZHJvcHMyMDE5IQ==",
             "Cache-Control":"no-cache"}

    connection = httplib.HTTPSConnection("boa-srm.asml.com")
    connection.request("POST", "/rest/reposyncer/1.0/sync/request.json", body=json.dumps(params), headers=headers)
    
    response = connection.getresponse()
    
    
    print response.status
    print response.reason
    responseInfo = response.read()
    jsonResponse = json.loads(responseInfo)
    jobUrl = jsonResponse["job_url"]
    print "Job URL: ", jobUrl
    callbackId = jsonResponse["callback_id"]

    status = ""
    while not status == "completed":
        connection.request("GET", "/rest/reposyncer/1.0/sync/status/"+callbackId+".json", headers=headers)
        status = json.loads(connection.getresponse().read())["status"]
        
        
        
       # response = connection.getresponse()
#        responseInfo = response.read()
#        jsonResponse = json.loads(responseInfo)
#        status = jsonResponse["status"]

        print "status: ",status
        time.sleep(10)
    
    print "DONE"


def createPullRequest():
    params ={"title": "Test PR GSME CC2BOA",
             "description": "Testing automation",
             "state": "OPEN",
             "open": "true",
             "closed": "false",
             "fromRef": {
                 "id": "refs/heads/test",
                 "repository": {
                     "slug": "test_bridge_repo",
                     "name": "test_bridge_repo",
                     "project": {
                         "key": "METLEV"
                     }
                 }
             },
             "toRef": {
                 "id": "refs/heads/master",
                 "repository": {
                     "slug": "test_bridge_repo",
                     "name": "test_bridge_repo",
                     "project": {
                         "key": "METLEV"
                     }
                 }
             },
             "locked": "false",
             "reviewers": [],
             "links": {
                 "self": [
                     "null"
                 ]
             }
         }


    headers={"Host":"boa-srm.asml.com",
             "Content-Type":"application/json",
             "Authorization":"Basic Z3NtZWV0czpUZWFyZHJvcHMyMDE5IQ==",
             "Cache-Control":"no-cache"}

    connection = httplib.HTTPSConnection("boa-srm.asml.com")
    connection.request("POST", "/rest/api/1.0/projects/METLEV/repos/test_bridge_repo/pull-requests", body=json.dumps(params), headers=headers)
    
    response = connection.getresponse()
    
    
    print response.status
    print response.reason
    print response.read()
    responseInfo = response.read()


createPullRequest()


#dummyPost()

