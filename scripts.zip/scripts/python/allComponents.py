#!/usr/bin/env python

def getAllComponents():

    configFile = "/boa_prd/ptacken/d/d/d/lil-1/.boa/config.yml"
    inListToUse = False
    componentList = []
    with open (configFile) as f:
        for line in f:
            line = line.strip()
            if "synced_components" in line:
                inListToUse = True
            elif inListToUse and ("- " in line):
                componentList.append(line.split(' ')[1])
    return componentList


if __name__ == "__main__":
    print getAllComponents()

