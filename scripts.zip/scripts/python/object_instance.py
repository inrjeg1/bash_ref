#!/usr/bin/env python

class SomeClass(object):
    def __init__(self):
          print("Constructed")
        

        
def createClassInstance():
    a = SomeClass()
    print dir((SomeClass()))
    PyObject *a

createClassInstance()

