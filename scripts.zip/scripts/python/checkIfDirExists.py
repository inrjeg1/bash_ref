#!/usr/bin/env python

import glob
import os


def _getPatchFile(newPatchPath):
    currentWd = os.getcwd()
    os.chdir(newPatchPath)
    tgzFile = glob.glob("*.tgz")[-1]
    os.chdir(currentWd)
    return newPatchPath+tgzFile



def checkPath():
    baselineName = "lvl_at_qbl_NPI_SP16_integration_191125_142150"
    featureIntegrator = "ptacken"
    newPatchPathRaw = "/exp/s2p/patch/"+featureIntegrator+"/"+baselineName
    newPatchPathTestpackages = newPatchPathRaw + "_M/"
    if os.path.isdir(newPatchPathTestpackages):
        newPatchPath = newPatchPathTestpackages
    else:
        newPatchPath = newPatchPathRaw +"/"

#    print "D:", newPatchPath
    print "New:", _getPatchFile(newPatchPath)


checkPath()


