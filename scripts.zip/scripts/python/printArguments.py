#!/usr/bin/env python

import sys

def printArguments():
    print "all arguments:"
    print sys.argv
    
    print "each separately:"
    for arg in sys.argv:
        print "argument: "
        print arg

#if __name__ == "__main__":
#    printArguments()


def main(argv):
    """
    Main routine.
    """
    print argv
    print('check_tics from cmdline')
    output = ""
    returncode = 0
   


if __name__ == '__main__':
    main(sys.argv[1:])
    
    
