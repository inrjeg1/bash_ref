#!/usr/bin/env python

import buildDependencyFileReader

mydata = buildDependencyFileReader.readBuildDependencyFile("buildDependencies.gradle")
print mydata.getProvidedInterface()





