#!/usr/bin/env python

import os
import re

def checkIfFileExists():
    
    path = "/sdev_shared/fc062data/PTAD/scripts/python/"
    
    if os.path.exists(path+'dummy.txt'):
        print "dummy exists"
    if os.path.exists('nonexisting'):
        print "ERROR"
    

def checkIfStringOccursInFile():
    if "quick brown" in re.sub('\s+', ' ', open("dummy.txt").read()):
        print "YES"
    else:
        print "NO"


def checkIfStringOccursInLine():
    line = "alpha            bravo"
    if "alpha bravo" in re.sub('\s+', ' ', line):
        print "line matches"
    else:
        print "line does not match"
    
    
checkIfStringOccursInLine()
#checkIfStringOccursInFile()

#checkIfFileExists()


