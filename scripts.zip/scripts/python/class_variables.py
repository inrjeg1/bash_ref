#!/usr/bin/env python


#class MyClass:
#   my_var = 0
#   my_bool = False
#   
#   def print_vars(self):
#      print MyClass.my_var
#      print MyClass.my_bool
#
#
#myclass = MyClass()
#myclass.print_vars()
#
#MyClass.my_bool = True
#myclass.print_vars()
#
#myotherclass = MyClass()
#myotherclass.print_vars()


class MyClassB:
    def __init__(self):
        self.alpha = 5
        self.bravo = "SIX"
    
    def changeClassVars(self):
        self.alpha = 6
        self.bravo = "SEVEN"
        
    def printVariables(self):
        print self.alpha
        print self.bravo

    def createNewVariables(self):
        self.charlie = 8
        self.delta = "NINE"
    
    def printNewVariables(self):
        print self.charlie
        print self.delta
        
    

#classBravo = MyClassB()
#classBravo.printVariables()
#classBravo.changeClassVars()
#classBravo.printVariables()
#classBravo.createNewVariables()
#classBravo.printNewVariables()


def someFunctionOutsideTheClass(someArgument):
#    print "a: ", someArgument
    someArgument = someArgument + 1
#    print "b: ", someArgument



class MyClassC:
    alpha = 0
    bravo = 0

    def __init__(self):
        self.alpha = 1
        self.bravo = 4
        self.charlie = 1
        self.delta = 5
    
    def callSomeFunctionOutsideTheClass(self):
#        print "ALL BEFORE:"
#        print self.alpha
#        print self.bravo
#        print self.charlie
#        print self.delta
#        print ""

        someFunctionOutsideTheClass(self.alpha)
        someFunctionOutsideTheClass(self.bravo)
        someFunctionOutsideTheClass(self.charlie)
        someFunctionOutsideTheClass(self.delta)

#        print ""
#        print "ALL AFTER:"
#        print self.alpha
#        print self.bravo
#        print self.charlie
#        print self.delta


def createClassC():
    myClassC = MyClassC()
    print myClassC.alpha
    print myClassC.delta
    myClassC.callSomeFunctionOutsideTheClass()
    myClassC.alpha = 8
    myClassC.delta = myClassC.delta + 1
    print myClassC.alpha
    print myClassC.delta
    


createClassC()
