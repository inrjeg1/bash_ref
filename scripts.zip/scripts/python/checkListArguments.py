#!/usr/bin/env python


from MdlTags import MdlMarker, MdlDataTag


def createMarker():
    a = [MdlMarker('KM-C304', 'QUEUE STAGE LEVEL (iVSA) SCAN', times = 1),
         MdlMarker('KM-C41C', 'QUEUE PARIS STAGE ALIGNMENT (PSA) SCAN')]

    print(a[0].times)

    b = a
    b[0].times = 5
    
    print(b[0].times)


#createMarker()


def extendList():
    a = {}
    a['alpha'] = ('zulu' +
                  'yankee' +
                  'x-ray' +
                  'whisky') 
    print(a['alpha'])

    a['bravo']=a['alpha'] + ('Uniform')

    print(a['bravo'])

#extendList()

class MdlTag(object):
    def __init__(self, tag):
        super(MdlTag, self).__init__()
        self.tag = tag

class MdlMarker(MdlTag):
    def __init__(self, tag, markerText, times = None):
        super(MdlMarker, self).__init__(tag)
        self.markerText = markerText
        self.times = times

class StageAlignmentMdlTags:
    tagsForStageAlignment = [
        MdlMarker('KM-C304', 'QUEUE STAGE LEVEL (iVSA) SCAN', times=1),
        MdlMarker('KM-C41C', 'QUEUE PARIS STAGE ALIGNMENT (PSA) SCAN')]


def testWithClass():
    stageAlignmentTags = StageAlignmentMdlTags().tagsForStageAlignment
    stageAlignmentTags[0].times = 8

    print(stageAlignmentTags[0].markerText)
    print(stageAlignmentTags[0].times)
    
    
testWithClass()
