#!/bin/bash

#-----------------------------------------------------------------------------#
#                                                                             #
#       Copyright (c) 2017, ASML Holding N.V. (including affiliates).         #
#                         All rights reserved                                 #
#                                                                             #
#-----------------------------------------------------------------------------#

devbenchName=$1

if [ $# -gt 1 ]; then
  CONFIGURATION=$2
else
  CONFIGURATION="NXT:1980Di"
fi

if [ $# -gt 2 ]; then
  TEST_CONFIGURATION=$3
else
  TEST_CONFIGURATION="default"
fi

echo "================================"
echo "REMOVING DEVBENCH (IF EXISTS)..."

devbench lnxexec -X -e $devbenchName "KT/tstpkg/KT_system_stop -sf; /sdev/user/sbin/kill_atlas; /usr/asm/atl.0000/bin/sun/install/asm_upgrade_const -o SYSTEM_STOP -s"
devbench remove -d $devbenchName

#--- Failure interception part -----------------------------------------------#

abort()
{
  echo "=== ERROR DETECTED"

  exit 1
}
trap 'abort' 0    # traps the 0 (exit) signal and calls abort function
set -e

#--- Creation ----------------------------------------------------------------#

echo "===================="
echo "CREATING DEVBENCH..."

devbench create -B at_qblr007_integration_180425_154250 -M $CONFIGURATION -t $TEST_CONFIGURATION -a $devbenchName
devbench exec -X -e $devbenchName "sudo -i asml_patch install /exp/s2p/patch/acilio/lvl_at_qbl_integration_180502_110438/AT_9.9.9.d-20180424_000000_lvl_at_qbl_integration_180502_110438-20180502_131413.tgz"
devbench exec -X -e $devbenchName "sudo -i asml_patch install /exp/s2p/patch/jarsande/iFPC_QBL/AT_9.9.9.d-20171019_000000_iFPC_QBL-20171030_105228.tgz"
devbench exec -X -e $devbenchName "sudo -i asml_patch install /exp/s2p/patch/ptacken/lvl_at_qbl_IFPC_phase2_integration_180507_130418/AT_9.9.9.d-20180412_000000_lvl_at_qbl_IFPC_phase2_integration_180507_130418-20180516_161035.tgz"
devbench exec -X -e $devbenchName "asm_upgrade_config -o O -r R"

#--- Stopping failure interception -------------------------------------------#
trap : 0    # stop trapping

