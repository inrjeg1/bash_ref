#!/usr/bin/env python

import re
import time

def checkTextForString():
    delay = 20
    with open ("dummy.txt") as dummyFile:
        for _ in range(delay):
            if "qube" in dummyFile.read():
                print "true"
            else:
                print "false"
                time.sleep(1)


def ignoreNumberOfSpaces():
    with open ("dummy.txt") as f:
        for line in f:
            if "the{quick" in line.replace(" ", ""):
                print line 
        
#ignoreNumberOfSpaces()
#checkTextForString()


def checkForDifferentTypesOfChars():
#    includedInterfaces = []
#    interfacePattern = re.compile("[A-Z]x[A-Z]")
#    onlyAlpha = re.compile('["< ]')
#    fileName = "data_garage_CaptureGwwStoreGarage.hpp"
#    with open (fileName) as f:
#        for line in f:
#            if (line.startswith("#include") and 
#                "/" in line):
#                interfaceDependency = line.split('/')[0].replace("#include","")
#                interfaceDependency = onlyAlpha.sub("", interfaceDependency)
#
#               # if interfacePattern.search(interfaceDependency):
#                if not (interfaceDependency in includedInterfaces):
#                    includedInterfaces.append(interfaceDependency)
#
#    print '\n'.join(includedInterfaces)
    

    myStrings = []
    myStrings.append("ALPH/AxBRAVO")
    myStrings.append("CHARLIExdELTA")
    myStrings.append("ECHoxF//OXTROTT")
    myStrings.append("gol/Fxhotel")
    myStrings.append("IxJ")
    
    for s in myStrings:
        pattern = re.compile("[A-z]/[A-z]")
        matchResult = pattern.search(s)
        if matchResult:
            print matchResult.string

checkForDifferentTypesOfChars()

