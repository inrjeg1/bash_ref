#!/usr/bin/env python

import re
import sys

INTERNAL_INTERFACES = []

#def fillInternalInterfaces(buildDepVersionsFile):
#    internalPart = False
#    with open (buildDepVersionsFile) as f:
#        for line in f:
#            if internalPart:
#                if "}" in line:
#                    internalPart = False
#                else:
#                    m = re.search('version\(\'(.+?)\',', line)
#                    if m:
#                        print "I", m.group(1)
#                        INTERNAL_INTERFACES.append(m.group(1))
#                        
#            elif "internalDependencies" in line:
#                internalPart = True
#
#fillInternalInterfaces('buildDependenciesVersions.gradle')

#print INTERNAL_INTERFACES
  
line = "version('VELIRFxPROF', '1-u0')"
line2 = "version('VELIRFxPROF_2', '1-u0', ojodjf)"

m = re.search('version\(\'(.+?)\',', line2)
if m:
    print "I", m.group(1)
    INTERNAL_INTERFACES.append(m.group(1))




#m = re.search('version\(\'(.+?)\',', line2)
#if m:
#    print "I", m.group(1)
#    INTERNAL_INTERFACES.append(m.group(1))
    
if __name__ == "__main__":
    if len(sys.argv) == 2:
        print sys.argv[1]    

