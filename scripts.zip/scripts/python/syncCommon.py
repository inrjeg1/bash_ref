#!/usr/bin/env python
#-----------------------------------------------------------------------------#
#                                                                             #
#       Copyright (c) 2018, ASML Holding N.V. (including affiliates).         #
#                         All rights reserved                                 #
#                                                                             #
#-----------------------------------------------------------------------------#

import glob
import os
import re
import sh
import subprocess

def getClearcaseViewFromBoa(boaPath):
    print "=== Getting Clearcase view from config.yml ==="
    clearcaseView = ""
    with open (boaPath+'/.boa/config.yml') as f:
        for line in f:
            if "view_name" in line:
                clearcaseView = line.split(":")[2].strip()
    return clearcaseView
    
def getRepositoryName(boaPath):
    print "=== Getting repository name from config.yml ==="
    with open (boaPath+'/build.gradle') as f:
        for line in f:
            if "group" in line and "METLEV" in line:
                repositoryName = line.split(".")[1].split("'")[0].strip()
                break
        return repositoryName


#print getRepositoryName("/boa_prd/ptacken/lil-development")

def getLastSyncTag(gitInstance):
    print "=== Fetching tags ==="
    gitInstance(['fetch', '--tags'])
    allTags = gitInstance(['tag'])
    syncTag = subprocess.Popen('echo  "%s" | grep sync-tag- | tail -1 | sed "s/ //g"' % allTags, 
                               shell=True, 
                               stdout=subprocess.PIPE).stdout.read().strip()     
    return syncTag

boaPath = "/boa_prd/ptacken/cc2boa2cc_testing"
git = sh.git.bake(_cwd=boaPath, _tty_out=False)
#print getLastSyncTag(git)

def getBoaComponents():
    componentFolders = glob.glob('*/com')
    component_re = re.compile('([A-Z]+)/com')
    return [component_re.match(componentFolder).group(1)
            for componentFolder in componentFolders]

currentWd = os.getcwd()
os.chdir(boaPath)
componentList = ','.join(getBoaComponents())
print componentList
os.chdir(currentWd)

