#!/usr/bin/env python


def getMachineArchitecture():
    cmd = "emcf_view -i MACHINE_ARCHITECTURE"
    print subprocess.check_output(cmd)

if __name__ == "__main__":
    getMachineArchitecture()



