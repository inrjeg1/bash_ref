#!/usr/bin/env python
#-----------------------------------------------------------------------------#
#                                                                             #
#       Copyright (c) 2019, ASML Holding N.V. (including affiliates).         #
#                         All rights reserved                                 #
#                                                                             #
#-----------------------------------------------------------------------------#

import argparse
import clearcase
import getComponent
import getInterface
import os
import re
import subprocess


def addUniqueItemToDictionary(dictionary, key, value):
    if key in dictionary:
        if not any(item == value for item in dictionary[key]):
            dictionary[key].append(value)
    else:
        dictionary[key] = [value]


def checkFileNameClearcase(viewName, fileName):
    output = clearcase.go_to_component(viewName, fileName)
    if output == 0:
        return fileName
    elif (len(fileName) > 1):
        return checkFileNameClearcase(viewName, fileName[:-1])


def fileIsPresentInMakefile(pathToDir, fileName):
    os.chdir(pathToDir)
    findResult = subprocess.Popen('find . -maxdepth 1 -type f -name "makefile*" \
                                      | xargs grep -H -n ' + fileName + ' | grep TARGET \
                                      | head -1',
                                            shell=True,
                                            stdout=subprocess.PIPE).stdout.read().strip()
    return findResult
    

def componentContainsFile(viewName, componentName, fileName):
    pathToComponent = subprocess.check_output(['/sdev/user/bin/xcd', componentName]).strip()
    print "path to component: " + pathToComponent
    if fileName.endswith(".so"):
        pathToDir = pathToComponent + "/com/ext/lib/"
        return fileIsPresentInMakefile(pathToDir, fileName)
    elif ("typ.h" in fileName) or ("met.h" in fileName):
        pathToDir = pathToComponent + "/com/ext/inc/"
        return fileIsPresentInMakefile(pathToDir, fileName)
    elif fileName.endswith(".h") or fileName.endswith(".hpp"):
        fullFileName = pathToComponent + "/com/ext/inc/" + fileName
        return os.path.isfile(fullFileName)
    else:
        print "ERROR: unknown file extension, expected: .so, .h or .hpp"
        exit(1)
        

def guessComponentName(viewName, componentName, fileName):
    output = clearcase.go_to_component(viewName, componentName)
    if output == 0:
        if componentContainsFile(viewName, componentName, fileName):
            return componentName
        elif (len(componentName) > 1):
            return checkFileNameClearcase(viewName, componentName[:-1])
            
    elif (len(componentName) > 1):
        return checkFileNameClearcase(viewName, componentName[:-1])
    else:
        return "NONE"

def getComponentForInterface(interfaceName, fileName):
    cmd = "cleartool pwv -short"
    viewName = subprocess.check_output([cmd], shell=True).strip()
    component = interfaceName.split('x')[0].split('_')[0].strip()
    if component.endswith("XA") or component.endswith("XT"):
        component = component[:-2]
    component = guessComponentName(viewName, component, fileName)
        
    return component

def getLibDependencies(component, libFileName):
    pathToComponent = subprocess.check_output(['/sdev/user/bin/xcd', component]).strip()
    pathToDir = pathToComponent + "/com/ext/lib/"
    os.chdir(pathToDir)

    libFindResult = subprocess.Popen('find . -maxdepth 1 -type f -name "makefile*" \
                                    | xargs grep -H -n ' + libFileName + ' | grep TARGET \
                                    | head -1',
                                          shell=True,
                                          stdout=subprocess.PIPE).stdout.read().strip()
   
    makefileName = libFindResult.split(':')[0]
    print "component " + component
    print "makefile " + makefileName
    print "libFileName " + libFileName
    
    makefileLineNumber = libFindResult.split(':')[1]

    inRequiredLibs = False
    libDependencies = []
    with open (makefileName) as f:
        for i in xrange(int(makefileLineNumber)):
            f.next()
        for line in f:
            line = line.strip()
            if inRequiredLibs:
                libToAdd = line.strip().split('\\')[0]
                libDependencies.append(libToAdd)
                if not ("\\" in line):
                    break
            elif ("DEPSOL" in line) or ("USRLIBS" in line):
                if "\\" in line: 
                    inRequiredLibs = True
                libToAdd = line.strip().split("=")[1].split("\\")[0].strip()
                if libToAdd:
                    libDependencies.append(libToAdd)
    return libDependencies


def getHeaderDependencies(interfaceName, component, fileName):
    pathToComponent = subprocess.check_output(['/sdev/user/bin/xcd', component]).strip()
    pathToDir = pathToComponent + "/../"
    os.chdir(pathToDir)
    
    
    if ("typ.h" in fileName) or ("met.h" in fileName):
        fullFileName = component + "/com/ext/inc/bld/" + fileName
        if not os.path.isfile(fullFileName):
            fullFileName = component + "/xifs/" + interfaceName + "/" + fileName
    else:
        fullFileName = component + "/com/ext/inc/" + fileName
        
    includedInterfaces = []
    interfacePattern = re.compile("[A-Z]x[A-Z]")
    includePattern = re.compile("[A-z]/[A-z]")
    onlyAlpha = re.compile('["< ]')
    with open (fullFileName) as f:
        for line in f:
            if (line.startswith("#include") and
                includePattern.search(line)):
                interfaceDependency = line.split('/')[0].replace("#include","")
                interfaceDependency = onlyAlpha.sub("", interfaceDependency)

               # if interfacePattern.search(interfaceDependency):
                if not (interfaceDependency in includedInterfaces):
                    includedInterfaces.append(interfaceDependency)
    return includedInterfaces



def checkInterfaceDependencies(interfaceName, fileName, 
                               interfaceDependencies, buildscopeComponents):
    libExceptionList = ['libasml.cpp']
                               
    if not (fileName.endswith(".hpp") or
            fileName.endswith(".h") or
            fileName.endswith(".so")):
        return
    componentForInterface = getComponentForInterface(interfaceName, fileName)
    
    
    print "FOUND COMPONENT: " + componentForInterface
    
    if (fileName.endswith(".hpp") or fileName.endswith(".h")):
        headerDependencies = getHeaderDependencies(interfaceName, componentForInterface, fileName)
        for interfaceOfDependency in headerDependencies:
            addUniqueItemToDictionary(interfaceDependencies, interfaceName, interfaceOfDependency)

    elif (fileName.endswith(".so")):
        libDependencies = getLibDependencies(componentForInterface, fileName)
        for libDependency in libDependencies:
            if not (libDependency in libExceptionList):
                componentOfDependency = getComponent.getComponent(libDependency, buildscopeComponents)
                interfaceOfDependency = getInterface.getInterfaceInClearcase(libDependency, componentOfDependency)
                addUniqueItemToDictionary(interfaceDependencies, interfaceName, interfaceOfDependency)
    

def printObsoleteInterfaceRequirement(interfaceName, actualInterfaceRequires, interfaceDependencies):
    for requiredInterface in actualInterfaceRequires[interfaceName]:
        if not (requiredInterface in interfaceDependencies[interfaceName]):
            print "Remove interface " + interfaceName + " requires " + requiredInterface


def listObsoleteDependencies(scopefile):
    buildscopeComponents = clearcase.get_buildscope()
    insideInterface = False
    insideComponent = False
    interfaceName = ''
    componentName = ''
    interfaceDependencies = {}
    actualInterfaceRequires = {}
    with open (scopefile) as f:
        for line in f:
            line = line.strip()
            if insideInterface:
                if "contains " in line:
                    fileName = line[::-1].split("/")[0][::-1]
                    checkInterfaceDependencies(interfaceName, fileName, 
                                               interfaceDependencies, buildscopeComponents)
                elif "requires" in line:
                    requiredInterface = line.split(' ')[-1]
                    addUniqueItemToDictionary(actualInterfaceRequires, interfaceName, requiredInterface)                    
                elif "}" in line:
                    if insideInterface:
                        printObsoleteInterfaceRequirement(interfaceName, actualInterfaceRequires, interfaceDependencies)                
                        insideInterface = False
                
            elif line.startswith("interface "):
                insideInterface = True
                interfaceName = line[::-1].split(' ')[0][::-1]
                actualInterfaceRequires[interfaceName] = []
                
    for key in interfaceDependencies:
        print "--> " + key +" <---"
        print '\n'.join(interfaceDependencies[key])


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-f" , "--file", 
                        help="Provide a scopefile",
                        required=True)
    args = parser.parse_args()
    scopefile = args.file

    listObsoleteDependencies(scopefile)
