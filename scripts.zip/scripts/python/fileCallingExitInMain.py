#!/usr/bin/env python

import exitInMain

print "BEFORE CALLING"

exitInMain.main()

print "AFTER CALLING"
