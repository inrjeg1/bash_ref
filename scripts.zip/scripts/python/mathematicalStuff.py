#!/usr/bin/env python


def countUp():
    a = 2
    a += 1
    print a


def getMaximum():
    alpha = 44
    bravo = 30
    
    print max(alpha, bravo) +3


def checkModulo():
    n = 1
    while n < 100:
        if n % 10 == 0:
            print n
        n += 1
    
    
checkModulo()
#getMaximum()
#countUp()

