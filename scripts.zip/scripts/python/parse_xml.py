#!/usr/bin/env python

import xml.etree.ElementTree as eTree
import xml.dom.minidom
import logging

xmlFile = 'config.xml'

def parseXmlFile():
    filehandler = open(xmlFile, "r")
    raw_data = eTree.parse(filehandler)
    data_root = raw_data.getroot()
    filehandler.close()
    
    print dir(data_root)
    print data_root._children
    

def parseXmlFile2():
    doc = eTree.parse(xmlFile)
    memoryElem = doc.find('buildscope')
    parentBuildscope = []
    for elem in memoryElem.text.split():
        if "/" in elem:
            parentBuildscope.append(elem.split("/")[1])
    
    print parentBuildscope
    
def parseXmlFile3():
    doc = xml.dom.minidom.parse(xmlFile)
    parentBuildscope = []
    buildscope = doc.getElementsByTagName("buildscope")[0].childNodes[0].data
    for elem in buildscope.split():
        if "/" in elem:
            parentBuildscope.append(elem.split("/")[1])
            
    print parentBuildscope
   
    
#parseXmlFile3()


def get_parent_buildscope(baseline):
    release = baseline.split("_integration")[0]
    configFile = "/exp/"+release+"/"+baseline+"/pkg/install/config.xml"
    doc = xml.dom.minidom.parse(configFile)
    buildscope = doc.getElementsByTagName("buildscope")[0].childNodes[0].data
    parentBuildscope = []
    for elem in buildscope.split():
        if "/" in elem:
            parentBuildscope.append(elem.split("/")[1])
    return parentBuildscope


def filter_view_buildscope(view, buildscope, baseline):
    logging.getLogger(__file__).info("Filtering buildscope for {}".format(view))
    new_buildscope = []
    parent_buildscope = get_parent_buildscope(baseline)
    for component in buildscope:
        if component in parent_buildscope:
            new_buildscope.append(component)
    return new_buildscope


view_buildscope = ['CMIM', 'EGTPEX', 'EMGN', 'EMGW', 'EMLP', 'EMLPEN', 'EMTDMI', 'EMWC', 'EMWM', 'EMWTMI', 'ENCD', 'ENDE', 'ENDM', 'ENEE', 'ENGE', 'ENGM', 'ENGMV2', 'ENTE', 'EQLCMI', 'EQZPPM', 'EUDCEX', 'EUFPEX', 'EUGEEX', 'EUGMEX', 'EULAMI', 'EUMMEX', 'EUSHEX', 'EUSVEX', 'EVWM', 'EVWT', 'KM', 'KR', 'KV', 'KVIFPC', 'KVWMRE', 'OWWG', 'VETF']
dumbo_baseline = "lvl_at7.3_integration_180412_002801"

#print filter_view_buildscope("my view", view_buildscope, dumbo_baseline)

a = 2
if a == 2:
    raise SystemError('a should not be "two"')



