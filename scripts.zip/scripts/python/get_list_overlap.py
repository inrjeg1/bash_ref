#!/usr/bin/env python

def get_overlapping_list_values():
    listA = ['A', 'B', 'C', 'D', 'E']
    listB = ['H', 'E', 'F', 'Z', 'D']
    
    listC = list(set(listA).intersection(listB))
    
    print listC

get_overlapping_list_values()
