#!/usr/bin/env python


def writeMyLinesToFile():
    myLines = ("alpha bravo\n"
               "    charlie delta\n"
               "    echo foxtrott\n"
               "golf hotel")

 
    with open("myNewFile", 'w+') as f:
        f.write(myLines)


writeMyLinesToFile()
