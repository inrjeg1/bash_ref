#!/usr/bin/env python


from __future__ import print_function

import sh

def printOutput(line):
    print(line, end='')

def gem(command):
    sh.gem(command.split(), _out=printOutput, _err=printOutput, _tty_out=False)

def installPackager():
    gem('install packaging -v 1.8.0')
    
installPackager()
