#!/usr/bin/env python


from datetime import datetime

def printNewBranchName():
    weekNr = datetime.date(datetime.now()).isocalendar()[1]
    if weekNr < 10:
        weekNr = "0" + str(weekNr)
    weekNr = str(weekNr)

    currentTime = (datetime.now().strftime("%y") + 
                           weekNr +
                           datetime.now().strftime('.%w_%H%M%S'))
    branchName = 'syncToBoa_'+currentTime
    print branchName
    
 
def printWeekNr():
    thisWeek = datetime.date(datetime.now()).isocalendar()[1]
    if thisWeek < 10:
        thisWeek = "0" + str(thisWeek)
    
    print "week:", thisWeek
    

def getDateAndTime():
    dateAndTime = datetime.now().strftime("%y%m%d_%H%M%S")
    print dateAndTime
    weekNr = datetime.date(datetime.now()).isocalendar()[1]
    if weekNr < 10:
        weekNr = "0" + str(weekNr)
    weekNr = str(weekNr)

    weekNrAndTime = (datetime.now().strftime("%y") + weekNr +
                           datetime.now().strftime('.%w_%H%M%S'))
    print weekNrAndTime

getDateAndTime()
#printWeekNr()
#printNewBranchName()
