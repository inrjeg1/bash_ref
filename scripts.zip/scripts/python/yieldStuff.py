#!/usr/bin/env/ python

class myClass():
    
    def execute(self):
        a = 5
        b = 8
        print ('echo', b)
        print ('charlie', a)
        if a > 4:
            print ('alpha', a)
            print ('delta', b)
            yield a
            print ('bravo', a)
            

a = myClass().execute()
for i in a:
    print "BLAAA"
    print i

for i in a:
    print "00000000"
    print i

