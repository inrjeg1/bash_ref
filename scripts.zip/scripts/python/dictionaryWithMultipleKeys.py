#!/usr/bin/env python

from common import addItemToDictionary

def dictionaryWithMultipleKeys():
    dictA = {}
    addItemToDictionary(dictA, ("alpha", "bravo"), "one")
    addItemToDictionary(dictA, ("alpha", "bravo"), "two")
    addItemToDictionary(dictA, ("alpha", "bravo"), "three")
    addItemToDictionary(dictA, ("alpha", "bravo"), "four")
    myList = dictA[("alpha", "bravo")]
    print sorted(myList)
    
    

dictionaryWithMultipleKeys()
