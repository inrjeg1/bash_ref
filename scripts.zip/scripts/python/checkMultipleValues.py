#!/usr/bin/env python


def checkMultiple():
    alpha = True
    bravo = False
    for value in alpha, bravo:
        
    
checkMultiple() 
