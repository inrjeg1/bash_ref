#!/usr/bin/env/ python

from __future__ import print_function

import contextlib
import os
import glob
import sh

import errno
import shutil

@contextlib.contextmanager
def workingDirectory(d):
    pwd = os.getcwd()
    sh.cd(d)
    try:
        yield
    finally:
        sh.cd(pwd)

@contextlib.contextmanager
def copyOfInterfaceDirectory(IF):
    try:
        os.makedirs(IF)
    except OSError as e:
        if e.errno == errno.EEXIST:
            print('DIRECTORY FOUND WITH SAME NAME AS INTERFACE FOR ' + IF)
            raise RuntimeError('DIRECTORY FOUND WITH SAME NAME AS INTERFACE FOR ' + IF)

    for headerfilename in glob.glob('*.hpp'):
        open(IF + '/' + headerfilename, 'w')

    try:
        yield
    finally:
        shutil.rmtree(IF)



def checkInterface(IF):
    print('Checking {}'.format(IF))
    failuresFound = False

    gcc = sh.Command('gcc')
    includePaths = [
        '/home/cadappl_RHEL6/gmock/1.7.0.a_32/gmock/include/',
        '/home/cadappl_RHEL6/gtest/1.7.0.a_32/gtest/include/',
        '/home/cadappl_RHEL6/boost/1.54.0_32/boost/include/',
        '/home/cadappl_RHEL6/python/2.7.b_32/python/include/python2.7/',
        '../basic/'
    ]
    class OutputStorer:
        output = None

        def __init__(self):
            self.output = []

        def __call__(self, s):
            self.output.append(s)

    with workingDirectory(IF):
        with copyOfInterfaceDirectory(IF):
            for headerfilename in glob.glob('*.hpp'):
                storeOutput = OutputStorer()
                try:
                    gcc('-fsyntax-only', '-std=c++11', '-m32', '-Wall', '-Wnon-virtual-dtor', c=headerfilename,
                        *['-isystem' + p for p in includePaths], _err=storeOutput)
                except sh.ErrorReturnCode:
                    print('    Failed:')
                    print(''.join('    ' + line for line in storeOutput.output))
                    failuresFound = True


    return failuresFound



def checkComponentInterfaces(ccName):
    print('CHECKING {} INTERFACES'.format(ccName))
    failuresFound = False
    with workingDirectory(os.path.join(ccName, 'xifs')):
        for IF in glob.glob('{}*'.format(ccName)):
            failuresFound |= checkInterface(IF)
    if failuresFound:
        print('INTERFACE CHECK FAILED')
        raise RuntimeError('INTERFACE CHECK FAILED')
    else:
        print('SUCCESS: Interfaces are correctly defined')

checkComponentInterfaces('CC')
