#!/usr/bin/env python

def reverseList():
    myList = ["alpha", "bravo", "charlie", "delta"]
    
    for itemNr, item in enumerate (reversed(myList), 1):
        if "p" in item:
            print itemNr
    


if __name__ == "__main__":
    reverseList()

