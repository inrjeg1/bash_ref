#!/usr/bin/env python

import re


def replaceString():
    with open("dummy2.txt") as f:
        i = f.read()
    with open("dummy2.txt") as f:
        original = "u("
        replacement = "a("
    
        i = re.sub(original, replacement, i)
        print i
        #f.write(i)
        

#replaceString()

def replaceString2():
    myString = "alfabravo"
    newString = myString.replace("a", "")
    print newString

#replaceString2()


def replaceString3():
    myString = "Alpha.Bravo/Charlie.Delta/Echo.Foxtrott/"
    print myString.replace(".",'_').replace('/','.')
    
#replaceString3()

