#!/usr/bin/env python

import argparse
import clearcase
import glob
import os
import subprocess

def getInterfaceInClearcase(fileName, componentName):
    pathToComponent = subprocess.check_output(['/sdev/user/bin/xcd', componentName]).strip()
    pathToDir = pathToComponent + "/../xscm"
    os.chdir(pathToDir)

    scopefiles = glob.glob('BB-*ternal_scope.txt.2')
    for scopefile in scopefiles:
        interfaceName = ""
        insideInterface = False
        with open (scopefile) as f:
            for line in f:
                if insideInterface:
                    if fileName in line:
                        return interfaceName
                    elif '}' in line:
                        insideInterface = False
                elif 'interface' in line:
                    insideInterface = True
                    interfaceName = line.split(' ')[1].strip()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('-f', '--file',
                        help="Filename for which interface should be retrieved",
                        required = True)
    parser.add_argument('-c', '--component',
                        help="Component that contains the file")             
    args = parser.parse_args()
    print getInterfaceInClearcase(args.file, args.component)
