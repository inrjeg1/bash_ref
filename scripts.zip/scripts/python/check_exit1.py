#!/usr/bin/env python

class ClassAlpha():
    def bravo(self):
        print "printing Bravo"
        return False

class ClassCharlie():
    def delta(self):
        print "printing Delta"
        return False


if ClassAlpha().bravo():
    exit(1)
elif ClassCharlie().delta():
    exit(1)
print "DONE!"
