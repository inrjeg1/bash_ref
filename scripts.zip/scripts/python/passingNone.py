#!/usr/bin/env python

def someFunction(argA=None):
    if not argA:
        print "ABSENT"
    else:
        print "PRESENT"

someFunction()
someFunction("argument")
