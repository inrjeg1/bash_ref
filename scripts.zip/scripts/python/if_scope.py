#!/usr/bin/env python

def checkVariableValue():

    a = 5
    if a > 4:
        b = 2
    else:
        b = 3
    print "b:", b


checkVariableValue()
