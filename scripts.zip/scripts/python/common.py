##################################################################
#                 Copyright (c) 2016, ASML Netherlands B.V.      #
#                        All rights reserved                     #
##################################################################

from __future__ import print_function

import glob
import os
import sh
import re
import contextlib

try:
    import cPickle as pickle
except:
    import pickle

BUILD_DEPENDENCIES_FILENAME = 'buildDependencies.gradle'


def printUsage(programName):
    print("Usage: {} all | linux".format(programName))


def printOutput(line):
    print(line, end='')


def printListOnMultipleLines(l, formatter = str):
    print('\n'.join(formatter(x) for x in l))
    print('')


def printPhase(phase):
    print('')
    print('======>', phase, '<======')


def printPhaseResult(result):
    print('======>', result)


def installFromCadenv(component, version=''):
    cadenvParams = ('-r {} '.format(version)) if version else ''
    cadenvParams += component
    sh.cadenv(cadenvParams.split(), _out=printOutput, _err=printOutput)


def getCurrentUserName():
    return str(sh.whoami()).split()[0]


def gem(command):
    sh.gem(command.split(), _out=printOutput, _err=printOutput, _tty_out=False)


def allowWriteAccessByOthers(path):
    sh.chmod('-R a+w {}'.format(path).split(),
             _out=printOutput, _err=printOutput)


def saveObjectToFile(object, fileName):
    sh.mkdir('--parents', os.path.dirname(fileName))
    with open(fileName, 'w') as f:
        pickle.dump(object, f)


def loadObjectFromFile(fileName):
    with open(fileName, 'r') as f:
        return pickle.load(f)


def selectFiles(paths):
    return [f for f in paths if os.path.isfile(f) and not os.path.islink(f)]


def copyFiles(path, toDir):
    sh.mkdir('--parents', toDir)
    sh.cp('--no-dereference', path, toDir)


def copyDir(path, toDir):
    sh.cp('--recursive', '--force', path, toDir)


def formattedSizeOf(path):
    return sh.du('-sh', path).split()[0]


def remove(path):
    sh.rm('-rf', path, _out=printOutput, _err=printOutput)


@contextlib.contextmanager
def tmp_path(d):
    try:
        yield
    finally:
        sh.rm('-rf', d)


@contextlib.contextmanager
def workingDirectory(d):
    pwd = os.getcwd()
    sh.cd(d)
    try:
        yield
    finally:
        sh.cd(pwd)


@contextlib.contextmanager
def collectExceptions(exceptions):
    try:
        yield
    except Exception as e:
        exceptions.append(e)


def ResultCachingDecorator(function):
    cache = {}

    def wrapper(*args):
        key = args
        if key in cache:
            return cache[key]
        else:
            rv = function(*args)
            cache[key] = rv
            return rv
    return wrapper


def getLILMakefiles():
    return [makefile for makefile in glob.glob('??LI??/com/*/*/makefile*')
            if not makefile.endswith('~')]


def getBoaComponents():
    componentFolders = glob.glob('*/com')
    component_re = re.compile('([A-Z]+)/com')
    return [component_re.match(componentFolder).group(1)
            for componentFolder in componentFolders]


def getFileExtension(filename):
    return os.path.splitext(filename)[1]


def getChangeSet():
    return sh.git('diff --name-only origin/master'.split(),
                  _tty_out=False).split()


def retrieveAndReportChangeSet():
    changeSet = getChangeSet()
    if changeSet:
        print('FILE CHANGE SET:')
        printListOnMultipleLines(changeSet)
    else:
        print('Repository content is identical to origin/master')
    return changeSet


def isNonEmptyFile(fpath):
    return os.path.isfile(fpath) and os.path.getsize(fpath) > 0


def getBuildDependencyFiles(boaPath = '.'):
    build_dependencies_files = []
    if os.path.exists(BUILD_DEPENDENCIES_FILENAME):
        build_dependencies_files = [BUILD_DEPENDENCIES_FILENAME]
    build_dependencies_files.extend(  glob.glob('%s/*/%s' % (boaPath, BUILD_DEPENDENCIES_FILENAME)) )
    return build_dependencies_files

def getAllMakefiles():
    return [makefile for makefile in glob.glob('*/com/*/*/makefile*')
            if not makefile.endswith('~')]
            
def addItemToDictionary(dictionary, key, value):
    if key in dictionary:
        dictionary[key].append(value)
    else:
        dictionary[key] = [value]
    return dictionary

# ==================
#     TESTS
# ==================

import unittest


class Tests_ResultCachingDecorator(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.longMessage = True

    def test_ResultCachingDecorator_SingleMethod(self):
        calls = []

        @ResultCachingDecorator
        def foo(bar):
            calls.append(bar)
            return bar

        args = [1, 1, 2, 3, 2, 3]
        for a in args:
            self.assertEqual(a, foo(a))
        self.assertEqual(sorted(list(set(args))), sorted(calls))

    def test_ResultCachingDecorator_MultipleMethods(self):
        calls = {}
        calls['foo'] = []
        calls['bar'] = []

        @ResultCachingDecorator
        def foo(a):
            calls['foo'].append(a)
            return a

        @ResultCachingDecorator
        def bar(a):
            calls['bar'].append(a)
            return a+1

        args = [1, 1, 2, 3, 2, 3]
        for a in args:
            self.assertEqual(a, foo(a))
            self.assertEqual(a+1, bar(a))
        self.assertEqual(sorted(list(set(args))), sorted(calls['foo']))
        self.assertEqual(sorted(list(set(args))), sorted(calls['bar']))

    def test_ResultCachingDecorator_NoArgs(self):
        calls = []

        @ResultCachingDecorator
        def foo():
            calls.append('foo')
            return 0

        @ResultCachingDecorator
        def bar():
            calls.append('bar')
            return 1

        for a in range(10):
            self.assertEqual(0, foo())
            self.assertEqual(1, bar())
        self.assertEqual(sorted(calls), sorted(['foo', 'bar']))

    def test_ResultCachingDecorator_MultipleArgs(self):
        calls = []

        @ResultCachingDecorator
        def foo(bar, top):
            calls.append(bar)
            return bar

        args = [1, 1, 2, 3, 2, 3]
        for a in args:
            self.assertEqual(a, foo(a, 2))
        self.assertEqual(sorted(list(set(args))), sorted(calls))
