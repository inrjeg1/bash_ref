#!/usr/bin/env python


b = 5

def checkOr():
    a = 5
    
    if (a == 4 or
        a == b or
        a == 6):
       
        print "TRUE"



consolidationTestSet = "ABC"
fullTestSet = "DEF"
LilStressTest = "CT3"

TEST_LIST = {}
TEST_LIST[consolidationTestSet] = ('CT1') + ('CT2')



TEST_LIST[fullTestSet] = TEST_LIST[consolidationTestSet] + \
    (LilStressTest)

print TEST_LIST[fullTestSet]
    
