#!/usr/bin/env python

from assembly_check.app import main

if __name__ == "__main__":
    """
    Main starter tool for the assembly check package
    """
    main()

