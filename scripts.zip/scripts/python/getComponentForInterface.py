#!/usr/bin/env python

from common import getBoaComponents
import argparse

def getComponentForInterface(interfaceName):
    if any(component == interfaceName for component in getBoaComponents()):
        return interfaceName
    elif len(interfaceName) > 2:
        return getComponentForInterface(interfaceName[:-1])
    else:
        return "ERROR"

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('-i', '--interface',
                        help="Interface name for which component should be retrieved",
                        required = True)
    args = parser.parse_args()
    print getComponentForInterface(args.interface)
