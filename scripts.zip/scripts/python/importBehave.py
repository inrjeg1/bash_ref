#!/usr/bin/env python

import behave

import mock

print mock.version_info

print dir(mock.version_info)

