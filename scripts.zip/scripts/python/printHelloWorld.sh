#!/bin/bash

echo "Alpha Bravo"

function printHelloWorldFunc() {
    echo "Hello World!"
}

printHelloWorldFunc
