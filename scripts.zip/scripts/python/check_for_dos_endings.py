#!/usr/bin/env python

from __future__ import print_function
import glob
import os
import sh

def removeDosLineEndings():
   for makefile in getLILMakefiles2():
      sh.dos2unix('-n',
                  makefile,
                  'makefile_unix')
      print('One')
      
      try:
          sh.diff('-u',
                  makefile,
                  'makefile_unix')
          print('SUCCESS: buildDependencies.gradle is sorted')
      except:
          print('ERROR: buildDependencies.gradle is not sorted')


def getLILMakefiles2():
    return glob.glob('makefile*')

def getLILMakefiles():
    return glob.glob('??LI??/com/*/*/makefile*')
    

removeDosLineEndings()



