

def bla():
    print "someFile called"
