#!/usr/bin/env python

import argparse


def someFunction(name):
    print ("name", name)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("-n", "--name", 
                        choices = ["Fred", "Homer", "Peter"], 
                        help="Some name")
    parser.add_argument("-v", "--view",
                        help="Give some view")
    parser.add_argument("arg_name", type=str,
                        help="Some argument")

    args = parser.parse_args()
    print args.view
    if args.view:
        print "View given!"
        print args.view
    
    #someFunction(args.nme)

