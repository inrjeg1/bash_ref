#!/usr/bin/env python

import argparse

def findFilesThatIncludeThisOne(pathToComDir, fileName):
    
    
    
    
if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("-f", "--file",
                        help="Provide a header file")

    args = parser.parse_args()
    headerFile = args.file
    pathToComDir = headerFile.rsplit('/', 3)[0]
    findFilesThatIncludeThisOne(pathToComDir, headerFile)

