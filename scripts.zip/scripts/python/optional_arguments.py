#!/usr/bin/env python

def someFunction(a = 82, b = "bravo", c = "charlie"):
    print "a:", a
    print someFunction.__defaults__
    if not b is someFunction.__defaults__[1]:
        print "b is true"
    if not c is someFunction.__defaults__[2]:
        print "c is true"
    
    #print(someArg)
    
#someFunction(5, b = "BRAVO", c = 9734)



def funcA(a, b, c):
    a = 5
    b = 9
    c = 2

alpha = 3
bravo = 1
charlie = 4


class A():
    def funcA(self, a = 4, b = 5):
        print self.funcA.__defaults__

        if not a == self.funcA.__defaults__[0]:
            print "a:", a
        if not b == self.funcA.__defaults__[1]:
            print "b:", b
    
    def A_main(self):
        self.funcA(a=10, 
                   b=8)
        
        
A().A_main()


#funcA(alpha, bravo, charlie)
#print alpha
#print bravo
#print charlie

#def funcWithOneOptionalArgument(alpha = True):
#    print "alpha", alpha

#funcWithOneOptionalArgument(alpha = False)

