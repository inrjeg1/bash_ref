#!/usr/bin/env python

def _privateFunction():
    print "Printing from private function"

def printSomething():
    print "Something"

class SomethingElse():
    def __init__(self, someArgument): 
        self.myArg = someArgument

    def printSomethingElse(self):
        print "Something Else", self.myArg
        exit(0)
        

if __name__ == "__main__":
    printSomething()
