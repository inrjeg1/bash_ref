#!/usr/bin/env python


def main():
    print "BEFORE EXIT"
    return
    print "WILL NEVER BE PRINTED"    

if __name__ == "__main__":
  main()  
  
