#!/usr/bin/env python

from makeExecutable import *


def callOtherFunction():
    SomethingElse("1 2 3").printSomethingElse()
    print "After finishing function call"

if __name__ == "__main__":
    printSomething()
    _privateFunction()
    callOtherFunction()

