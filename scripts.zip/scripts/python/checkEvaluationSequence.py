#!/usr/bin/env python

a = 5
b = a + 2
print b

if b > 5:
    print "Greater!"
else:
    print b + c

