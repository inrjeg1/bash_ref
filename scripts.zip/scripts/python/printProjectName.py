#!/usr/bin/env python


from clearcase import get_ccget_config_stack


def printProjectName():
    projectName = get_ccget_config_stack()['projects'][0]
    print projectName
    
    
printProjectName()
