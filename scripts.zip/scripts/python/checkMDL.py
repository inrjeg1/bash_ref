#!/usr/bin/env python


import sys
sys.path.append("/usr/asm/atl.0000/KVLIVT/tstpkg")
sys.path.append("/usr/asm/atl.0000/KVLIVT/tstpkg/ddpy-dist.zip")
sys.path.append("/usr/asm/atl.0000/KVLIVT/tstpkg/python-utilities")

import string


from mdl import MdlFile, getMdlFilename
from LilMdlTags import LilMdlTags
from MdlTags import MdlDataTag

def checkMDLFile():
    print "checking MDL"
    
    localFieldDataTag = MdlDataTag('KU-EA92', 'dyn_calculation_result')
    
    
    mdlFileName = "/usr/asm/data.0000/output_informal_diagnostics/ME/20160802-160630-test_BasicLotLilWithExposure-9HWD4Y_0802_160526.mdl.gz"
    foundTags = MdlFile(mdlFileName).find(localFieldDataTag.tag)
    print foundTags
    a = len(foundTags)
    print ("len",a)
    
    expectedTag = "RESULTING_FIT_NODE_LOCAL_FIELD"
    
    status = "TRUE"
    for entry in foundTags:
        if not entry.dat.attempted_fit_mode == expectedTag:
	    status = "FALSE"
    
    print status
    
    
checkMDLFile()

