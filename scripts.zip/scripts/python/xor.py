#!/usr/bin/env python

from operator import xor

class TestXor():
    def __init__(self):
        self.alpha = True
        self.bravo = True
        self.charlie = False
        self.delta = False

    def xor_1(self):
        print "XOR 1"

        print "a or b", self.alpha ^ self.bravo
        print "a or c", self.alpha ^ self.charlie
        print "c or b", self.charlie ^ self.bravo
        print "c or d", self.charlie ^ self.delta

    def xor_2(self):
        print "XOR 2"

        print "a or b", xor(self.alpha, self.bravo)
        print "a or c", xor(self.alpha, self.charlie)
        print "c or b", xor(self.charlie, self.bravo)
        print "c or d", xor(self.charlie, self.delta)


testXor = TestXor()
testXor.xor_1()
testXor.xor_2()
