#!/usr/bin/env python

x = 'alpha'

exec("%s = %d" % (x, 2))

print alpha


