#!/usr/bin/env python

def or_equals():

   f = 1

   if f:
   
      c = 3 == (3 -1)
      print c

      c |= 2 == 2

      print c

      c |= 3 == 1

      print c

   print c
   return c
   
   
   
my_bool = or_equals()
print "my_bool", my_bool


