#!/usr/bin/env python

import filecmp

def compareFiles():
#    print dir(filecmp)
    print filecmp.cmp('dummy.txt', 'dummy2.txt')
    


compareFiles()
