#!/usr/bin/env python

def printLenghtOfLongestKey():
    myDict = {}
    myDict['alpha'] = 0
    myDict['foxtrott'] = 0
    myDict['novemeber'] = 0
    myDict['zulu'] = 0

    maximumLength = len(max(myDict.keys(), key=len))
    for key in myDict:
        print key + " " * (maximumLength - len(key)) + ": " + str(myDict[key])
    
   # print maximumLength
    
    print all(value == 0 for value in myDict.values())
    
    
printLenghtOfLongestKey()
