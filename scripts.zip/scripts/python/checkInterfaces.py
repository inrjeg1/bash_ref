#!/bin/env python

from __future__ import print_function
import glob
import sh
import os
import subprocess

from common import workingDirectory, \
                   printPhase, \
                   printListOnMultipleLines, \
                   getBuildDependencyFiles

def guessComponentsForInterfaceCheck(changeSet):
    printPhase('ANALYZING INTERFACE CHANGES')
    headerFiles = [f for f in changeSet if f.endswith(('.h', '.hpp'))]
    interfaceHeaders = []

    build_dependencies_files = getBuildDependencyFiles()
    for build_dependencies_file in build_dependencies_files:
        interfaceHeaders.extend(
            [
                f for f in headerFiles
                if os.path.basename(f)
                in open(build_dependencies_file).read()
            ] )
    if interfaceHeaders:
        print('\nChanged interface header files:')
        printListOnMultipleLines(interfaceHeaders)
    else:
        print('Interface header files are not changed.')
        print('Interface checks can be skipped.')

    componentNames = list(set([f.split('/')[0] for f in interfaceHeaders]))
    return componentNames


def checkComponentInterfaces(ccName):
    printPhase('CHECKING {} INTERFACES'.format(ccName))
    failuresFound = False
    path = os.path.join(ccName, 'xifs')
    if os.path.exists(path):
        with workingDirectory(path):
            for interface in glob.glob('{}*'.format(ccName)):
                failuresFound |= checkInterface(interface)
        if failuresFound:
            print('INTERFACE CHECK FAILED')
            raise RuntimeError('INTERFACE CHECK FAILED')
        else:
            print('SUCCESS: Interfaces are correctly defined')
    else:
        print('INGORED: No interfaces defined')


def checkInterface(interface):
    print('Checking {}'.format(interface))
    failuresFound = False

    gcc = sh.Command('gcc')
    includePaths = [
        '/home/cadappl_RHEL6/gmock/1.7.0.a_32/gmock/include/',
        '/home/cadappl_RHEL6/gtest/1.7.0.a_32/gtest/include/',
        '/home/cadappl_RHEL6/boost/1.54.0_32/boost/include/',
        '/home/cadappl_RHEL6/python/2.7.b_32/python/include/python2.7/',
        '../basic/',
        '../ddgen/'
    ]

    class OutputStorer:
        output = None

        def __init__(self):
            self.output = []

        def __call__(self, line):
            self.output.append(line)

    def printer(line): print(line)

    with workingDirectory(interface):
        for headerfilename in glob.glob('*.hpp'):
            storeOutput = OutputStorer()
            try:
                print('   header: {}'.format(headerfilename))
                gcc('-fsyntax-only', 
                    '-std=c++11', 
                    '-m32', 
                    '-Wall', 
                    '-Wnon-virtual-dtor', 
                    c=headerfilename,
                    *['-isystem' + p for p in includePaths], 
                    _err=storeOutput)
            except sh.ErrorReturnCode:
                print('    Failed:')
                print(''.join('    ' + line for line in storeOutput.output))
                failuresFound = True

    return failuresFound


def checkAllInterfaces():
   # subprocess.Popen(['bash', '-c', ' . ../jenkins-tooling/installers.sh; installGcc'])
    tooling_dir = os.path.dirname(sys.argv[0])
    subprocess.Popen(['%s/installers.sh' % (tooling_dir), 'installGcc'])
    for interface in glob.glob('??[L|D]I*'):
        checkComponentInterfaces(interface)


if __name__ == '__main__':
    import sys

    if len(sys.argv) > 1:
        checkComponentInterfaces(sys.argv[1])
    else:
        checkAllInterfaces()
