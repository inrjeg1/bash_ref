#!/bin/env python
##################################################################
#                 Copyright (c) 2019, ASML Netherlands B.V.      #
#                        All rights reserved                     #
##################################################################

import copy
import os.path
import sys

from common import workingDirectory


class ProvidedInterface:
    def __init__(self):
        self.name = None
        self.versionedFiles = None
        self.requires = None
        self.buildFiles = None

    def __init__(self,interfaceName):
        self.name = interfaceName
        self.versionedFiles = set({})
        self.requires = set({})
        self.buildFiles = set({})

    def __eq__(self, other):
        if isinstance(other, ProvidedInterface):
            return self.name == other.name and \
                   self.versionedFiles == other.versionedFiles and \
                   self.requires == other.requires and \
                   self.buildFiles == other.buildFiles
        return False

    def __repr__(self):
        return "name = {}, versionedFiles = {}, requires = {}, buildFiles = {}" \
               .format(self.name, self.versionedFiles, self.requires, self.buildFiles)

    def __ne__(self, other):
        return not self.__eq__(other)



class BuildDependency:
    providedInterfaces = None
    requiredInterfaces = None
    requiredTestInterfaces = None

    def __init__(self):
        self.providedInterfaces = {}
        self.requiredInterfaces = set({})
        self.requiredTestInterfaces = set({})

    def __eq__(self, other):
        if isinstance(other, BuildDependency):
            return self.providedInterfaces == other.providedInterfaces and \
                   self.requiredInterfaces == other.requiredInterfaces and \
                   self.requiredTestInterfaces == other.requiredTestInterfaces
        return False

    def __ne__(self, other):
        return not self.__eq__(other)

    def __repr__(self):
        return "providedInterfaces = {}, requiredInterfaces = {}, requiredTestInterfaces = {}" \
               .format(self.providedInterfaces, self.requiredInterfaces, self.requiredTestInterfaces)

    def getProvidedInterface(self,name):
        if name in self.providedInterfaces:
            return self.providedInterfaces[name]
        else:
            pi = ProvidedInterface(name)
            self.providedInterfaces[name] = pi
            return pi

    def getInterfacesExposingVersionedFile(self,header):
        out = set({})
        for _,pi in self.providedInterfaces.items():
            interfacesName = [pi.name for vf in pi.versionedFiles if header in vf]
            for name in interfacesName:
                out.add(name)
        return out



def readBuildDependencyFileBuffer(fileBuffer):
    buildDep = BuildDependency()
    depth = 0

    def _appendFilePathFromLine(container,line):
        container.add(line.split('\'')[1])

    inProvidedInterfaces = False
    inRequiredInterfaces = False
    inRequiredTestInterfaces = False
    for line in fileBuffer:
        line = line.strip().replace("\t","").replace(" ","")
        if inProvidedInterfaces:
            if (depth == 1) and ("versionedFiles" in line):
                _appendFilePathFromLine(interface.versionedFiles,line)
            if (depth == 1) and ("buildFiles" in line):
                _appendFilePathFromLine(interface.buildFiles,line)
            if (depth == 2) and ("compile" in line):
                _appendFilePathFromLine(interface.requires,line)
            if "{" in line:
                if depth == 0:
                    interfaceName = ''.join(x for x in line if x.isalpha())
                    interface = buildDep.getProvidedInterface(interfaceName)
                depth += 1
            if "}" in line:
                if depth == 0:
                    inProvidedInterfaces = False
                depth -= 1
        elif inRequiredInterfaces or inRequiredTestInterfaces:
            if ("compile" in line):
                if inRequiredInterfaces:
                    _appendFilePathFromLine(buildDep.requiredInterfaces,line)
                elif inRequiredTestInterfaces:
                    _appendFilePathFromLine(buildDep.requiredTestInterfaces,line)
            if "}" in line:
                inRequiredInterfaces = False
                inRequiredTestInterfaces = False
        if "providedInterfaces{" in line:
            inProvidedInterfaces = True
        elif "requiredInterfaces{" in line:
            inRequiredInterfaces = True
        elif "requiredTestInterfaces{" in line:
            inRequiredTestInterfaces = True

    return buildDep



def readBuildDependencyFile(buildDependencyFile):
    buildDep = None
    if os.path.isfile(buildDependencyFile):
        with open(buildDependencyFile) as bdf:
            buildDep = readBuildDependencyFileBuffer(bdf)
    return buildDep


def autoTest():
    def _createProvidedInterface(name,versionedFiles,requires,buildFiles):
        pi = ProvidedInterface(name)
        pi.versionedFiles = versionedFiles
        pi.requires = requires
        pi.buildFiles = buildFiles
        return pi

    # Reference buildDependencies.gradle that will be used for comparison
    buildDepReference = BuildDependency()
    buildDepReference.providedInterfaces = {
        'KMLISAxCONTROLxNSLIB':
        _createProvidedInterface('KMLISAxCONTROLxNSLIB',set({}),set({}),
                                 {'com/ext/lib/bld_x86lnx/libKMLISA_asdDetermineSaUsecase.cpp.x86lnx.so',
                                  'com/ext/lib/bld_x86lnx/libKMLISA_asdStageAlignment.cpp.x86lnx.so',
                                  'com/ext/lib/bld_x86lnx/libKMLISA_asdStageAlignmentLifecycle.cpp.x86lnx.so'}),
        'KMLISAxERR':
        _createProvidedInterface('KMLISAxERR',{'com/ext/ddf/KMLISAxERR.ddf'},{'KMLISAxGN', 'ddgen'},{'KMLISAxERRtyp.h'})}
    buildDepReference.requiredInterfaces = {'DDXA', 'ERXA', 'asml_header', 'python'}
    buildDepReference.requiredTestInterfaces = {'CNXA', 'VELIRFxTEST', 'VELIRFxTESTSCRIPTS'}

    def _copyAndRemoveProvidedInterface(buildDep):
        out = copy.deepcopy(buildDep)
        del out.providedInterfaces['KMLISAxCONTROLxNSLIB']
        return out

    def _copyAndRemoveRequiredInterface(buildDep):
        out = copy.deepcopy(buildDep)
        out.requiredInterfaces.remove('python')
        return out

    def _copyAndRemoveRequiredTestInterface(buildDep):
        out = copy.deepcopy(buildDep)
        out.requiredTestInterfaces.remove('CNXA')
        return out

    def _copyAndChangeProvidedInterfaceName(buildDep):
        out = copy.deepcopy(buildDep)
        out.providedInterfaces['KMLISAxCONTROLxNSLIB'].name = 'xxx'
        return out

    def _copyAndRemoveProvidedInterfaceVersionedFile(buildDep):
        out = copy.deepcopy(buildDep)
        out.providedInterfaces['KMLISAxERR'].versionedFiles.remove('com/ext/ddf/KMLISAxERR.ddf')
        return out

    def _copyAndRemoveProvidedInterfaceRequires(buildDep):
        out = copy.deepcopy(buildDep)
        out.providedInterfaces['KMLISAxERR'].requires.remove('ddgen')
        return out

    def _copyAndRemoveProvidedInterfaceBuildFile(buildDep):
        out = copy.deepcopy(buildDep)
        out.providedInterfaces['KMLISAxERR'].buildFiles.remove('KMLISAxERRtyp.h')
        return out

    with workingDirectory(os.path.dirname(os.path.realpath(__file__))):
        # Compares the parsed test file with the reference values defined above
        buildDep = readBuildDependencyFile('buildDependencies.gradle.test')
        if not buildDep == buildDepReference:
            raise RuntimeError('readBuildDependencyFile auto test failed')
        if not buildDep.getInterfacesExposingVersionedFile('KMLISAxERR.ddf') == set({'KMLISAxERR'}):
            raise RuntimeError('readBuildDependencyFile auto test failed')

    # Makes sure the test can actually fail
    if _copyAndRemoveProvidedInterface(buildDepReference) == buildDepReference:
        raise RuntimeError('readBuildDependencyFile auto test should have failed')
    if _copyAndChangeProvidedInterfaceName(buildDepReference) == buildDepReference:
        raise RuntimeError('readBuildDependencyFile auto test should have failed')
    if _copyAndRemoveRequiredInterface(buildDepReference) == buildDepReference:
        raise RuntimeError('readBuildDependencyFile auto test should have failed')
    if _copyAndRemoveRequiredTestInterface(buildDepReference) == buildDepReference:
        raise RuntimeError('readBuildDependencyFile auto test should have failed')
    if _copyAndRemoveProvidedInterfaceVersionedFile(buildDepReference) == buildDepReference:
        raise RuntimeError('readBuildDependencyFile auto test should have failed')
    if _copyAndRemoveProvidedInterfaceRequires(buildDepReference) == buildDepReference:
        raise RuntimeError('readBuildDependencyFile auto test should have failed')
    if _copyAndRemoveProvidedInterfaceBuildFile(buildDepReference) == buildDepReference:
        raise RuntimeError('readBuildDependencyFile auto test should have failed')


if __name__ == '__main__':
    if len(sys.argv) == 2:
        print readBuildDependencyFile(sys.argv[1])
    else:
        autoTest()

