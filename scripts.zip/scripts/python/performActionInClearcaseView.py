#!/usr/bin/env python

import moveInternalInterfacesToExternalIfNeeded
import subprocess

class performActionInView():
    def __init__(self, clearcaseView):
        self.clearcaseView = clearcaseView

    def _setView(self):
        print "=== Setting Clearcase view", self.clearcaseView, "==="

        subprocess.Popen('cleartool startview '+ self.clearcaseView,
                         shell = True, 
                         stdout=subprocess.PIPE).stdout.read().strip()

    def _moveInternalInterfacesToExternal(self):
        moveInternalInterfacesToExternalIfNeeded.moveInternalInterfacesToExternalIfNeeded().move()
        
    def perform(self):
        self._setView()
        self._moveInternalInterfacesToExternal()

if __name__ == "__main__":
    print "HELLO"
    cc_view = "ptacken_lvl_at_qbl_dumbo_adb_SP13190514_185943_int"
    performActionInView(cc_view).perform()
