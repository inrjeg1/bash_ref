#!/usr/bin/env python

import re

from os import listdir

def getDirectIncludes(filename):
    with open(filename) as f:
        a = re.findall(r'#include ["<]([\w\.-/]+)[">]', f.read())
        print a



#for fileName in listdir("/boa_prd/ptacken/lil-development/KVLIWC/com/ext/lib/"):
fileName = "/boa_prd/ptacken/lil-development/KMLIWA/com/ext/inc/duract_SplitCowaMeasurementFactory.hpp"
if '.hpp' in fileName:
    print fileName
    getDirectIncludes(fileName)
  

