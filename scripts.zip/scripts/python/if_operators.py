#!/usr/bin/env python


def ifOperators():
    a = True
    b = False
    c = False
    d = True
    
    e = a or b       # True
    f = b or c       # False
    g = a or d       # True
    h = b or c or e  # True

    print "b", b
    b = a or b
    print "b", b
    
    
    
#ifOperators()


def ifOps2():
    alpha = "one"
    bravo = True if "onu" in alpha else False
    print "bravo", bravo
    
    
ifOps2()

