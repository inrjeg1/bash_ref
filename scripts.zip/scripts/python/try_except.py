#!/usr/bin/env python

import os
import sh

def function_with_exception():
   
#   try:
#      sh.diff('-u', output_arguments.py, test_or_operator.py)
#   except:
#      print "Except"
#   finally:
 #      print "finally"
   print "function called"
   
   
   #if sh.diff('-u', output_arguments.py, test_or_operator.py):
   #   print "TRUE"
#
#
#def call_except_function():
#   try:
#      assert 1 == 2
#      print "Hello"
#   except:
#      print "Global except"
#  


a1 = [1, 2, 3, 4, 5, 6]
a2 = [1, 2, 3] + [4, 5]
a2.append(6)

def call_except_function():
   try:
      assert a1 == a2
      print "Succeed!"
   except:
      print "Global except"


call_except_function()

b = 5
a = -b +2
print (a)

