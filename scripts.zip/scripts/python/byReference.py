
#In python objects that are passed are passed BY REFERENCE
# They are passed by value only when it concerns very basic types,
# like integers

class myClass():
    def __init__(self):    
        self.a = 0
        self.b = 0

def callee(someObject):
    someObject.a = 5


def caller():
    myObject = myClass()
    myObject.a = 7
  
    callee(myObject)

    print(myObject.a)
    
#caller()

