#!/usr/bin/env python

def emptySomeFile(fileName):
    print "Cleaning file"
    open(fileName, 'w').close()

#emptySomeFile('someFile')


def writeToNewFile():
    someText = "some text"
    with open ("myNewFile", 'w') as f:
        f.write(someText)
    f.close()
         
writeToNewFile()
