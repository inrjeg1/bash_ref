/*------------------------------------------------------------------------------
|                                                                              |
|                  Copyright (c) 2018, ASML Netherlands B.V.                   |
|                             All rights reserved                              |
|                                                                              |
|-----------------------------------------------------------------------------*/

#ifndef DATA_GARAGE_CAPTUREGWWTRETRIEVEGARAGEFACTORY_HPP
#define DATA_GARAGE_CAPTUREGWWTRETRIEVEGARAGEFACTORY_HPP

#include <boost/shared_ptr.hpp>

#include "KVDIWCxWCxDMA/KVDIWCxWCxDMA_data_gen_Dtos.hpp"
#include "KVDIWCxWCxDMC/KVDIWCxWCxDMC_data_gen_ControlEntityIds.hpp"
#include "KVDIWCxWCxDMA/KVDIWCxWCxDMA_data_gen_DtoFactories.hpp"

namespace KVLIWC {
namespace DataServices {

using KVDIWC::Data::Capture::MultiCaptureMeasurementEntityId;
using KVDIWC::Data::Capture::CaptureGWWDTOPtr;
using KVDIWC::Data::Capture::CaptureGWWDTOFactoryPtr;

class CaptureGwwStoreGarage : private boost::noncopyable
{
public:

   virtual ~CaptureGwwStoreGarage() = default;

   virtual void store(
      const MultiCaptureMeasurementEntityId&,
      const CaptureGWWDTOPtr&) const = 0;

   virtual CaptureGWWDTOFactoryPtr getCaptureGWWFactory() const = 0;

   using pointer = boost::shared_ptr<CaptureGwwStoreGarage>;
};

using CaptureGwwStoreGaragePtr = CaptureGwwStoreGarage::pointer;

}
}

#endif
