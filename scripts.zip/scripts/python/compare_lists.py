
def compareLists():
    received = [
      0.0085000000000000006,
      0.007000000000000001,
      0.0055000000000000005,
      0.0040000000000000001,
      0.0025000000000000005,
      0.0010000000000000009,
      -0.00050000000000000044,
      -0.002,
      -0.0034999999999999996,
      -0.0049999999999999992,
      -0.0064999999999999988,
      -0.0080000000000000002]

    expected = [0.0084999999999999989, 0.0069999999999999993, 0.0054999999999999997, 0.0040000000000000001, 0.0025000000000000001, 0.001, -0.00050000000000000001, -0.002, -0.0035000000000000001, -0.0050000000000000001, -0.0065000000000000006, -0.0080000000000000002]

    
    assert len(received) == len(expected)
    
    
    
    for itemExpected, itemReceived in zip(expected, received):
        
        epsilon = 1e-17
        
        assert abs(itemExpected - itemReceived) < epsilon,(
               'expectedValue = {}, receivedValue = {}, epsilon = {}'
               .format(itemExpected, itemReceived, epsilon))


compareLists()

