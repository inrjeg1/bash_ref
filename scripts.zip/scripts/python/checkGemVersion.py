#!/usr/bin/env python

import subprocess

def printGemVersion():
    print "Gem version:"
    print subprocess.check_output('boa2clearcase -v', shell=True)
    

if __name__ == "__main__":
    printGemVersion()
