#!/usr/bin/env python

#  requires   KVDIWMxWMxDMC
#  requires   KVDIxCORExDMC

# Uppercase before lowercase

a = "KVDIWMxWMxDMC"
b = "KVDIxCORExDMC"

if a < b:
    print "correct"


x = "X"
y = "Y"

if x < y:
    print "also correct"

