#!/usr/bin/env python

from shutil import move

def moveFile():
    move('dummy1', 'dummy2')


moveFile()
