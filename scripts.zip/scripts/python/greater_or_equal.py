#!/usr/bin/env/ python

def someFunction():
    
    a = 5
    b = 6
    
    if b >= a:
        print "b is at least as great as a"
    else:
        print "b is smaller than a"
    


if __name__ == '__main__':
    someFunction()

