#!/usr/bin/env python

import subprocess
from clearcase import get_ccget_config_stack, exec_shell_command

def checkCcsetViewOutput(projectName):
    output = subprocess.check_output("ccset_view -l -u {}".format(projectName+"_int"), shell=True).strip().split('\n')
    
    output = [i.split('_')[0] for i in output]# output[0].split('_')[0]
  
    print output
      
if __name__ == "__main__":  
    #checkCcsetViewOutput("lvl_at_qbl")
    #clearcaseView = "ptacken_lvl_at_qbl_NPI_sp14_int"
    #configStack = get_ccget_config_stack(clearcaseView)
    #levelingBaseline = configStack["baselines"][1]

    featureIntegratorLine = exec_shell_command("cclst_project | grep FI")[0]
    featureIntegrator = featureIntegratorLine.split(" ")[-1].split(')')[0]
    print featureIntegrator

    
   # print "OUTPUT:"
  #  print output
