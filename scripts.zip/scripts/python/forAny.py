#!/usr/bin/env python
#
def checkForAny():
    exceptionList = ['alpha', 'bravo', 'charlie']

    interfaceName = "alpha"

    if not any( x == interfaceName for x in exceptionList):
        print "clear!"
    

def printForIf():
    alphabet = ['alpha', 'bravo', 'charlie', 'delta', 'echo', 'foxtrott']
    randomItems = ['charlie', 'zulu', 'november', 'bravo', 'hotel']
    
    myNewList = list(set([f.split('/')[0] for f in alphabet if f in randomItems]))
    
    print myNewList


def checkIfAnyStringOccurs():
    view1 = "ptacken_at6.3.0.b_p9449_int"
    view2 = "ptacken_at6.1.0.b_p9449_int"
    releases = ['at5.0', 'at6.1', 'at7.3']


    print any(x in view1 for x in releases)
    print any(x in view2 for x in releases)


if __name__ == "__main__":
#    checkForAny()
    #printForIf()
    checkIfAnyStringOccurs()




