#!/usr/bin/env python
#-----------------------------------------------------------------------------#
#                                                                             #
#       Copyright (c) 2018, ASML Holding N.V. (including affiliates).         #
#                         All rights reserved                                 #
#                                                                             #
#-----------------------------------------------------------------------------#

import glob
import os
import re
import sys

sys.path.insert(0, '/boa_prd/ptacken/jenkins-tooling')

from clearcase import get_ccget_config_stack
from syncCommon import getClearcaseViewFromBoa, getRepositoryName


class UpdateListOfDevpatches():
    def __init__(self, viewName, boaPath, configStack):
        self.viewName = viewName
        self.boaPath = boaPath
        self.configStack = configStack
        
    def _getPatchFile(self, userName, baseline):
        newPatchDir = "/exp/s2p/patch/"+userName+"/"+baseline+"/"
        currentWd = os.getcwd()
        os.chdir(newPatchDir)
        tgzFile = glob.glob("*.tgz")[0]
        os.chdir(currentWd)
        return newPatchDir+tgzFile

    def _getNewLevelingPatch(self):
        levelingBaseline = self.configStack["baselines"][1]
        userName = "acilio"
        return self._getPatchFile(userName, levelingBaseline)

    def _getNewProjectPatch(self):
        projectBaseline = self.configStack["baselines"][0]
        userName = self.viewName.split("_")[0]
        return self._getPatchFile(userName, projectBaseline)

    def _fillReplacementList(self, devbenchFile):
        projectName = self.configStack["projects"][0]
        replacements = {}
        for line in devbenchFile:
            if "devbench create" in line:
                oldBaseline = line.split(" ")[3]
                allBaselines = self.configStack["baselines"]
                newBaseline = allBaselines[len(allBaselines) - 1]
                replacements[oldBaseline] = newBaseline
            elif "asml_patch install" in line:
                if "lvl_at_qbl_integration" in line:
                    oldLevelingPatch = line.split("asml_patch install ")[1].replace("\"", "").strip()
                    newLevelingPatch = self._getNewLevelingPatch()
                    replacements[oldLevelingPatch] = newLevelingPatch
                elif projectName in line:
                    oldProjectPatch = line.split("asml_patch install ")[1].replace("\"", "").strip()
                    newProjectPatch = self._getNewProjectPatch()
                    replacements[oldProjectPatch] = newProjectPatch
        return replacements

    def update(self):
        print "=== Updating devpatches in create_devbench.sh ==="
        devbenchFile = self.boaPath+'/create_devbench.sh'
        if os.path.exists(devbenchFile):
            with open (devbenchFile) as f:
                replacements = self._fillReplacementList(f)
            with open (devbenchFile) as f:
                fileContents = f.read()
            with open(devbenchFile, "w") as f:
                for key in replacements:
                    fileContents = re.sub(key, replacements[key], fileContents)
                f.write(fileContents)
        else:
            print "--> create_devbench.sh not found"


if __name__ == '__main__':
    currentWd = os.getcwd()
    boaPath = currentWd.split('/')[-1]
    if 'lil' not in boaPath:
        print "You need to be in the root of your BOA"
        exit(1)

    boaPath = currentWd
    clearcaseView = getClearcaseViewFromBoa(boaPath)
    if not clearcaseView:
        print "No clearcase view found! Exiting now."
        exit(1)
    print "-> Clearcase view: ", clearcaseView

    repositoryName = getRepositoryName(boaPath)
    configStack = get_ccget_config_stack(clearcaseView)

    UpdateListOfDevpatches(clearcaseView, boaPath, configStack).update()
