#!/usr/bin/env python

import subprocess

from clearcase import exec_shell_command

def getViewName():
    cmd = "cleartool pwv -short"
    viewName = subprocess.check_output([cmd], 
                                       shell=True).strip()
    print "VIEWNAME: "  + viewName
    
def getViewNameFromExecShellCommand():
    viewName = exec_shell_command("cleartool pwv -short")
    print viewName[0]

getViewNameFromExecShellCommand()
#getViewName()

