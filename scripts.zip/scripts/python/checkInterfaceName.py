#!/usr/bin/ev python


def checkName():
    interfaceName = "GTKMxABxCD"
    ccName = "component MKGT"
    interfaceName = "KMxABxCD"
    ccName = "component KM"
    
    while len(interfaceName) > 0:
        if "component " + interfaceName in ccName:
            print interfaceName
            break
        interfaceName = interfaceName[:-1]
    print interfaceName
    if interfaceName:
        print "YES"
    if not interfaceName:
        print "NO"    
        
checkName()        
