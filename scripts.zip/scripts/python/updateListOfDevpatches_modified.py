#!/usr/bin/env python
#-----------------------------------------------------------------------------#
#                                                                             #
#       Copyright (c) 2018, ASML Holding N.V. (including affiliates).         #
#                         All rights reserved                                 #
#                                                                             #
#-----------------------------------------------------------------------------#

import argparse
import glob
import os
import re
import sys

sys.path.insert(0, '/boa_prd/ptacken/jenkins-tooling')

from clearcase import get_ccget_config_stack
from syncCommon import getClearcaseViewFromBoa, getRepositoryName


class UpdateListOfDevpatches():
    def __init__(self, viewName, boaPath, configStack):
        self.viewName = viewName
        self.boaPath = boaPath
        self.configStack = configStack
        
    def _getPatchFile(self, userName, baseline):
        newPatchDir = "/exp/s2p/patch/"+userName+"/"+baseline+"/"
        currentWd = os.getcwd()
        os.chdir(newPatchDir)
        tgzFile = glob.glob("*.tgz")[0]
        os.chdir(currentWd)
        return newPatchDir+tgzFile

    def _getNewLevelingPatch(self):
        levelingBaseline = self.configStack["baselines"][1]
        userName = "schavate"
        return self._getPatchFile(userName, levelingBaseline)

    def _getNewProjectPatch(self):
        projectBaseline = self.configStack["baselines"][0]
        userName = self.viewName.split("_")[0]
        return self._getPatchFile(userName, projectBaseline)

    def _fillReplacementListInstallPatches(self, patchesFile):
        replacements = {}
        for line in patchesFile:
            if "asml_patch install" in line:
                if "lvl_at_qbl_integration" in line:
                    oldLevelingPatch = line.split("asml_patch install ")[1].replace("\"", "").strip()
                    replacements[oldLevelingPatch] = self._getNewLevelingPatch()
                elif "lvl_at_qbl" in line:
                    oldProjectPatch = line.split("asml_patch install ")[1].replace("\"", "").strip()
                    #newProjectPatch = self._getNewProjectPatch()
                    newProjectPatch = "/exp/s2p/patch/ptacken/lvl_at_qbl_NPI_SP13_integration_190430_115404/AT_9.9.9.d-20190328_000000_lvl_at_qbl_NPI_SP13_integration_190430_115404-20190501_103242.tgz"
                    replacements[oldProjectPatch] = newProjectPatch
        return replacements

    def _fillReplacementListCreateDevbench(self, devbenchFile):
        replacements = {}
        for line in devbenchFile:
            if "devbench create" in line:
                oldBaseline = line.split(" ")[3]
                allBaselines = self.configStack["baselines"]
                newBaseline = allBaselines[len(allBaselines) - 1]
                replacements[oldBaseline] = newBaseline
        return replacements

    def update(self):
        print "=== Updating baseline in create_devbench.sh ==="
        devbenchFile = self.boaPath+'/create_devbench.sh'
        if os.path.exists(devbenchFile):
            with open (devbenchFile) as f:
                replacements = self._fillReplacementListCreateDevbench(f)
            with open (devbenchFile) as f:
                fileContents = f.read()
            with open(devbenchFile, "w") as f:
                for key in replacements:
                    fileContents = re.sub(key, replacements[key], fileContents)
                f.write(fileContents)
        else:
            print "--> create_devbench.sh not found"
            
        print "=== Updating devpatches in install_patches.sh ==="
        devbenchFile = self.boaPath+'/install_patches.sh'
        if os.path.exists(devbenchFile):
            with open (devbenchFile) as f:
                replacements = self._fillReplacementListInstallPatches(f)
            with open (devbenchFile) as f:
                fileContents = f.read()
            with open(devbenchFile, "w") as f:
                for key in replacements:
                    fileContents = re.sub(key, replacements[key], fileContents)
                f.write(fileContents)
        else:
            print "--> create_devbench.sh not found"
            

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("-v", "--view",
                        help="Specify a custom view to sync from")
    args = parser.parse_args()
   
    currentWd = os.getcwd()

    boaPath = currentWd.split('/')[-1]
    if 'lil' not in boaPath:
        print "You need to be in the root of your BOA"
        exit(1)

    boaPath = currentWd
    if args.view:
        clearcaseView = args.view
    else:
        clearcaseView = getClearcaseViewFromBoa(boaPath)
        if not clearcaseView:
            print "No clearcase view found! Exiting now."
            exit(1)
    print "-> Clearcase view: ", clearcaseView

    repositoryName = getRepositoryName(boaPath)
    configStack = get_ccget_config_stack(clearcaseView)

    UpdateListOfDevpatches(clearcaseView, boaPath, configStack).update()
