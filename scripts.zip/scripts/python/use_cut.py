#!/usr/bin/env python


def getLine():
    with open ("dummy.txt") as f:
        for line in f:
            if "test_Bag" in line:
                print line.split("=")[1].strip()


def cutFromGivenField():
    alpha = "lvl_at_qbl_integration_180410_233701"
    bravo = "lvl_at7.3_integration_180412_002801"

    charlie = alpha.split("_integration")[0]
    delta = bravo.split("_integration")[0]
    print charlie
    print delta

#getLine()
#cutFromGivenField()


def cutCharacters():
    mystring = "alpha/bravo/charlie"
    cutFirst = mystring[1:]
    print "cut first: " + cutFirst
    
    cutLast = mystring[:-1]
    print "cut last: " + cutLast
    

cutCharacters()

