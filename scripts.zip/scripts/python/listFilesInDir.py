#!/usr/bin/env python

import glob

def listFilesInThisDir():
    print glob.glob("*/dummy*")
    
    
if __name__ == "__main__":
    listFilesInThisDir()


