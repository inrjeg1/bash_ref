#!/usr/bin/env python
#-----------------------------------------------------------------------------#
#                                                                             #
#       Copyright (c) 2019, ASML Holding N.V. (including affiliates).         #
#                         All rights reserved                                 #
#                                                                             #
#-----------------------------------------------------------------------------#

import argparse
import subprocess
import xml.etree.ElementTree as ET

class colors:
    TITLE = '\033[47m'
    FAILURE = '\033[41m'
    SUCCESS = '\033[42m'
    ERROR = '\033[43m'
    NEUTRAL = '\033[0m'

def parseXmlToDictionary(scenarios, xmlStruct):
    for task in xmlStruct.iter('task'):            
        scenarioName = task.iter('scenario_name').next().text
        taskStatus = task.iter('task_status').next().text
        if (taskStatus == "DONE"):
            scenarioResult = task.iter('scenario_result').next().text
        else:
            scenarioResult = taskStatus
        configurationId = task.iter('configuration_id').next().text
        machineType = task.iter('machine_type').next().text
        ## ID of first testcase added to make scenario unique (hopefully)
        testCaseId = "NONE"
        for testCases in task.iter('test_cases'):
            for testCase in testCases.iter('test_case'):
                for tcId in testCase.iter('tc_id'):
                    testCaseId = tcId.text
                    break
                break
            break
        key = scenarioName + ':' + configurationId + '__' + '_' + machineType + '__' + testCaseId

        comment = ""
        if (not (task.iter('user_status').next().text == None)):
            comment = " " + task.iter('user_status').next().text
        scenarios[key] = (scenarioResult, comment)
 

def getColorForTestResult(testResult):
    if testResult == "PASS":
        return colors.SUCCESS
    elif testResult == "FAIL":
        return colors.FAILURE
    else:
        return colors.ERROR

def getRefRunKey(key, scenariosRefRun):
    if key in scenariosRefRun:
        return key
    elif key.endswith("__NONE"):
        partWithoutNONE = "__".join(key.split('__')[:-1])
        for keyTest in scenariosRefRun:
            if keyTest.startswith(partWithoutNONE):
                return keyTest
    else:
        partWithoutTcId = "__".join(key.split('__')[:-1])
        newKey = partWithoutTcId + "__NONE"
        return newKey

def compareRuns(testId, refId):
    scenariosTestRun = {}
    scenariosRefRun = {}

    testXml = subprocess.check_output(['testarena getresult --tc '+ testId], shell = True)
    refXml = subprocess.check_output(['testarena getresult --tc '+ refId], shell = True)

    testET = ET.fromstring(testXml)
    refET = ET.fromstring(refXml)

    parseXmlToDictionary(scenariosTestRun, testET)
    parseXmlToDictionary(scenariosRefRun, refET)

    collumnWithScenario = 100
    collumnWidthResult = 12
    collumnWidthComment = 50
    collumnWidthName = min(max(len(key.split('__')[0]) for key in scenariosTestRun if not (scenariosTestRun[key][0] == "PASS")), collumnWithScenario) +2

    print colors.TITLE+ "SCENARIO".center(collumnWidthName) + testId.center(collumnWidthResult) +\
         refId.center(collumnWidthResult) + "COMMENT".center(collumnWidthComment) + colors.NEUTRAL
    for key in scenariosTestRun:
        testRunResult = scenariosTestRun[key][0]
        if (testRunResult != 'PASS'):
            colorTest = getColorForTestResult(testRunResult)
            scenarioString = key.split('__')[0][:collumnWidthName -2].ljust(collumnWidthName).replace(' ', '-')
            testString = colorTest + testRunResult.center(collumnWidthResult)
            commentString =  colors.NEUTRAL + scenariosTestRun[key][1][:collumnWidthComment].ljust(collumnWidthResult)
            refRunKey = getRefRunKey(key, scenariosRefRun)
            if refRunKey in scenariosRefRun:
                colorRef = getColorForTestResult(scenariosRefRun[refRunKey][0])
                refString = colorRef + scenariosRefRun[refRunKey][0].center(collumnWidthResult)
            else:
                colorRef = colors.NEUTRAL
                refString = colorRef +  "-".center(collumnWidthResult)
            print scenarioString + testString + refString + commentString

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-t", "--testrun",
                        help="Test run id",
                        required = True)
    parser.add_argument("-r", "--referencerun",
                        help="Reference run id",
                        required = True)
    args = parser.parse_args()
    compareRuns(args.testrun, args.referencerun)
