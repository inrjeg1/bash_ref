#!/usr/bin/env python

def checkBeforeAssigning():
    a = None
    
    if not a:
        print "NOT a"
    else:
        print "a exists"

checkBeforeAssigning()
