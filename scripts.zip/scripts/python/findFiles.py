#!/usr/bin/env python

from glob import glob

def findFiles():
    searchPath = "/exp/s2p/patch"
    patchName = "lvl_at_qbl_integration_191220_141751"

    print glob(searchPath + "/fn-dai*/" + patchName + "/AT*")[0]


findFiles()
