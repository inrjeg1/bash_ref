import zipfile

def do_unzip(zipped_file):
    print "UNZIPPING"
    zip_ref = zipfile.ZipFile(zipped_file, 'r')
    zip_ref.extractall('./')
    zip_ref.close()  
    


do_unzip('./earth_topography.zip')
