#!/usr/bin/env python


def do_something_else():
   print "something else!"


def print_text():
   print "Hello world!"
   do_something_else()


def print_with_assert():
    a = 1
    b = 2
    
    try:
        assert a == b, 'Some text \
           Some more text'
    except:
         print 'FAILED!'


def printWithParams():
    a = "ALPHA"
    b = "BRAVO"
    c = 3
    print "This is",a,"string" , b , "with",c,"arguments", a, b

def printString():
    a = 2
    print "\nalpha ", a, " bravo\n", a+1


def printWithBrackets():
    a = "alpha"
    c = "charlie"
    print (a +" bravo " + c + " delta")


class colors:
    SUCCESS = '\033[32m'
    FAILURE = '\033[31m'
    BOLD = '\033[1m'
    NEUTRAL = '\033[0m'

def checkBorderSize():
    cwbdChecks = {}
    cwbdChecks['x-ray'] = "UNRESOLVED"
    cwbdChecks['yankee'] = "FAIL"
    cwbdChecks['zulu'] = "PASS"
    
    if "FAIL" in cwbdChecks.values() or "UNRESOLVED" in cwbdChecks.values():
        print colors.FAILURE
        print "=============================================="
        print "= FAILED: ONE OR MORE CWBD CHECKS HAVE FAILED ="
        print "==============================================\n"
        for checkName in cwbdChecks.keys():
            if cwbdChecks[checkName] == "FAIL" or cwbdChecks[checkName] == "UNRESOLVED":
                print "  -->", cwbdChecks[checkName], " " * (len("UNRESOLVED") - len(cwbdChecks[checkName])), checkName
        print colors.NEUTRAL
    else:
        print colors.SUCCESS
        print "\n========================================"
        print "= SUCCESS: ALL CWBD CHECKS HAVE PASSED ="
        print "========================================\n"
        print colors.NEUTRAL


checkBorderSize()
#printWithBrackets()
#print_text()
#print_with_assert()
#printWithParams()
#printString()
