#!/usr/bin/env python

myString = "alpha1bravo2charlie3"

myString2 = ''.join(x for x in myString if (x.isdigit() or x.isalpha()))

print myString2

