#!/usr/bin/env python

import logging
import re
import subprocess
import time


def exec_shell_command(cmd, view=None, raise_error=True):
   """ Execute a command in shell environment and return its output as array of strings
   Raises an exception if the exit status != 0
   Logs the output.
   
   :param cmd   The command to execute. Should not contain double quotes...
   :param view  If a view is given, the command is echo'ed and piped to ccset_view, to be executed in view.
   """
   output = []

   if "\'" in cmd:
      raise SystemError("command should not contain single quotes. "+str(cmd))

   if view:
      cmd = "echo '{}' | ccset_view {}".format(cmd, view)
   logging.getLogger(__file__).debug("Exec: "+cmd)

   ansi_escape_re = re.compile(r'\x1B\[[0-?]*[ -/]*[@-~]')
   process = subprocess.Popen(cmd,
                           shell=True,
                           stdout=subprocess.PIPE,
                           stderr=subprocess.STDOUT
                           )
   for line in iter(process.stdout.readline,''):
      line = line.strip()
      line = ansi_escape_re.sub('', line)
      # problematic log statement: it can generate ~1GB of data
#      logging.getLogger(__file__).debug(line)
      output.append(line)
      time.sleep(0) # yield to other thread

#   returncode = process.wait()
   returncode = 1
   if raise_error and returncode != 0:
      raise SystemError("Error executing: " +cmd + " Output: " + str(output))
   return output


def create_new_project_baseline():
    cmd = "ccmk_bl && ccset_bl_stat -P BUILT && ccset_bl_stat -r"
    output = exec_shell_command(cmd)
    print output
 


def isSolarisRelease():
    cmd = 'cleartool lsstream | cut -d" " -f3'
    streamName = exec_shell_command(cmd, 'ptacken_at6.1_pc9547_int')[0]
    for release in ['at5.0', 'at6.1', 'at7.3']:
        if release in streamName:
            return True
    return False

    
def getBaselineName():
    cmd = 'ccget_config | grep "\<proj\>" | head -1 | cut -d"<" -f2 | cut -d">" -f2'
    projectName = exec_shell_command(cmd, 'ptacken_at6.1_pc9547_int')[0]
    cmd = 'ls -t /exp/'+projectName+'/ | head -1'
    baselineName = exec_shell_command(cmd,'ptacken_at6.1_pc9547_int')[0]

    return baselineName


def createDevpatch():
    print "=== Creating devpatch ==="

    devpatchName = getBaselineName()
    isSolaris = isSolarisRelease()
    if isSolaris:
        cmd = 'ccmk_devpatch -T ALL -o ' + devpatchName
    else:
        cmd = 'generate-patch -T ALL ' + devpatchName

    returnVal = exec_shell_command(cmd, 'ptacken_at6.1_pc9547_int')
    print "RETURN: ", returnVal
    if returnVal != 0:
        exit(1)

def bla():
    a =  ['Running: ccmk_devpatch.sun -T ALL -o at6.1_pc9547_integration_180419_162239', 'ccmk_devpatch.sun: INFO: Collecting PKG_contents files.', "ccmk_devpatch.sun: INFO: Collecting all packages in: '/vobs/litho/pkg/ATLAS_1.0.0'.", 'ccmk_devpatch.sun: INFO: Adjusting relative/oldsystem locations.', "ccmk_devpatch.sun: INFO: Collecting all packages in: '/exp/at6.1_pc7016/at6.1_pc7016_integration_180309_105741/pkg/ATLAS_1.0.0'.", 'ccmk_devpatch.sun: INFO: Adjusting relative/oldsystem locations.', 'ccmk_devpatch.sun: INFO: Determining changed targets.', 'ccmk_devpatch.sun: INFO: Determining deleted targets.', 'ccmk_devpatch.sun: INFO: Collecting installable packages.', 'ccmk_devpatch.sun: INFO: The next platforms are supported: NT1', '----------------------------------------', 'Number of targets to patch: 542', 'Patch created in: /exp/s2p/patch/ptacken/at6.1_pc9547_integration_180419_162239', '----------------------------------------', "ccmk_devpatch.sun: INFO: Patch prediction/generation 'OK'", 'ccmk_devpatch.sun: INFO: Total running time was: 00:02:21', "ccmk_devpatch.sun: INFO: See '/vobs/litho/pkg/PKG_diff.PDF' for results!", 'ccmk_devpatch.sun: WARNING: 43  targets were deleted!', 'ccmk_devpatch.sun:          These targets will be deleted by the development patch tooling:', 'ccmk_devpatch.sun:            Will not show deletions if more then 10 targets are deleted, look in the PKG_diff.exp for all details!']
    print("\n".join(a))

#bla()
createDevpatch()

#create_new_project_baseline()

#self.logger.info("Making dumbo...")
#cmd = "ccmk_dumbo -b {} {}{}".format(self.baseline, self.dumbo_name, self.get_baseline_timestamp())
#output = self.exec_shell_command(cmd)
#for line in output:
# if "The created VIEW is: " in line:
#    self.view = line.replace("The created VIEW is: ", "")
#    self.logger.info("Created dumbo view: "+self.view)
