#!/usr/bin/env python


with open('mcs_tmp') as f:
    for line in f:
        
        actual = line.strip().split(',')[1]
        changed = line.strip().split(',')[2]
        if not (actual == changed):
            print line.strip().split(',')[0]
            print "Actual: ", actual
            print "Changed ", changed, "\n"
