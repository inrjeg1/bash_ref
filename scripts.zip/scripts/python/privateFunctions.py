#!/usr/bin/env python


def _privateFuncA():
    print "This is a private function outside of the class"


class Alpha():
    def funcA(self):
        print "This is function A inside a class"
        __privateFuncA()

