#!/usr/bin/env python

import subprocess

subprocess.Popen(['bash', '-c', ' . printHelloWorld.sh; printHelloWorldFunc'])
