#!/usr/bin/env python

def whileTrue():
    someNumber = 2
    while True:
        print "N: ", someNumber
        someNumber += 1
        if someNumber > 7:
            return someNumber
        print "SOME MORE TEXT"       
    



def callWhileTrue():
    print "Text before call"
    output = whileTrue()
    print "Text after call"
    
    print "OUTPUT:", output


callWhileTrue()

