#!/usr/bin/env python

def someOtherFunction():
    print "some other function"
    exit(1)
