#!/usr/bin/env python

#def createDictionary():
#    d = {}
#    d['blue'] = [('SMURF', 1)]
#    d['red'] =  ['APPLE']
#   
#    d['blue'].append(('CAR', 2))
#
#    print d['blue']
#    print d
#    
# 
#def appendToDictionary():
#    a = {}
#    a['alpha'] = [1]
#    print a
#    a['alpha'].append(2)
#    print a
#    
#    for key in a:
#        print key, ":"
#        for value in a[key]:
#            print value
#
#appendToDictionary()    
#    
#createDictionary()

#
def appendToDictionary(someNumber, myDictionary):
    myDictionary[someNumber].append("b")

def dictionaryByReference():
    myDict = {}
    someNumber =1
    myDict[someNumber] = ["a"]
    appendToDictionary(someNumber, myDict)
    
    print myDict
    

#
#

def complexerDictionary():
    myDict = {}
    myDict['a'] = [("alpha", "green")]
    myDict['a'].append(("alpha", "blue"))
    #myDict['a'].append(("alpha", "red"))
    myDict['a'].append(("bravo", "orange"))
    myDict['b'] = [("charlie", "purple")]
    
    for key in myDict:
        myDictionary = dict(myDict[key])
        print myDictionary
        value = myDictionary.get("alpha")
        
        print value
        #for (first, second) in myDict[key]:
        #    print (first, second)
    
#complexerDictionary()

#def dictionaryWithMultipleValues():
#    myDict = {}
#    firstVal = 7
#    secondVal = 42
#    
#    myDict["alpha"] = (firstVal, secondVal)
#    
#    print myDict["alpha"][0]
#    
#dictionaryWithMultipleValues()   
#    


def addUniqueItemToDictionary(dictionary, key, value):
    if key in dictionary:
        if not any(item == value for item in dictionary[key]):
            dictionary[key].append(value)
    else:
        dictionary[key] = [value]
    return dictionary

def dictionaryWithDuplicates():
    myDict = {}
    addUniqueItemToDictionary(myDict, 'a', 'alpha')
    addUniqueItemToDictionary(myDict, 'a', 'bravo')
    addUniqueItemToDictionary(myDict, 'a', 'alpha')
    addUniqueItemToDictionary(myDict, 'b', 'alpha')
    addUniqueItemToDictionary(myDict, 'b', 'bravo2')
    addUniqueItemToDictionary(myDict, 'c', 'charlie')
    
    for key in myDict:
        print "--> " + key +" <---"
        print myDict[key]
 

def createEmptyDictionaryItem():
    myDictA = {}
    myDictB = {}
    addUniqueItemToDictionary(myDictB, 'a', 'alpha')
    addUniqueItemToDictionary(myDictB, 'a', 'bravo')

    myDictA['a'] = []
    addUniqueItemToDictionary(myDictA, 'a', 'alpha')
    addUniqueItemToDictionary(myDictA, 'a', 'bravo')
   
    myDictC = {}
    myDictC['a'] = "charlie"
    if myDictC:    
        print "Exists"
    else:
        print "Does NOT Exist"

    
def loopOverDictionary():
    myDict = {'a':'alpha', 'b':'bravo', 'c':'charlie', 'd':'delta'}
    myKeys = myDict.iterkeys()
    for key in myKeys:
        print "KEY:", key
        if not myKeys.next():
            print "RETURNING"
            return
        print "ALL:", key, myDict[key]
    
 
 
def getAllValues():
    myDict = {'a':'alpha', 'b':'bravo', 'c':'charlie', 'd':'delta'}
    print myDict.values()
    

def checkOccurrence():
    myDict = {'a':['alpha'], 'b':['bravo'], 'c':['charlie'], 'd':['delta']}

    myDict['b'].append('other')
    myList = []
    myList.append("someString")
    myList.append("thebravonet")
    
    print "d: ", myDict
    print "l: ", myList

    print any(x in item for item in myList for x in myDict['b'])


def checkAllKeys():
    myDict = {}
    myDict['alpha'] = True
    myDict['bravo'] = True
    myDict['charlie'] = True
    
    if all(myDict.values()):
        print "ALL PASSED"
    


def dictionaryAsOptionalArgument(argDict = {}):
    argDict["xray"] = 5
    argDict["yankee"] = 7

def dictionaryAsOptionalArgument2(argDict = {}):
    argDict["mike"] = 3
    argDict["november"] = 4

def callFunctionWithAndWithoutDictionary():
    myDict = {}
    myDict["alpha"] = 1
    myDict["bravo"] = 2
    dictionaryAsOptionalArgument()
    print "After call without argument"
    print myDict
    dictionaryAsOptionalArgument(myDict)
    print "After call WITH argument"
    print myDict
    dictionaryAsOptionalArgument2()
    print "After call without argument2"
    print myDict
    dictionaryAsOptionalArgument2(myDict)
    print "After call WITH argument2"
    print myDict
 
 
def someCalculations():
    myDict = {}
    myDict['alpha'] = 2
    myDict['alpha'] += 1
    print myDict
 
 
def copyKeysFromList():
    myList = ['a', 'bravo', 'c']
    myDict = {}
    for item in myList:
        myDict[item] = 0 
    print myDict
    

copyKeysFromList()
#someCalculations()    
#callFunctionWithAndWithoutDictionary()
#checkAllKeys()
#checkOccurrence()
#getAllValues()
#loopOverDictionary()
#dictionaryWithDuplicates()
#dictionaryByReference()
#createEmptyDictionaryItem()   

