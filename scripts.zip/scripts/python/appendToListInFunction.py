#!/usr/bin/env python


def functionACaller():
    listA = []
    listA.append('a')
    c = ['e', 'f']
    listA.extend(c)
    listA.extend('g')
    listA.append('h')
    listA.extend(['i', 'j'])
    print listA


if __name__ == "__main__":
    functionACaller()
