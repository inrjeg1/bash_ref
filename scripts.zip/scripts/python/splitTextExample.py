#!/usr/bin/env python

import os


fileName = "KVLIWM/com/ext/inc/someFile.hpp"

extension = os.path.splitext(fileName)[1]
print extension

