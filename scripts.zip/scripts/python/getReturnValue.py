#!/usr/bin/env python

def returnSomeString():
    someString = "Some string"
    return someString
    return "another string"

def getSomeString():
    myString = returnSomeString()
    print myString
    

def functionJustReturns():
    return


def getMultiple():
    a = ['charlie', 'detla', 'echo']
    b = True
    return (a,b)

def multipleReturns():
    (alpha, bravo) = getMultiple()
    
    print "alpha:", alpha
    print "bravo:", bravo

    
if __name__ == "__main__":
    #getSomeString()
    #functionJustReturns()
    #print "After returning fuction"

    multipleReturns()
