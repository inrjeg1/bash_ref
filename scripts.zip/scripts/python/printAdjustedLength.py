#!/usr/bin/env python

def printBasedOnMessage(message):
    length = len(message)
    print "=" * (length + 4)
    print "=", message, "="
    print "=" * (length + 4)
    
    
printBasedOnMessage("A")    
printBasedOnMessage("My message")
printBasedOnMessage("Some other message")

