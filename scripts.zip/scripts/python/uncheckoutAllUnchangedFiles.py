#!/usr/bin/env python
#-----------------------------------------------------------------------------#
#                                                                             #
#       Copyright (c) 2019, ASML Holding N.V. (including affiliates).         #
#                         All rights reserved                                 #
#                                                                             #
#-----------------------------------------------------------------------------#

import argparse
import os
import sh
import subprocess

from clearcase import exec_shell_command


def getBuildscope(viewName):
    FNULL = open(os.devnull, 'w')
    cmd = "echo '{}' | ccset_view {}".format('ccget_buildscope | cut -d\'/\' -f2', viewName)
    buildscope = subprocess.check_output(cmd, shell=True, stderr= FNULL).split("\n")
    return [x for x in buildscope if x]


def getPullTags(git):
    git(['fetch', '--tags'])
    allTags = git(['log', '--tags', '--simplify-by-decoration', '--pretty=%d'])
    allTags = subprocess.Popen('echo  "%s" | grep -F "tag:"' % allTags,
                                shell=True, 
                                stdout=subprocess.PIPE).stdout.read().strip().split("\n")
    newestPullTag = None
    referenceTag = None
    for tagline in allTags:
        tagline = tagline.split('(')[1].split(')')[0].split(',')
        pullFromBoaTags = [x for x in tagline if "pull-from-boa" in x]
        if pullFromBoaTags:
            pullTag = pullFromBoaTags[0].split(' ')[-1]
            if not newestPullTag:
                newestPullTag = pullTag
            else:
                if any(x for x in tagline if "sync-tag-" in x):
                  referenceTag = pullTag
                  return (newestPullTag, referenceTag)


def checkoutHasChangedInBoa(git, newestPullTag, referenceTag, checkout, buildscope, isDirectory):
    for depth, directory in enumerate(reversed(checkout.split("/")), 1):
        if directory in buildscope:
            checkoutPathBoa = "/".join(checkout.split("/")[-depth:])
            break
    if isDirectory:
        diffoutput = git(['diff', '--name-only', '--diff-filter=ADR', referenceTag, newestPullTag, '--', checkoutPathBoa])
    else:
        diffoutput = git(['diff', referenceTag, newestPullTag, '--', checkoutPathBoa])
    return diffoutput


def uncheckoutFilesThatHaveNotChangedInBoa(viewName, git):
    print "=== Performing uncheckout of all files and directories that have not changed in BOA ==="
    buildscope = getBuildscope(viewName)
    allCheckouts = exec_shell_command('cleartool lsco -avobs -cview -s', viewName)
    allCheckouts = [x for x in allCheckouts if "scope.txt.2" not in x]
    (newestPullTag, referenceTag) = getPullTags(git)
    print "--> New pull tag:      ", newestPullTag
    print "--> Reference pull tag:",referenceTag + "\n"
    for checkout in allCheckouts:
        isDirectory = os.path.isdir("/view/"+viewName+"/"+checkout)
        if not checkoutHasChangedInBoa(git, newestPullTag, referenceTag, checkout, buildscope, isDirectory):
            print "--> Performing uncheckout of", checkout
            output = exec_shell_command('cleartool unco -rm ' + checkout , viewName)
            print "\n".join(output) + "\n"


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-r", "--repo",
                        help="Specify a local git repository",
                        required=True)
    parser.add_argument("-v", "--view",
                        help="Specify a custom view to sync to")
    args = parser.parse_args()

    cmd = "cleartool pwv -short"
    viewName = subprocess.check_output([cmd], shell=True).strip()    
    if viewName == "** NONE **":
        if args.view:
            viewName = args.view
        else:
            print "You need to be in a clearcase view or provide a view name using -v"        
            exit(1)

    boaPath = args.repo
    git = sh.git.bake(_cwd=boaPath, _tty_out=False)
    uncheckoutFilesThatHaveNotChangedInBoa(viewName, git)
