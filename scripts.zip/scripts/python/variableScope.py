#!/usr/bin/env python

def funcB(a):
    a[2] = 3
    return a

def funcB():
    a = {}
    a[3] = 5
    return a

def funcA():
    a = {}
    b = {}
    c = {}
    d = {}
    b[2] = 4
    c[3] = 9
    
    a.update(b)
    a.update(c)
    b[2] = 8
    a.update(b)
    a.update(funcB())

    print a

funcA()
