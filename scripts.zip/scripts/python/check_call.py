#!/usr/bin/env python

import subprocess
import sh

from common import gem, workingDirectory, printOutput
from clearcase import exec_shell_command

def check_call():
    boaPath = "/boa_prd/ptacken/lil-development"
    with workingDirectory(boaPath):
        #sh.gradle('fetchGrants', _out=printOutput, _err=printOutput)
        returnVal = subprocess.call("check_grants", shell=True)
        print returnVal
        


def checkWhetherActivityExists(viewName):
    print "=== Checking for existing activity ==="
    activity = exec_shell_command('cleartool lsact -cact -cview', viewName)
    if not activity:
        print "--> No activity found! Exiting now"
        exit(1)
    else:
        print "--> Activity found:", activity
        

#checkWhetherActivityExists("ptacken_at6.1_pc6703_int")

def createClone():
    for line in sh.git.clone("ssh://git@boa-srm-eid.asml.com:7999/metlev/ifpc-development.git", "/sdev_shared/fc062data/PTAD/scripts/python/cloneTest", 
                             '--progress', '--recursive', _err_to_out=True, _iter=True, _out_bufsize=100):
        print line
    

#createClone()


def findCCview():
    clearcaseView = ""
    with open ("dummy.txt") as f:
        for line in f:
            if "view_name" in line:
                clearcaseView = line.split(":")[2].strip()
    
    return clearcaseView

#ccview = findCCview()

#if not ccview:
#    print "not found!"
#else:
#    print ccview


def check_call_with_ls():
    subprocess.check_call(["ls", "-1"])
    #subprocess.check_output(["ls", "-1"])

def call_with_ls():
#    subprocess.call(["ls", "-1"])
    subprocess.call("ls -1", shell=True)

check_call_with_ls()
#call_with_ls()

    
