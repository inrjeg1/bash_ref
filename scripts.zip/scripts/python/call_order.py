#!/usr/bin/env python

def callFunctionA():
    functionA()
    
def functionA():
    print "functionA called"

callFunctionA()
