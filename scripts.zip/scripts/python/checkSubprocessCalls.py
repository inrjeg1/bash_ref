#!/usr/bin/env python

import subprocess


def checkSubprocessCalls():
    print "call"
    output = subprocess.call(['ls ALPHA_BRAVO > /home/ptacken/public/tmp_190624'], shell=True)

    print "output: ", output

    if output:
        print "ERROR"
    
    
    print "check call"
    subprocess.check_call('ls ALPHA > /home/ptacken/public/tmp_190624', shell=True)
     
    print "check output"
    subprocess.check_output('ls ALPHA > /home/ptacken/public/tmp_190624', shell=True)
    
    
    
    print "After"
    
   # print "OUTPUT"
   # print output


if __name__ == "__main__":
    checkSubprocessCalls()
