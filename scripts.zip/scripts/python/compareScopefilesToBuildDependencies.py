#!/usr/bin/env python

from common import addItemToDictionary, getBuildDependencyFiles
import argparse
import collections
import os
import subprocess

from glob import glob

class colors:
    BOLD = '\033[1m'
    NEUTRAL = '\033[0m'


class compareScopeClearcaseBoa():
    def __init__(self, viewName, boaPath):
        self.viewName = viewName
        self.boaPath = boaPath
        self.interfacesDdgen = os.listdir("/view/" + self.viewName + "/vobs/litho/xifs/ddgen/")
        self.interfacesBasic = os.listdir("/view/" + self.viewName + "/vobs/litho/xifs/basic/")


    def _targetCheckOK(self, target):
        return not (target in self.interfacesDdgen or 
                    target in self.interfacesBasic or
                    target == "ddgen" or
                    target == "basic" or
                    target == "__init__.py" or
                    target == "python" or
                    target =="EREXXA" or
                    "_i.py" in target or
                    target.startswith("ERx") or
                    target.startswith("DDXA"))
                    

    def _getAllScopefiles(self):
        FNULL = open(os.devnull, 'w')
        bbList = []
        scopefileList = []
        cmd = "echo '{}' | ccset_view {}".format('ccget_buildscope', self.viewName)
        buildscope = subprocess.check_output(cmd, shell=True, stderr= FNULL).split("\n")

        ccList = ["/view/" + self.viewName + "/vobs/litho/" + x for x in buildscope if x]

        for component in ccList:
            pathToXscm = component + "/../xscm"
            os.chdir(pathToXscm)
            currentDir = os.getcwd()
            if not currentDir in bbList:
                bbList.append(currentDir)
                for bbFile in glob("BB-*ternal_scope.txt.2"):
                    scopefileList.append(currentDir + "/" + bbFile)
                for bbFile in glob("BB-*system_scope.txt.2"):
                    scopefileList.append(currentDir + "/" + bbFile)
                for bbFile in glob("BB-*test_scope.txt.2"):
                    scopefileList.append(currentDir + "/" + bbFile)            
        return scopefileList

    
    def _getInterfaceContentsFromClearcase(self, allScopefiles):
        interfaceContentsClearcase = {}
        print "\n=== Parsing scopefiles ==="
        for scopefile in allScopefiles:
            print "  --> " + scopefile.split('/')[-1]
            with open(scopefile, "r") as f:
                lines = f.readlines()
                insideInterfaceOrComponent = False
                for line in lines:
                    if "interface " in line or "component " in line:
                           insideInterfaceOrComponent = True
                           interfaceOrComponentName = line.strip().split()[1]
                    if insideInterfaceOrComponent:
                        if '}' in line:
                            insideInterfaceOrComponent = False
                        elif ("contains" in line or 
                              "source" in line or 
                              "requires" in line):
                            containsSourceRequires = line.strip().split()[0].replace("source", "contains")
                            target = line.strip().split("/")[-1].split()[-1]
#                            if "bld_x86lnx" in line:
#                                target = target.replace(".so", ".x86lnx.so")
                            if self._targetCheckOK(target):
                                addItemToDictionary(interfaceContentsClearcase, interfaceOrComponentName, (containsSourceRequires, target))
        return interfaceContentsClearcase


    def _getInterfaceContentsFromBoa(self):
        interfaceContentsBoa = {}
        print "\n=== Parsing buildDependency files ==="
        for buildDepFile in getBuildDependencyFiles(self.boaPath):
            print "  --> " + "/".join(buildDepFile.split('/')[-2:])
            componentName = buildDepFile.split('/')[-2]
            with open (buildDepFile, "r") as f:
                lines = f.readlines()
                inProvidedInterfaces = False
                inRequiredInterfaces = False
                inRequiredTestInterfaces = False
                depth = 0
                for line in lines:
                    if inProvidedInterfaces:
                        if depth >= 1: ## inside interfaces block
                            if ("versionedFiles" in line or
                                "buildFiles" in line or
                                "compile" in line):
                                target = line.split('\'')[1].split('/')[-1]
                                if "compile" in line:
                                    containsSourceRequires = "requires"
                                elif ("versionedFiles" in line or "buildFiles" in line):
                                    containsSourceRequires = "contains"
                                if self._targetCheckOK(target):
                                    if "x86lnx" in line:
                                        target = target.replace(".x86lnx.so", ".so")
                                    addItemToDictionary(interfaceContentsBoa, interfaceName, (containsSourceRequires, target))
                        if "{" in line:
                            if depth == 0:
                                interfaceName = ''.join(x for x in line if (x.isalpha() or x.isdigit() or x == "_"))
                            depth += 1
                        if "}" in line:
                            if depth == 0:
                                inProvidedInterfaces = False
                            depth -= 1
                    elif inRequiredInterfaces or inRequiredTestInterfaces:
                        if ("compile" in line):
                            target = line.split('\'')[1].split('/')[-1]
                            if self._targetCheckOK(target):
                                if inRequiredInterfaces:
                                    addItemToDictionary(interfaceContentsBoa, componentName, ("requires", target))
                                elif inRequiredTestInterfaces:
                                    addItemToDictionary(interfaceContentsBoa, componentName, ("requires_tst", target))
                        if "}" in line:
                            inRequiredInterfaces = False
                            inRequiredTestInterfaces = False
                    elif "providedInterfaces {" in line:
                        inProvidedInterfaces = True
                    elif "requiredInterfaces {" in line:
                        inRequiredInterfaces = True
                    elif "requiredTestInterfaces" in line:
                        inRequiredTestInterfaces = True
        return interfaceContentsBoa


    def _compareInterfaceContents(self, interfaceContentsClearcase, interfaceContentsBoa):
        interfacesNotPresentInBoa = []
        interfacesNotPresentInClearcase = []
        interfaceContentsBoaOrdered = collections.OrderedDict(sorted(interfaceContentsBoa.items()))
        
        for interface in interfaceContentsBoaOrdered:
            if not interface in interfaceContentsClearcase:
                interfacesNotPresentInClearcase.append(interface)
            else:
                if not (sorted(interfaceContentsBoa[interface]) == sorted(interfaceContentsClearcase[interface])):
                    print "\n\n" + colors.BOLD + interface + colors.NEUTRAL + " IS NOT EQUAL!"
#                    if interface == "KMLIWA":
#                        print "Clearcase"
#                        for x1 in interfaceContentsClearcase[interface]:
#                            print x1
#                        print "BOA"
#                        for x2 in interfaceContentsBoa[interface]:
#                            print x2
  
                    missingInBoa = [x for x in interfaceContentsClearcase[interface] if (x not in interfaceContentsBoa[interface])]
                    missingInClearcase = [x for x in interfaceContentsBoa[interface] if (x not in interfaceContentsClearcase[interface])]

                    if missingInBoa:
                        print "Not in BOA:"
                        for item in missingInBoa:
                            print item[0], item[1]
                    if missingInClearcase:
                        print "Not in Clearcase:"
                        for item in missingInClearcase:
                            print item[0], item[1]

        for interface in interfaceContentsClearcase:
            if not interface in interfaceContentsBoa:
                interfacesNotPresentInBoa.append(interface)
        
#        print "\n=== INTERFACES NOT PRESENT IN BOA ==="
#        print "\n".join(interfacesNotPresentInBoa)
        if interfacesNotPresentInClearcase:
            print "\n=== INTERFACES NOT PRESENT IN CLEARCASE ==="
            print "\n".join(interfacesNotPresentInClearcase)



    def compare(self):
        allScopefiles = self._getAllScopefiles()
        interfaceContentsClearcase = self._getInterfaceContentsFromClearcase(allScopefiles)
        interfaceContentsBoa = self._getInterfaceContentsFromBoa()
        self._compareInterfaceContents(interfaceContentsClearcase, interfaceContentsBoa)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-v", "--view",
                        help="Specify a Clearcase view",
                        required=True)
    parser.add_argument("-b", "--boapath",
                        help="Specify a path to a BOA repo",
                        required=True)                    
    args = parser.parse_args()

    if args.view:
        viewName = args.view
    else:
        cmd = "cleartool pwv -short"
        viewName = subprocess.check_output([cmd], shell=True).strip()    
        if viewName == "** NONE **":
            print "You need to be in a clearcase view or provide a view name using -v"        
            exit(1)
    
    compareScopeClearcaseBoa(viewName, args.boapath).compare()
