#!/usr/bin/env python

from clearcase import get_ccget_config_stack

def printConfigStack():
#    viewName = "ptacken_at_qbl_lvl_NPI_fixes_LIL12_int"
    viewName = "ptacken_at_qbl_FC062_lvl_NXT1470_int"
    configStack = get_ccget_config_stack(viewName)
    
   # configStack = {'parent project': u'lvl_at_qbl', 'parent baseline': u'lvl_at_qbl_integration_191220_141751', 'baselines': [u'lvl_at_qbl_NPI_20_integration_200115_064426', u'lvl_at_qbl_integration_191220_141751', u'at_qblr007_integration_191216_164816'], 'projects': [u'lvl_at_qbl_NPI_20', u'lvl_at_qbl', u'at_qblr007']}
    
#    print [x for x in configStack['baselines'] if x.startswith('at_qblr007')][0]
    print configStack

printConfigStack()
