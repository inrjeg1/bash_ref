# Assembly check

Check an assembly project baseline in releases (run this from your view).

If you're developping on an assembly, you can use this tool to check your developments in recommended releases (e.g. at6.2, at7.3).

Currently, this tool is geared towards the FC-062 assembly. Feel free to modify it to be used in other assemblies too (the main modification needed is to determine which recommended release baseline to use).

