import os
import glob
import re
import time
import logging
import subprocess

# TODO: share this and other general utility functions
def test_marker(view):
   s = view.split("_")

   if s[3] != "dumbo":
     raise SystemError("View name should contain the string \"dumbo\".")

   assembly = s[1]
   sib = s[2]
   return "{} on {} ".format(assembly.upper(), sib.upper())


def get_latest_log_file(view):
   logfiles = glob.glob("/sdev_shared/dpdata/datplus/{}/ccrun_datplus.log.*".format(view))
   if logfiles:
      return max(logfiles, key=os.path.getctime)
   return ""


def get_latest_result(view):
   latest_log_file = get_latest_log_file(view)
   if latest_log_file:
      with open(latest_log_file, 'r') as f:
         for line in f:
            if "setting overall result to: " in line:
               return line.rsplit(":", 1)[1].strip()
   return "Unknown"


def run(view):
   logging.getLogger(__file__).info("Running datplus on {}".format(view))

   prev_time = time.time() # as floating point processor time in seconds
   ansi_escape_re = re.compile(r'\x1B\[[0-?]*[ -/]*[@-~]')
   output = []

   description = test_marker(view) + "DAT+"
   cmd = 'echo ccrun_datplus -d \\\"{}\\\" | ccset_view {}'.format(description, view)
   logging.getLogger(__file__).debug("Exec: "+cmd)
   process = subprocess.Popen(cmd,
                           shell=True,
                           stdout=subprocess.PIPE,
                           stderr=subprocess.STDOUT
                           )
   for line in iter(process.stdout.readline,''):
      line = line.strip()
      line = ansi_escape_re.sub('', line)
      logging.getLogger(__file__).debug(line)
      output.append(line)
      if (time.time() - prev_time) > 180:
         prev_time = time.time()
         logging.getLogger(__file__).info("still running datplus on {}...".format(view))
      time.sleep(0) # yield to other thread

   returncode = process.wait()
   
   for line in output:
      if "setting overall result to: PASS" in line:
         logging.getLogger(__file__).info("Overall datplus results have passed for {}".format(view))
         return "Pass"
   
   if returncode != 0:
      SystemError("Error executing: "+cmd)
   # else: assume that a 0 exit code means OK
   return "Fail"


