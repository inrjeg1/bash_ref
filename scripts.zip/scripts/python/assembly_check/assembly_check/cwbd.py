import logging

import assembly_check.clearcase


def get_check_libref_error_log_path(view=None):
   return "/tmp/check_libref_errors_{}.txt".format(view)


def check_libref(view=None):
   logging.getLogger(__file__).info("CWBD check libref {}".format(view))
   cmd = "cwbd -X -c check_libref"
   try:
      output = assembly_check.clearcase.exec_shell_command(cmd, view)
      return "Passed"
   except:
      with open(get_check_libref_error_log_path(view), 'w') as f:
         errors = assembly_check.clearcase.get_build_errors(view)
         for errline in errors:
            f.write(errline)
      
   return "Failed"




def scope_control(view=None):
   logging.getLogger(__file__).info("CWBD scope control {}".format(view))
   cmd = "cwbd -X -c scope_control"
   try:
      output = assembly_check.clearcase.exec_shell_command(cmd, view)
      return "Passed"
   except:
      pass
   return "Failed"

