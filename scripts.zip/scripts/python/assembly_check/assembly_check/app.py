#!/usr/bin/env python

import os.path
import argparse
import logging
import datetime

# own package include
import assembly_check.clearcase
import assembly_check.check_baseline

def handle_commandline_args():
   parser = argparse.ArgumentParser(description="Check whether the contents of this assembly stream work in all sharing releases.")

   #parser.add_argument('keyword', type=str, nargs='+', help='a number of keywords to search for')
   parser.add_argument("-a", "--assembly", metavar="AS", type=str, help="only test for given assembly, e.g. 'as_lvl'", default="")
   parser.add_argument("-b", "--baseline", help="Add baseline to the list of AIB baselines to check", action="append", metavar="BL")
   parser.add_argument("-c", "--cleanup", help="Clean up after run (remove dumbo's etc)", action="store_true")
   parser.add_argument("-l", "--log", dest='loglevel', metavar="LVL", type=str, help='The logging level {DEBUG,INFO,WARNING,ERROR}', default="INFO")
   parser.add_argument("-n", "--dumbo-name", type=str, metavar="STR", help='Add STR to dumbo name', default="")
   parser.add_argument("-q", "--include-qbl", help="Include QBL in tests", action="store_true")
   parser.add_argument("-s", "--add-scope", help="Add component CC to buildscope [default: buildscope of assembly stream]", action="append", metavar="CC")
   # TODO: Better mechanism to specify user-defined qualification sets - now the argument requires a full path
   parser.add_argument("--add-qsets", help="Additional TestArena qualification sets to run (set names must contain release name)", type=str, nargs='+', metavar="/home/bla/at6.2_qset.xml")
   parser.add_argument("--full-fc", help="Trigger all FC tests", action="store_true")
   parser.add_argument("--fc", help="FC for all FC tests, example FC-061 [default = FC-062]", type=str, default="FC-062")


   parser.add_argument("--skip-tests", help="Skip tests like metro test or datplus", action="store_true")
   parser.add_argument("--skip-full-build", help="Don't execute a full build", action="store_true")
   
   parser.add_argument("--ignore-baseline", help="Ignore that the view is not on the latest baseline", action="store_true")
   
   args = parser.parse_args()
   return args


def get_logger(loglevel):
   #logfmt_long = "%(asctime)s Pr%(process)d,Th%(thread)d: %(pathname)s:%(funcName)s(): %(levelname)s: %(message)s"
   logfmt_long = "%(asctime)s Pr%(process)d,Th%(thread)d: %(module)s:%(funcName)s(): %(levelname)s: %(message)s"
   logfmt_short = "%(asctime)s: %(module)s:%(funcName)s(): %(levelname)s: %(message)s"
   #logfmt_console = "%(module)s:%(funcName)s(): %(levelname)s: %(message)s"
   logfmt_console = "%(levelname)s: %(message)s"
   
   numeric_level = getattr(logging, loglevel.upper(), None)
   if not isinstance(numeric_level, int):
      raise ValueError('Invalid log level: %s' % loglevel)

   # log to file:
   curtime = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
   logfile = os.path.join(os.path.expanduser("~"), "assembly_check_{}".format(curtime))
   logging.basicConfig(filename=logfile, filemode='w', level=numeric_level, format=logfmt_long)

   # log to console:
   formatter = logging.Formatter(logfmt_console)
   lsh = logging.StreamHandler()
   #lsh.setLevel(logging.WARNING) # log warnings/errors only to console
   lsh.setLevel(logging.INFO) # log info/warnings/errors only to console
   lsh.setFormatter(formatter)
   rootLogger = logging.getLogger()
   rootLogger.addHandler(lsh)

   logger = logging.getLogger(__file__)
   logger.info("Application started, logging to {}".format(logfile))

   return logger



def update_baseline_set_from_args(baselines, args):
   baselines = prune_baseline_set(baselines, args)
   baselines = extend_baseline_set(baselines, args)
   logging.getLogger(__file__).info("AIB baselines to check:\n\t{}".format("\n\t".join(baselines)))
   return baselines


def prune_baseline_set(baselines, args):
   if not args.include_qbl:
        baselines = [ b for b in baselines if not "_at_qbl_integration_" in b ]
   # TODO: Add a filter option (only test on a subset of release contexts)
   return baselines


def extend_baseline_set(baselines, args):
   if args.baseline:
      baselines = list(set(baselines) + set(args.baseline))
   baselines = sorted(baselines, reverse=True)
   return baselines


def start_running_checks(baselines, changed_assembly_baselines, buildscope, args):
   check_threads = []
   for baseline in baselines:
      t = assembly_check.check_baseline.run_checks(baseline, changed_assembly_baselines, buildscope, args)
      check_threads.append(t)
      t.start()
   return check_threads


def wait_for_threads(threadlist):
   for thrd in threadlist:
      thrd.join()


def extend_buildscope_with_cmdline_args(buildscope, args):
   if args.add_scope:
      for component in args.add_scope:
         logging.getLogger(__file__).debug("Adding {} to buildscope".format(component))
         buildscope.append(component)
   return buildscope


def get_thread_status(threadlist):
   for thrd in threadlist:
      thrd.get_status()

def main():
   args = handle_commandline_args()
   logger = get_logger(args.loglevel)
   
   assembly_check.clearcase.check_if_view_is_set()
   
   assemblies = [ "as_lvl_common", "as_lvl_ldl", "as_lvl_lil" ]

   aibs = [ "lvl_at_qbl", "lvl_at7.3", "lvl_at6.2" ]
   
   # get project info
   config_stack = assembly_check.clearcase.get_ccget_config_stack(None)
   project = config_stack['projects'][0]
   parent_baseline = config_stack["parent baseline"]
   logging.getLogger(__file__).debug("Parent baseline: %s" %(parent_baseline))
   buildscope = assembly_check.clearcase.get_buildscope() # a list
   buildscope = extend_buildscope_with_cmdline_args(buildscope, args)
   changed_assembly_baselines = assembly_check.clearcase.get_changed_assembly_baselines(args.assembly, project)

   # get target release BL info
   aib_baselines = assembly_check.clearcase.get_latest_system_baselines(aibs)

   logging.getLogger(__file__).info("Latest assembly integration branch baselines:\n\t{}".format("\n\t".join(aib_baselines)))

   # Verify that the view is on a recommended baseline, in order to get it release to the assembly.
   if ( not args.ignore_baseline ) and ( parent_baseline not in aib_baselines ):
       raise SystemError("Current view parent baseline (%s) is not in the latest AIB baselines (%s)" % (parent_baseline,", ".join(aib_baselines)))

   # Get matching Assembly baselines from the parent baseline...
   assembly_baselines = assembly_check.clearcase.get_assembly_baselines_for_aib_baseline(parent_baseline, assemblies)

   # Get backtrace baselines of all the assembly_baselines (per release)
#   release_baselines = assembly_check.clearcase.get_release_baselines_for_assembly_baselines(assembly_baselines, args.include_qbl, aibs)
#   logging.getLogger(__file__).info("Release baselines: %s" %(", ".join(release_baselines)))

   aib_baselines = update_baseline_set_from_args(aib_baselines, args)
   
   if aib_baselines:
      # perform the actual checks in seperate threads (parallel)
      checking_threads = start_running_checks(aib_baselines, changed_assembly_baselines, buildscope, args)
      wait_for_threads(checking_threads)
      get_thread_status(checking_threads)
   else:
      logging.getLogger(__file__).warning("No AIB baselines to check the assemby in")
   
#-----------------------------------------------------------------------------#
# MAIN
#-----------------------------------------------------------------------------#
if __name__ == "__main__":
   main()

