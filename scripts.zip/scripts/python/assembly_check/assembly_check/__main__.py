""" executed when directory is called as script """

from .app import main
main()

