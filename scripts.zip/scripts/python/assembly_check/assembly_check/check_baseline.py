import os
import re
import logging
import threading
from datetime import datetime

import assembly_check.clearcase
import assembly_check.cwbd
import assembly_check.datplus
import assembly_check.testarena


class run_checks(threading.Thread):
   def __init__(self, baseline, changed_assembly_baselines, buildscope, args):
      threading.Thread.__init__(self)
      self.logger = logging.getLogger(__file__)
      self.baseline = baseline
      self.changed_assembly_baselines = changed_assembly_baselines
      self.buildscope = buildscope

      # command line arguments:
      self.do_cleanup = args.cleanup
      self.dumbo_name = args.dumbo_name
      self.do_tests = not args.skip_tests
      self.do_full_build = not args.skip_full_build
      self.qsets = args.add_qsets
      self.do_full_tests = args.full_fc
      self.fc_for_full_tests = args.fc
      
      self.view = None
      self.rebase_in_progress = False
      self.cwbd_check_libref = "Unknown"
      self.full_build_start_time = None
      self.full_build_jobid = 0
      self.build_state = "Unknown"
      self.metro_test_request = 0
      self.metro_test_advice = "Unknown"
      self.qset_requests = [ ]


   def get_baseline_timestamp(self):
      matches = re.search("\d{6}_\d{6}", self.baseline)
      if matches:
         return matches.group(0)
      raise SystemError("Cannot establish the date/time of the baseline")
   
   
   def get_branch_of_baseline(self):
      return re.sub("_integration_\d{6}_\d{6}", "", self.baseline)


   def exec_shell_command(self, cmd):
      # we should replace these exec_shell_commands with some common utility function in a seperate module or so
      return assembly_check.clearcase.exec_shell_command(cmd)
      

   def create_dumbo(self):
      self.logger.info("Making dumbo...")
      cmd = "ccmk_dumbo -b {} {}{}".format(self.baseline, self.dumbo_name, self.get_baseline_timestamp())
      output = self.exec_shell_command(cmd)
      for line in output:
         if "The created VIEW is: " in line:
            self.view = line.replace("The created VIEW is: ", "")
            self.logger.info("Created dumbo view: "+self.view)


   def remove_dumbo(self):
      self.logger.info("Removing dumbo of {}...".format(self.view))
      cmd = "ccrm_dumbo -f {}".format(self.view)
      output = self.exec_shell_command(cmd)
      # TODO: if the ccrm_dumbo fails, get the project name from its output, and call ccrm_dumbo again with the project as argument (and echo "y" into it)
   
   
   def retrieve_dumbo_view(self):
      cmd = "ccset_view -P -l | grep \"{}\" | grep \"{}{}\" | head -n 1".format(self.get_branch_of_baseline(), self.dumbo_name, self.get_baseline_timestamp())
      output = "".join(self.exec_shell_command(cmd)).strip()
      
      if len(output) > 0 and "dumbo" in output:
         self.view = output
         self.logger.info("Using existing dumbo view: "+self.view)
         return True
      return False
   

   def rebase_assembly_baselines(self):
      self.logger.info("Rebasing "+self.view)

      for aa_baseline in self.changed_assembly_baselines:
         self.rebase_to_assembly_baseline(aa_baseline)


   def rebase_to_assembly_baseline(self, aa_baseline):
      self.logger.info("Rebasing to "+aa_baseline)
      cmd = "/sdev/simgt/sbin/ccrebase_assembly -q -b {}".format(aa_baseline)
      output = assembly_check.clearcase.exec_shell_command(cmd, self.view)

      self.rebase_in_progress = True
      for line in output:
         if "No rebase needed" in line:
            self.rebase_in_progress = False
            break

      if self.rebase_in_progress == True:
         self.logger.info("Closing rebase "+self.view)
         cmd = "/sdev/simgt/sbin/ccrebase_assembly -c"
         assembly_check.clearcase.exec_shell_command(cmd, self.view)
         self.rebase_in_progress = False
      else:
         self.logger.debug("Rebase to {} wasn't needed for {}".format(aa_baseline, self.view))


   def rebase_assembly_baseline_abort(self):
      self.logger.info("Aborting rebase "+self.view)
      cmd = "/sdev/simgt/sbin/ccrebase_assembly -q -a"
      assembly_check.clearcase.exec_shell_command(cmd, self.view)
      self.rebase_in_progress = False


   def get_status(self):
      state = "for VIEW: {}".format(self.view)
      if self.do_tests:
         metroRunURL = "Unknown"
         if self.metro_test_request != 0:
            metroRunURL = "http://testarena.asml.com:9180/TestArena/schedule/?id={}".format(self.metro_test_request)
         state += "\n      *** Metro test advice: {}".format(self.metro_test_advice)
         state += "\n      *** Metro test run:    {}".format(metroRunURL)
         state += "\n      *** DAT plus results:  {}".format(assembly_check.datplus.get_latest_result(self.view))
         state += "\n      *** DAT plus logs:     {}".format(assembly_check.datplus.get_latest_log_file(self.view))

         #TODO: Add results of any user-defined q-sets

      state += "\n      *** Build:             {}".format(self.build_state)
      
      state += "\n      *** CWBD check libref: {}".format(self.cwbd_check_libref)
      if "Failed" in self.cwbd_check_libref:
         state += "\n               check libref errors in: {}".format(assembly_check.cwbd.get_check_libref_error_log_path(self.view))
         
      state += "\n"
      self.logger.info(state)
      return state


   ###################################################################
   def run(self):
      """
      # create dumbo's on AIB baselines
      # set dumbo buildscope
      # rebase to the lvl baselines that are changed
      # build
      # metro_test_submit -s --> check advice
      # start any testarena qualification sets given by user input
      # ccrun_datplus
      # full build
      """
      self.logger.info("Running checks on {}".format(self.baseline))
      self.logger.info("For the following baselines:\n\t{}".format("\n\t".join(self.changed_assembly_baselines)))

      try:
         if not self.retrieve_dumbo_view():
            self.create_dumbo()
         
         self.buildscope = clearcase.filter_view_buildscope(self.view, self.buildscope)
         assembly_check.clearcase.set_view_buildscope(self.view, self.buildscope)

         self.rebase_assembly_baselines()

         # In order to have a correct build we might need to add all the CC of the assemby.
         # It happens that new components are added and these interfaces are not correctly built, 
         # if the new cc is not in the buildscope. (Or add the additional components)
         # assembly_check.clearcase.add_assembly_buildscope(self.view)
         assembly_check.clearcase.update_scope(self.view)

         assembly_check.clearcase.build_partially(self.view)
         self.build_state = "Partial OK" # Build partially would have raised an exception if it failed
         
         self.cwbd_check_libref = assembly_check.cwbd.check_libref(self.view)

         if self.do_tests:

            if self.do_full_tests:
                self.metro_test_request = assembly_check.testarena.metro_test_full_submit(self.view, self.fc_for_full_tests)
            else:
                self.metro_test_request = assembly_check.testarena.metro_test_submit(self.view)

            if self.qsets:
                # Filter on AIB name (reflecting sharing release name):
                branch = self.get_branch_of_baseline()
                qsets = [x for x in self.qsets if branch in x]
                if qsets:
                   self.qset_requests = assembly_check.testarena.queue_qsets(self.view, qsets)

            assembly_check.datplus.run(self.view)
            # TODO: -i in dumbo doesn't include known issues...
            self.metro_test_advice = assembly_check.testarena.metro_test_advice(self.view, self.metro_test_request)

         if self.do_full_build:
            self.full_build_start_time, self.full_build_jobid = assembly_check.clearcase.build_full(self.view)
            self.build_state = assembly_check.clearcase.check_full_build(self.full_build_start_time, self.full_build_jobid, self.view)

         self.logger.info("All checks are done for {}".format(self.view))
      except Exception as e:
         self.logger.exception("Failed to execute checks for "+str(self.view))
      finally:
         if not self.do_cleanup and self.rebase_in_progress:
            try:
               self.rebase_assembly_baseline_abort()
            except Exception as e:
               self.logger.exception("Ignoring exception after rebase aborting: "+str(e))
      
      # cleanup if required (cmdline arg)      
      if self.do_cleanup:
         try:
            self.remove_dumbo()
         except Exception as e:
            self.logger.exception("Ignoring exception during cleanup: "+str(e))


