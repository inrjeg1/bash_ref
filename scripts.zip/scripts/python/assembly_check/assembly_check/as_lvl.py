##
#-----------------------------------------------------------------------------#
#                                                                             #
#                            Python script                                    #
#                                                                             #
#-----------------------------------------------------------------------------#
#
# Ident        : as_lvl.py
'''
Assembly-specific definitions for LVL distributed assembly.
All other assembly tools must be devoid of specific assembly references and
use the definitions in an assembly-specific module like this instead.

Usage: import dynamically in Python script as follows:

    import importlib
    DAI = importlib.import_module( <as-dai> )

Where <as-dai> is a variable containing the short form of the assembly name
in small caps, with "as_" prefix. For instance: "as_lvl".
'''
__author__ = "Andrea Cilio (ACIL) [ASML]"
#
# History
# 2018-03-02   : _______ Creation.
#
#-----------------------------------------------------------------------------#
#                                                                             #
#                Copyright (c) 2018, ASML Netherlands B.V.                    # 
#                         All rights reserved                                 #
#                                                                             #
#-----------------------------------------------------------------------------#

AS = "lvl"

AIB_RELEASES = [ "at_qbl", "at6.2", "at7.3" ]
SHARING_RELEASES = AIB_RELEASES + [ "at6.3" ]

# WARNING: VOBs could change in the future
VOB_SDB = "@/vobs/litho_projects5"
VOB_AIB = "@/vobs/litho_projects3"

AIBS = [ AS+"_"+r  for r in AIB_RELEASES ]

