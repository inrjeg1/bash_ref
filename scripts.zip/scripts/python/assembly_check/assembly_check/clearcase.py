import glob
import re
import time
import os.path
import logging
import subprocess
import xml.dom.minidom
from datetime import datetime


def exec_shell_command(cmd, view=None, raise_error=True):
   """ Execute a command in shell environment and return its output as array of strings
   Raises an exception if the exit status != 0
   Logs the output.
   
   :param cmd   The command to execute. Should not contain double quotes...
   :param view  If a view is given, the command is echo'ed and piped to ccset_view, to be executed in view.
   """
   output = []

   if "\'" in cmd:
      raise SystemError("command should not contain single quotes. "+str(cmd))

   if view:
      cmd = "echo '{}' | ccset_view {}".format(cmd, view)
   logging.getLogger(__file__).debug("Exec: "+cmd)

   ansi_escape_re = re.compile(r'\x1B\[[0-?]*[ -/]*[@-~]')
   process = subprocess.Popen(cmd,
                           shell=True,
                           stdout=subprocess.PIPE,
                           stderr=subprocess.STDOUT
                           )
   for line in iter(process.stdout.readline,''):
      line = line.strip()
      line = ansi_escape_re.sub('', line)
      # problematic log statement: it can generate ~1GB of data
#      logging.getLogger(__file__).debug(line)
      output.append(line)
      time.sleep(0) # yield to other thread

   returncode = process.wait()
   if raise_error and returncode != 0:
      raise SystemError("Error executing: " +cmd + " Output: " + str(output))
   return output


def get_ccget_config_stack(view_name=None):
    """ Returns the ClearCase configuration stack of the given view name.
    ### from /sdev_shared/sics/DT/lib/asml/clearcase/clearcase.py
    :param view_name: (Optional) The name of the view to get the ClearCase
                      configuration stack
    :type view_name:  str

    :return:          conf_stack
    :rtype:           A dictionary holding:

                        - "parent baseline"
                        - A list of "baselines"
                        - A list of "projects"
                        - "parent project"
    """

    conf_stack = {}
    conf_stack["parent baseline"] = "No parent baseline found!"
    conf_stack["baselines"] = []
    conf_stack["projects"] = []
    conf_stack["parent project"] = 'Parent project is not set!'

    output = exec_shell_command('ccget_config', view_name)

    doc = xml.dom.minidom.parseString("".join(output))

    xml_baselines = doc.getElementsByTagName("baseline")
    for xml_baseline in xml_baselines:
        conf_stack["parent baseline"] = xml_baseline.firstChild.nodeValue
        break

    xml_baselines = doc.getElementsByTagName("bl")
    for xml_baseline in xml_baselines:
        conf_stack["baselines"].append(xml_baseline.firstChild.nodeValue)

    xml_projects = doc.getElementsByTagName("proj")
    for xml_project in xml_projects:
        conf_stack["projects"].append(xml_project.firstChild.nodeValue)

    xml_parent_projects = doc.getElementsByTagName("project")
    for xml_parent_project in xml_parent_projects:
        conf_stack["parent project"] = xml_parent_project.firstChild.nodeValue
        break

    return conf_stack


def get_buildscope(view_name=None, raw_format=False):
    """ Returns the buildscope of the given view.
        ### from /sdev_shared/sics/DT/lib/asml/clearcase/clearcase.py

        :param view_name:        (Optional) The name of the view to get the
                                 buildscope from. If none given it expects that
                                 it is in a view_name.
        :type view_name:         str
        :param raw_format:       Raw output of ccget_buildscope is requested
        :type raw_format:        bool
        :return: buildscope:     The buildscope of the given view
        :rtype:                  str
    """

    if raw_format:
        cmd = 'ccget_buildscope -r'
    else:
        cmd = 'ccget_buildscope'

    output = exec_shell_command(cmd, view_name)

    if raw_format:
        buildscope = "".join(output)
    else:
        buildscope = [x.split('/')[-1] for x in output]

    return buildscope


def check_if_view_is_set():
   if not os.path.exists("/vobs/litho/xscm"):
      logging.getLogger(__file__).error("check if clearcase view is set")
      raise SystemError("Not in a ClearCase view")
   logging.getLogger(__file__).debug("clearcase view is set")


def get_istream_of_project(project):
   cmd = 'cleartool lsproj -fmt "%[istream]Xp" {}'.format(project)
   output = exec_shell_command(cmd)

   return "".join(output)


def get_target_assembly_of_project(project):

   istream = get_istream_of_project(project)

   cmd = 'cleartool describe -fmt "%[def_deliver_tgt]p" {}'.format(istream)
   output = exec_shell_command(cmd)

   target_istream = "".join(output).strip()
   assembly = target_istream.split("_at_qbl_integration")

   if assembly[1] != "":
      raise SystemError("The target of project {} is not a valid QBL-based integration stream: {}.".format(project, target_istream))

   return "as_"+assembly[0]


def get_changed_assembly_baselines(assembly_filter, project):
   assembly_filter = get_target_assembly_of_project(project)
   process = subprocess.Popen("cclst_baselines | grep \"{}\" | grep \"{}\" | sed \"s/baseline://\"".format(assembly_filter, project),
                                    shell=True,
                                    stdout=subprocess.PIPE,
                                    )
   output = process.communicate()[0].strip().split('\n') #process.stdout.readlines()
   process.wait()

   logging.getLogger(__file__).info("Changed assembly baselines:\n\t{}".format("\n\t".join(output)))
   return output


def get_last_build_info_from_array(last_system_build_content):
   info = {}
   info['type'] = last_system_build_content[0].strip().lower()
   date_time_str = last_system_build_content[1].strip()
   ### can have different formats...
      # Thursday, December 21, 2017 10:31:40 AM MET
      # Fri Dec 22 11:08:58 CET 2017
   for fmt in ("%A, %B %d, %Y %I:%M:%S %p %Z", "%a %b %d %H:%M:%S %Z %Y"):
      try:
         info['datetime'] = datetime.strptime(date_time_str, fmt)
         break
      except ValueError:
         logging.getLogger(__file__).debug("Date/time string \"{}\" doesn't conform to \"{}\"".format(date_time_str, fmt))
         info['datetime'] = None

   if not info['datetime']:
      logging.getLogger(__file__).error("Cannot parse date/time string from last system build: \"{}\"".format(date_time_str))

   return info


def get_last_build_info_from_view(view=None):
   info = None
   if view:
      try:
         FNULL = open(os.devnull, 'w')
         content = subprocess.check_output("echo \"cat /vobs/litho/logging/flags/last_system_build.txt\" | ccset_view {}".format(view), shell=True, stderr=FNULL).strip().split('\n')
         info = get_last_build_info_from_array( content[-2:] )
      except:
         logging.getLogger(__file__).debug("No such file 'last_system_build.txt'. Assuming no build has taken place yet")
         info = { 'type': "", 'datetime': None }
   else:
      with open("/vobs/litho/logging/flags/last_system_build.txt", 'r') as f:
         info = get_last_build_info_from_array( f.readlines() )
   logging.getLogger(__file__).debug("{}".format(info))
   return info


def go_to_component(view, component):
    cmd = "cd `xcd " + component +"`"
    cmd = "echo '{}' | ccset_view {}".format(cmd, view)
    return subprocess.call(cmd, 
                           shell=True,  
                           stdout=subprocess.PIPE,
                           stderr=subprocess.STDOUT)


def filter_view_buildscope(view, buildscope):
    logging.getLogger(__file__).info("Filtering buildscope for {}".format(view))
    newBuildscope = []
    for component in buildscope:
        if go_to_component(view, component) == 0:
            newBuildscope.append(component) 
    return newBuildscope


def set_view_buildscope(view, buildscope):
   logging.getLogger(__file__).info("Setting buildscope for {}".format(view))
   cmd = "echo \"exit\" | ccset_view {} {}".format(view, " ".join(buildscope))
   exec_shell_command(cmd)


def add_to_buildscope(view, buildscope):
   logging.getLogger(__file__).info("Adding {} to buildscope of {}".format(" ".join(buildscope), view))
   cmd = "ccset_buildscope -a {}".format( " ".join(buildscope))
   cmd = "echo \"{}\" | ccset_view {}".format( cmd, view)
   exec_shell_command(cmd)


def add_assembly_buildscope(view):
   logging.getLogger(__file__).info("Adding assembly to buildscope of {}".format(view))
   cmd = "ccset_buildscope -c"
   cmd = "echo \"{}\" | ccset_view {}".format( cmd, view)
   exec_shell_command(cmd)


def update_build_environment(view=None):
   logging.getLogger(__file__).info("Running ccupd_bldenv on {}".format(view))
   cmd = "ccupd_bldenv -y -r -f"
   output = exec_shell_command(cmd, view)


def update_scope(view=None):
   logging.getLogger(__file__).info("Running ccupdate_scope on {}".format(view))

   cmd = "ccupdate_scope -a"
# TODO: Check with SIMGT why we need the prompt confirmation
   if "at6.2" in view:
      cmd = "echo \"y\" | ccupdate_scope -a"
   output = exec_shell_command(cmd, view)


def build_partially(view=None):
   logging.getLogger(__file__).info("Running partial build on {}".format(view))
   
   cmd = "ccmake -s"
   exec_shell_command(cmd, view)


def is_build_in_progress(view=None):
   try:
      FNULL = open(os.devnull, 'w')
      cmd = "ls /vobs/litho/logging/flags/build.flag"
      if view:
         cmd = "echo '{}' | ccset_view {}".format(cmd, view)
      subprocess.check_call(cmd, shell=True, stdout=FNULL, stderr=subprocess.STDOUT)
      logging.getLogger(__file__).debug("Build in progress on {}".format(view))
      return True
   except:
      logging.getLogger(__file__).debug("No build in progress on {}".format(view))
      return False
   

def is_build_ok(view=None):
   # if there are no errors, there shouldn't be a /vobs/litho/logging/errlog/local.err
   try:
      FNULL = open(os.devnull, 'w')
      cmd = "ls /vobs/litho/logging/errlog/local.err"
      if view:
         cmd = "echo '{}' | ccset_view {}".format(cmd, view)
      subprocess.check_call(cmd, shell=True, stdout=FNULL, stderr=subprocess.STDOUT)
      logging.getLogger(__file__).debug("Build failed, {}/logging/errlog/local.err is present".format(view))
      return False
   except:
      logging.getLogger(__file__).debug("Build seems ok, {}/logging/errlog/local.err is not present".format(view))
      return True


def is_unnecessary_logging_information(line):
   return "Rebuild" in line or "gcc -" in line or "ccppc " in line or "Wink" in line or "acceptable" in line


def get_error_file_content(filename):
   content = []
   try:
      with open(filename, 'r') as f:
         for line in f:
            if not is_unnecessary_logging_information(line):
               content.append(line)
   except:
      logging.getLogger(__file__).exception("Couldn't read file {}".format(filename))
   return content


def get_build_errors(view=None):
   output = []
   if view:
      errfiles = glob.glob("/view/{}/vobs/litho/logging/errlog/*.err".format(view))
   else:
      errfiles = glob.glob("/vobs/litho/logging/errlog/*.err".format(view))

   if errfiles:
      for ef in errfiles:
         # TODO: check if date of file >= given date
         scm_errfile = os.path.splitext(ef)[0]
         
         output.append("*************************************\n")
         output.append("*************************************\n")
         output.append("***  File: {}.out\n".format(scm_errfile))
         output.append("*************************************\n")
         output.append("*************************************\n")
         output += get_error_file_content(scm_errfile+".out")
   return output


def wait_for_full_build(full_build_start_time, full_build_jobid, view=None):
   build_info = get_last_build_info_from_view(view)
   
   if full_build_start_time:
      wait_time = 180
      logging.getLogger(__file__).info("Waiting for full build (job {}) to finish on {}".format(full_build_jobid, view))
      while is_build_in_progress(view) or build_info['type'] == "partial build" or build_info['datetime'] < full_build_start_time:
         logging.getLogger(__file__).info("waiting {} more seconds for buid (job {}) ...".format(wait_time, full_build_jobid))
         time.sleep(wait_time)
         build_info = get_last_build_info_from_view(view)

   else:
      logging.getLogger(__file__).warning("No full build started, so no need to wait at {}".format(view))



def check_full_build(full_build_start_time, full_build_jobid,view=None):
   wait_for_full_build(full_build_start_time, full_build_jobid, view)
   if not is_build_ok():
      logging.getLogger(__file__).debug("full build failed on {}".format(view))
      return "Failed"

   logging.getLogger(__file__).debug("full build passed on {}".format(view))
   return "OK"


def build_full(view=None):
   logging.getLogger(__file__).info("Running full build on "+view)
   full_build_jobid = 0
   output = exec_shell_command("ccmake full", view)

   for line in output:
      matches = re.search("Job <(\d+)> is submitted to queue", line)
      if matches:
         full_build_jobid = matches.group(1)
   full_build_start_time = datetime.now()
   logging.getLogger(__file__).debug("Full build (job {}) started at {}".format(full_build_jobid, full_build_start_time))
   
   return (full_build_start_time, full_build_jobid)


def get_latest_system_baselines(branches):
   baselines = []

   for branch in branches:
      logging.getLogger(__file__).debug("Running cclst_sysbls for {}".format(branch))
      cmd = "/home/simgt/bin/cclst_sysbls {}_integration | tail -1".format(branch)
      output = exec_shell_command(cmd)
      if len(output) == 1:
         logging.getLogger(__file__).info("Baseline found: {}".format(output[0]))
         baselines.append(output[0])
   
   logging.getLogger(__file__).debug("Latest system baselines: {}".format(str(baselines)))
   return baselines

def get_assembly_baselines_for_aib_baseline(baseline, assemblies):
    assembly_baselines = []
    assembly_string = ",".join(assemblies)
    cmd = "cclst_baselines -a {} -b {}".format(assembly_string, baseline)
    output = exec_shell_command(cmd)
    logging.getLogger(__file__).debug("Assembly baselines: %s" %(",".join(output)))
    return output

def get_release_baselines_for_assembly_baselines(baselines, include_qbl, aibs):
    release_baselines = []
    matching_baseline_dict = {}
    for baseline in baselines:
        cmd = "cclst_baselines -B {}".format(baseline)
        output = exec_shell_command(cmd)
        # removed due to excessive logging
#        logging.getLogger(__file__).debug("Backtraced baselines of %s: %s" % (baseline, ", ".join(output)))
        for aib in aibs:
           aib_backtraced_baselines = [x for x in output if "%s_integration" % (aib) in x]
           logging.getLogger(__file__).debug("Backtraced baselines for AIB %s: %s" % (aib, ", ".join(aib_backtraced_baselines)))
           aib_backtraced_baselines.sort(reverse=True)
#           logging.getLogger(__file__).debug("Sorted backtraced baselines: %s" % (", ".join(aib_backtraced_baselines)))
           latest_backtraced_baseline = aib_backtraced_baselines[0]
           logging.getLogger(__file__).debug("Latest backtraced baseline of %s: %s" % (baseline, latest_backtraced_baseline))
           if latest_backtraced_baseline in matching_baseline_dict:
              matching_baseline_dict[latest_backtraced_baseline].append(baseline)
           else:
              matching_baseline_dict[latest_backtraced_baseline] = [baseline]
    
    logging.getLogger(__file__).debug("matching_baseline_dict: %s" % (str(matching_baseline_dict)))

    # Get parent baselines...
    for k in matching_baseline_dict.keys():
        cmd = "cleartool describe -fmt \"%[SFN_config]SNa\" {} 2> /dev/null".format(k)
        output = exec_shell_command(cmd)
        logging.getLogger(__file__).debug("Parent baselines of %s: %s" % (k, ", ".join(output)))
        if len(output) == 1:
            b = output[0].replace('"','')
            if '/' in b:
                b = b.split('/')[0]
            b = b.replace('lbpb_','')
            if (include_qbl or not ("at_qbl" in b)):
                release_baselines.append(b)
    
    # sort and remove double entries
    release_baselines = sorted(list(set(release_baselines)))

    return release_baselines


def build_interfaces(view=None):
   logging.getLogger(__file__).info("Running interfaces build on {}".format(view))
   
   build_info = get_last_build_info_from_view(view)

   cmd = "ccmake interfaces"
   if build_info['type'] == "full build":
      # switch from full build needs confirmation
      cmd = "echo \"y\" | ccmake interfaces"
   exec_shell_command(cmd, view)
