##
#-----------------------------------------------------------------------------#
#                                                                             #
#                            Python script                                    #
#                                                                             #
#-----------------------------------------------------------------------------#
#
# Ident        : dai.py
'''
Assembly-specific definitions for distributed assemblies.
All other assembly tools must be devoid of specific assembly references and
use the definitions in this module instead.

Where <your-dai> is a variable containing the short form of the assembly
name, in small caps, without "as_" prefix. For instance: "lvl".

Usage: import dynamically in Python script as follows:

    import importlib
    importlib.import_module( <your-dai> )

'''
__author__ = "Andrea Cilio (ACIL) [ASML]"
#
# History
# 2018--03-02   : _______ ACIL initial empty version
#
#-----------------------------------------------------------------------------#
#                                                                             #
#                Copyright (c) 2018, ASML Netherlands B.V.                    # 
#                         All rights reserved                                 #
#                                                                             #
#-----------------------------------------------------------------------------#

AS = "lvl"

AIB_RELEASES = [ "at_qbl", "at6.2", "at7.3" ]
SHARING_RELEASES = AIB_RELEASES + [ "at6.3" ]

