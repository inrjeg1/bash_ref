import os
import re
import time
import logging
import subprocess
import xml.dom.minidom

import assembly_check.clearcase


def test_marker(view):
   s = view.split("_")


## FIX!!! USE MORE ROBUST SPLIT PATTERN
   assembly = s[1]
   sib = s[2]
   return "{} on {} ".format(assembly.upper(), sib.upper())


def get_results(request_id):
   ta_data = subprocess.check_output('testarena getresult %s' %(request_id), shell=True, stderr=None)
   xml_data = xml.dom.minidom.parseString(ta_data)
   return xml_data


def request_is_done(results_xml):
   e1 = results_xml.getElementsByTagName("testrequests")[0]
   e2 = e1.getElementsByTagName("testrequest")[0]
   e3 = e2.getElementsByTagName("tr_status")[0]

   status = e3.firstChild.nodeValue

   return (status == "DONE" or status == "ABORT")


def wait_for_results(request_id):
   results_xml = get_results(request_id)
   prev_time = time.time() # as floating point processor time in seconds
   while not request_is_done(results_xml):
      time.sleep(30)
      results_xml = get_results(request_id)

      if time.time() - prev_time > 180:
         prev_time = time.time()
         logging.getLogger(__file__).info("still waiting for testarena results of {}...".format(request_id))


def metro_test_submit(view):
   logging.getLogger(__file__).info("metro_test_submit on {}".format(view))
   description = test_marker(view) + "metro test"
   cmd = "metro_test_submit -s -d \"{}\"".format(description)
   output = assembly_check.clearcase.exec_shell_command(cmd, view)
   
   request_id = None
   re_runid = re.compile("dynamic qset submit to Testarena succeeded with runid: (\d+)")
   for line in output:
      mo = re_runid.search(line)
      if mo:
         request_id = mo.group(1)

   logging.getLogger(__file__).info("metro_test_submit returned runid: {}".format(request_id))
   return request_id


def metro_test_advice(view, request_id):
   wait_for_results(request_id)

   cmd = "metro_test_advice -i {}".format(request_id)
   output = assembly_check.clearcase.exec_shell_command(cmd, view)
   
   # TODO: Advice for dumbo doesn't take into account known issues on release baseline..."
   for line in output:
      if "negative" in line.lower():
         logging.getLogger(__file__).info("metro_test_advice negative on {}".format(view))
         return "Negative (known issues not accounted for)"
      elif "degradation" in line.lower():
         logging.getLogger(__file__).info("metro_test_advice degradation on {}".format(view))
         return "Degradation (known issues not accounted for)"

   logging.getLogger(__file__).info("metro_test_advice assumed positive on {}".format(view))
   return "Positive"


def metro_test_full_submit(view, FC):
   logging.getLogger(__file__).info("Full metro_test_submit for {} on {}".format(FC,view))
   BB_filter = FC.replace("FC-", "BB-") + "-*"
   description = test_marker(view) + "full {} metro test".format(FC)
   cmd = "metro_test_submit -s --components_custom \"{}\" --scenarios_export -d \"{}\"".format(BB_filter, description)
   output = assembly_check.clearcase.exec_shell_command(cmd, view)

   request_id = None
   re_runid = re.compile("dynamic qset submit to Testarena succeeded with runid: (\d+)")
   for line in output:
      mo = re_runid.search(line)
      if mo:
         request_id = mo.group(1)

   logging.getLogger(__file__).info("metro_test_submit returned runid: {}".format(request_id))
   return request_id


def queue_qsets(view, qsets):
   logging.getLogger(__file__).info("user-defined qualification sets for {}:\n\t{}".format(view,
         "\n\t".join(qsets)))

   request_ids = [ ]
   for qset in qsets:
       qset_name = qset.split("/")[-1].replace(".xml","")
       cmd = "testarena queue -q {} -d \"{}\"".format(qset, qset_name)
       output = assembly_check.clearcase.exec_shell_command(cmd, view)

       doc = xml.dom.minidom.parseString("".join(output))

       xml_testid = doc.getElementsByTagName("id")[0]
       testid = int(xml_testid.firstChild.nodeValue)
       request_ids.append(testid)
       logging.getLogger(__file__).info("Test {} started. Job id {}.".format(qset_name, testid))

   return request_ids

