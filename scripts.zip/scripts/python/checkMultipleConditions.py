#!/usr/bin/env python

def checkMultipleConditions():
    a = 1
    b = 2
    c = 4
    d = True
    
    if (a == 1 and
        b == 2 and
        c == 4 and
        d):
       print "TRUE"
    


checkMultipleConditions()
