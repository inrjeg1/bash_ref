#!/usr/bin/env python

def replaceSpacesBySingleSpace():
    myString = "alpha   bravo charlie   delta"
    print ' '.join(myString.split())
    

replaceSpacesBySingleSpace()
