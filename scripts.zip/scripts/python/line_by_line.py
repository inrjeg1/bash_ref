#!usr/bin/env python

import os.path

def readLines():
    failed = 0
    with open("buildDependencies.gradle") as f:
        ccFound = False
        for line in f:
            if 'project' in line:
                CC = line.split("'")[1].replace(':','')
                ccFound = True
        
            elif 'versionedFiles' in line:
                fileName = CC + '/' + line.split("'")[1]
                if not os.path.isfile(fileName):
                    print "File " + fileName + " does not exist!"
                
            
            
def checkBuildDependenciesForNonExistingFiles():
 #   printPhase('CHECKING BUILD DEPENDENCIES FOR NON-EXISTING FILES')
    failedFiles = []
    CC = ''
    with open("buildDependencies.gradle") as f:
        for line in f:
            if 'project' in line:
                CC = line.split("'")[1].replace(':','')    
            elif 'versionedFiles' in line:
                if not CC:
                    raise RuntimeError('No CC defined')
                fileName = CC + '/' + line.split("'")[1]
                if not os.path.isfile(fileName):
                    
                    failedFiles.append(fileName)
    if failedFiles:
        print('FILES FOUND IN BUILDDEPENDENCIES.GRADLE THAT DO NOT EXIST:')
        printListOnMultipleLines(failedFiles)
        raise RuntimeError('Non-existing files found in buildDependencies.gradle')
    print('SUCCESS: buildDependencies.gradle does not contain any non-existing files')     
            



def checkEmptyList():
    failedFiles = []
    failedFiles.append("File1")
    failedFiles.append("File2")
    if failedFiles:
        print "Failed!"
        for f in failedFiles:
           print f
    

def goThroughTextTwice():
    with open("dummy.txt") as f:
        for line in f:
            if "mike" in line:
                print "MIKE:", line
                break
        for line in f:
            print "LINE: ", line
    
    
goThroughTextTwice()


#readLines()
#checkEmptyList()
#checkBuildDependenciesForNonExistingFiles()
