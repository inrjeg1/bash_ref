#!/usr/bin/env python

def tryCheckout():
    print "trying checkout"


tryCheckout()

