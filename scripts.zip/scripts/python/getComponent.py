#!/usr/bin/env python

import allComponents
import argparse
import clearcase
import getCurrentBoaRepo
import subprocess

def checkFileNameBoa(fileName, componentList):
    for component in componentList:
        if fileName == component:
            return component
    if (len(fileName) > 1):
        return checkFileNameBoa(fileName[:-1], componentList)


def checkFileNameClearcase(viewName, fileName):
    output = clearcase.go_to_component(viewName, fileName)
    if output == 0:
        return fileName
    elif (len(fileName) > 1):
        return checkFileNameClearcase(viewName, fileName[:-1])


def getComponent(fileName, buildscope=None):
    cmd = "cleartool pwv -short"
    viewName = subprocess.check_output([cmd], 
                                       shell=True).strip()
    boaRepo = getCurrentBoaRepo.getCurrentRepo()
    
    inClearcase = False
    componentList = []
    if not (viewName == "** NONE **"):
        inClearcase = True
    elif not (boaRepo == "None"):
        componentList = allComponents.getAllComponents()
    else:
        print "This script needs to be executed from a Clearcase or BOA environment"
        exit(1)

    if fileName.startswith("lib"):
        fileName = fileName[3:]
    component = fileName.split('.')[0].split('x')[0][:6].strip()

    if component.endswith("XA") or component.endswith("XT"):

        component = component[:-2]

    if not inClearcase:
        component = checkFileNameBoa(component, componentList)

    else:
        component = checkFileNameClearcase(viewName, component)
    
    if component:
        return component
    else:
        print "Component for file " + fileName + " not found!"


def getComponent2(fileName, buildscope=None):
    cmd = "cleartool pwv -short"
    viewName = subprocess.check_output([cmd], 
                                       shell=True).strip()
    boaRepo = getCurrentBoaRepo.getCurrentRepo()
    
    inClearcase = False
    componentList = []
    if not (viewName == "** NONE **"):
        inClearcase = True
        if not buildscope:
            componentList = clearcase.get_buildscope()
        else:
            componentList = buildscope
    elif not (boaRepo == "None"):
        componentList = allComponents.getAllComponents()
    else:
        print "This script needs to be executed from a Clearcase or BOA environment"
        exit(1)

    if fileName.startswith("lib"):
        fileName = fileName[3:]
    fileName = fileName.split('.')[0].split('x')[0][:6]

    component = checkFileNameBoa(fileName, componentList)
    if component:
        return component
    else:
        return checkFileNameClearcase(viewName, fileName)
    print "Component for file " + fileName + " not found!"


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('-f', '--file',
                        help="Filename for which component should be retrieved",
                        required = True)
    parser.add_argument('-b', '--buildscope',
                        help="A buildscope can be passed to scope the search area")
    args = parser.parse_args()
    print getComponent(args.file, args.buildscope)
