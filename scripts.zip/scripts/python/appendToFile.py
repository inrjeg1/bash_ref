#!/usr/bin/env python

def appendToFile():
    with open("dummy.txt", "a") as f:
        f.write("Additional contents\n")

def appendListContentsToFile(): 
    myList = ["ALPHA" , "BRAVO", "CHARLIE", "DELTA"]
    with open("dummy.txt", "a") as f:
        for item in myList:
            f.write(item+"\n")

def appendToNonExistingFile():
    fileName = "dummy_alphaBravo"
    with open(fileName, "a") as f:
        f.write("Some text")
    with open(fileName, "w+") as f:
        f.write("Some more text")


if __name__ == "__main__":
    #appendToFile()
#    appendListContentsToFile()
    appendToNonExistingFile()
