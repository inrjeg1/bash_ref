#!/usr/bin/env python

class classZulu():
    def zuluPrint(self):
        print "Inside class Zulu"
