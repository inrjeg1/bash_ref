#!/usr/bin/env python

import sh
from common import printOutput, printPhase, getCurrentUserName, gem

def syncToDevbench(devbench):
    dbCmd = sh.Command('devbench')
    showProgress = '-l'
    skipSymLinks = '-S'
    includeTests = '-t'
    systemScope = '-c s'.split()
    dbCmd('sync', showProgress, skipSymLinks, includeTests, systemScope,
          devbench, _out=printOutput, _err=printOutput)
    # Circumventing a BOA lnxsync bug
   # copyVpiFilesToDevbench(devbench)

syncToDevbench("blaa")
