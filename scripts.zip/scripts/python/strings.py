#!/usr/bin/env python

import subprocess

def printString(completeString):
    print (completeString)


def concatenateStrings():
    a = "ABC"
    b = "DEF"
    
    c = a + b
    print (c)
    
    c = "XXX"
    
    printString("UVW " + "'" + c + "'" + " XYZ")
    


def checkEmptyString():
    
    a = subprocess.Popen('ls | grep uNzip',
                            shell = True, 
                            stdout=subprocess.PIPE).stdout.read().strip()
    print a

    if not a:
        print "NO"
    else:
        print "YES"


def compareStrings():
    a = "bla"
    b = "bla"
    
    if a != b:
        print "NOT EQUAL"
    else:
        print "EQUAL", a, b


def stringWithArguments():
    a = 'alpha'
    b = 'bravo'
    c = 'charlie'
    
    myString = 'A string with %s, %s and %s' % (a, b, c) 
    
    print myString

def changeString():
    a = "alpha"
    a = a+" bravo"
    print a




def concatenateStringWithVar(variable):
    
    
    class structA:
        def __init__(self):
            self.alpha = 1
            self.bravo = 2
            self.charlie = 3
    
    a = structA()
    var = "bravo"
    
    print eval("a."+var)
    
    
def removeLastCharacterFromString():
    stringA = "abcdef"
    stringB = stringA[:-2]
    print stringA
    print stringB

def getLastItemOfString():
    stringA = "alpha bravo charlie delta"
    
    print stringA.split(' ')[-1]

def getLastTwoItemsOfString():
    stringA = "alpha bravo charlie delta"
    
    print stringA.split(' ')[-2:]


def splittingString():
    fileName = "KMXABRAVOxABCxDEF.cpp"
    fileName = fileName.split('.')[0].split('x')[0][:6]
    print fileName 


def compareStrings():
    a = "alpha"
    b = "alpha"
    c = "alpaha"
    d = "Alpha"
    
    if a == b:
        print "a is b"
    if a is c:
        print "a is c"
    if a is d:
        print "a is d"


def stringsWithRegularExpressions():
    import re
    fileName = "dummy.txt"
    with open(fileName) as f:
        #for line in f:
        #    if line.strip().endswith("dog"):
        #        print line.strip()

        if "alpha" in re.sub('\s+', ' ', open(fileName).read()).rstrip():
            print "MATCH"
        else:
            print "NO"
        
def getLastNElements():
    myString = "alpha/bravo/charlie/delta/echo/foxtrott/golf/hotel"
    last = myString.split("/")[-1]
    secondLast = "/" + "/".join(myString.split("/")[-2:])
    
    print last
    print secondLast
            

def stringWithNone(bravo = ""):  
    print "alpha", bravo, "charlie"
    
    
def checkIfStringContainsCharacters():
    myString = ""
    myString2 = "ALPHA/bravo/Charlie/"
    print any(x.isalpha for x in myString)
    print any(x.isalpha for x in myString2)
    

def checkEmptyString():
    myString = "vieName_int"
    if myString.endswith("_int"):
        print "ERROR 1"
    
    myString2 = None
    if myString2.endswith("_int") or not(myString2):
        print "ERROR 2"


def checkIfCharacterInLine():
    myString = "+"
    print dir(myString[0])
    checkOutput = any(x.isalpha for x in myString)
    print "output:" , checkOutput


def playingWithFields():
    myString = "alpha/bravo/charlie/delta/echo/foxtrott/golf"
    myString = myString.split("/")
    nr = 2
    print myString[nr]
    print ":"+str(nr), myString[:nr]
    print "::"+str(nr), myString[::nr]
    print str(nr)+":", myString[nr:]
    print str(nr)+"::", myString[nr::]
    print ""
    print myString[-nr]
    print ":"+str(-nr), myString[:-nr]
    print "::"+str(-nr), myString[::-nr]
    print str(-nr)+":", myString[-nr:]
    print str(-nr)+"::", myString[-nr::]


def replaceInNone():
    myStrings = []
    myStrings.append("Alpha")
    myStrings.append(None)
    myStrings.append(2)
    myStrings.append("Yankee")
    print myStrings
    for s in myStrings:
        if s:
            print s.replace("a", "i")
        else:
            print s


def multipleFields():
    myString = "alpha bravo charlie delta echo foxtrott golf hotel"
    print myString.split(' ')[1-2]
    
        

multipleFields()

#replaceInNone()
#playingWithFields()
#checkIfCharacterInLine()
#checkEmptyString()
#checkIfStringContainsCharacters()
#stringWithNone()
#getLastNElements()
#stringsWithRegularExpressions()
#compareStrings()
#splittingString()
#removeLastCharacterFromString()
#getLastItemOfString()
#getLastTwoItemsOfString()
#concatenateStringWithVar(" d e f")
#concatenateStrings()
#checkEmptyString()
#compareStrings()
#stringWithArguments()
#changeString()

