#!/usr/bin/env python

import parentPythonFile

parentPythonFile.printHelloWorld()
