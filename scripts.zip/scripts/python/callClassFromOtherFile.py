#!/usr/bin/env python

from fileWithClass import classZulu


class classAlpha():
    def callFunctionFromClassZulu(self):
        classZulu().zuluPrint()
    

classAlpha().callFunctionFromClassZulu()
