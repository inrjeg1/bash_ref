#!/usr/bin/env python

import os

def changeDir():
    os.chdir('..')
    os.system("pwd")
    os.system("/bin/bash")



if __name__ == "__main__":
    changeDir()
