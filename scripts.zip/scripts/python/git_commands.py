#!/usr/bin/env python

import subprocess
from datetime import datetime

def getListOfNewCommits(latestCommit=None):
    if latestCommit:
        cmd = 'git log --oneline | sed "/%s/q" | sed "$ d"' % latestCommit
    else:
        cmd = 'git log --oneline'

    newCommitsList = subprocess.Popen(cmd,
                                  cwd = "/boa_prd/ptacken/cc2boa2cc_testing", shell = True,
                                  stdout = subprocess.PIPE,
                                  stderr = subprocess.PIPE).stdout.read().strip()

    return newCommitsList

def createNewTag():
    #latestSyncTag = self._getLastSyncTag()
    listOfNewCommits = getListOfNewCommits()
    currentTime = datetime.now().strftime('%y%W.%w_%H%M%S')
  # print "=== Creating new sync tag ==="
    newTagName = 'pull-from-boa-wk'+currentTime

    print listOfNewCommits

    cmd  = 'git tag -a newTagNameDummy -m "%s"' % (listOfNewCommits)
 #   self.git(['tag', '-a', newTagName, '-m', listOfNewCommits])
    #return newTagName

    subprocess.Popen(cmd,
                                      cwd = "/boa_prd/ptacken/cc2boa2cc_testing", shell = True,
                                      stdout = subprocess.PIPE,
                                      stderr = subprocess.PIPE).stdout.read().strip()
createNewTag()
