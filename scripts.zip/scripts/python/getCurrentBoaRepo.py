#!/usr/bin/env python

import os

def getCurrentRepo():
    currentWd = os.getcwd()
    boaProjectName = "/boa_prd"

    if boaProjectName in currentWd:
        userName = currentWd.split('/')[2]
        repository = currentWd.split('/')[3]

        return boaProjectName + "/" + userName +"/" + repository
    else:
        return "None"


if __name__ == "__main__":
     print getCurrentRepo()
