#!/usr/bin/env python

def check_baselines():
    print "Checking baseline"
    

check_baselines()

