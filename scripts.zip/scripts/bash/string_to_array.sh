#!/bin/bash

stringA="alpha bravo charlie delta echo"
IF=' ' read -r -a arrayA <<< "$stringA"

echo "${arrayA[*]}"
