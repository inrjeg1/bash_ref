#!/bin/bash

function functionWithArgs
{
    argument=$1
    myLine="alpha_${1}_charlie"
    echo $myLine
    if [[ ! -z $argument ]]; then
        echo "argument found!"
    fi
    
}


functionWithArgs "bravo"
functionWithArgs

