#!/bin/bash
#
#allArgs="$@"
#boaProjectName="/boa_prd"
#currentDir=$PWD
#viewName=$(cleartool pwv -short)
#
#if [[ $viewName != "** NONE **" ]]; then
#    cd `xcd $allArgs`
#    echo $PWD
#    exit 0
#
#elif [[ $currentDir =~ $boaProjectName ]]; then
#    pathWithSlashes="${allArgs// //}"
#    depthDiff=1
#    dirToCheck=$currentDir
#    while [[ ! -z  $dirToCheck ]]; do
#        dirToCheck=`echo $currentDir | rev | cut -d'/' -f${depthDiff}- | rev`
#        echo "currentDir: $dirToCheck"
#        if [[ -d "${dirToCheck}/.boa" ]]; then
#            echo ${dirToCheck}/${pathWithSlashes}
#            exit 0
#        fi
#        ((depthDiff++))
#    done
#    echo "./"
#    exit 0
#else
#    echo "./"
#    exit 0
#fi

awk '{print $argv}'
