#!/bin/bash

n=0

while [[ $n -lt 100 ]]; do

    echo $n
    echo -e "\033[0;${n}mCOLOR...\033[m"
    ((n++))

done
