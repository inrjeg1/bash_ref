#!/bin/bash

viewName=$(cleartool pwv -short)

if [[ $viewName == "** NONE **" ]]; then
    echo "This script needs to be run from a Clearcase view"
    exit 1
fi

baselineDir="/exp/"`cclst_project | grep -F "project:" | cut -d":" -f3 | cut -d"@" -f1`
latestBaselineName=`ls -rt $baselineDir | tail -1`

/sdev/user/bin/ccmk_devpatch ${latestBaselineName}
/sdev/user/bin/ccmk_devpatch -T ALL ${latestBaselineName}_T
