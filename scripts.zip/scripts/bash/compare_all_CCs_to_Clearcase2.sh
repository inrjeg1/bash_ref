#!/bin/bash

ccList=`ccget_buildscope | cut -d'/' -f2`

for cc in $ccList; do
    
#    if [[ ( $cc != "KM" ) &&
#          ( $cc != "KMLD" ) &&
#          ( $cc != "KV" ) &&
#          ( $cc != "KVFM" ) &&
#          ( $cc != "KR" ) &&
#          ( $cc != "KVLIPG" ) &&
#          ( $cc != "KMLIWA" ) ]]; then
#        echo -n ""
#    else
        echo "============ $cc ============"
        cd `xcd $cc com`
    
        /sdev_shared/fc062data/PTAD/scripts/bash/compare_to_clearcase2.sh 20
#    fi
done


