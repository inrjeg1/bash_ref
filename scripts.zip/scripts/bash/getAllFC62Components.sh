#!/bin/bash

viewName="/view/pub_at_qbl_wk829_int"

cd $viewName
