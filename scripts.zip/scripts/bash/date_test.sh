#!/bin/bash

set -e

some_name="BLADIEBLA"

name="SOME_NAME_${some_name}_`date +%Y%m%d_%H%M%S`"

echo $name

