#!/bin/bash

myList2="\
alpha\
"


for item in $myList2; do
    echo "i: $item"
done

