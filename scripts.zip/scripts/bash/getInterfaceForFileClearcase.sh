#!/bin/bash

if [[ $# -lt 1 ]]; then
    echo "Please provide a file name"
    exit 1
fi

fileName=$1
ccName=`/sdev_shared/fc062data/PTAD/scripts/bash/get_current_component_name.sh`
allComponents=`ccget_buildscope 2>/dev/null | cut -d'/' -f2`
currentCC=`/sdev_shared/fc062data/PTAD/scripts/bash/get_current_component_name.sh`
viewName=$(cleartool pwv -short)
scopeFiles=''

if [[ $viewName == "** NONE **" ]]; then
    echo "This script needs to be executed from a Clearcase view"
    exit 1
fi

if [[ -z $currentCC ]]; then
    for component in $allComponents; do
       if [[ $fileName =~ "${component}/com/" ]]; then
            currentCC=$component
            break
        fi
    done
    if  [[ -z $currentCC ]]; then
        currentCC=`/sdev_shared/fc062data/PTAD/scripts/bash/getComponent.sh $fileName`
    fi
fi

fileName=`echo "$fileName" | rev | cut -d'/' -f1 | rev`

if [[ -z $currentCC ]]; then
    scopeFiles=`/sdev_shared/fc062data/PTAD/scripts/bash/getAllScopefilesInBuildscope.sh`
else
    cd `xcd $currentCC`
    currentDir=$PWD
    cd ../xscm
    currentDir=$PWD
    scopeFiles=`ls BB-*ternal_scope.txt.2 BB-*_test_scope.txt.2 | sed -e "s@^@${currentDir}/@"`
fi


for scopeFile in $scopeFiles; do
    interfaceName=''
    insideInterface=0
    while IFS='' read -r line || [[ -n "$line" ]]; do
        if [[ $insideInterface -eq 1 ]]; then
            if [[ $line =~ $fileName ]]; then
                echo $interfaceName
                break
            elif [[ $line =~ "}" ]]; then
            insideInterface=0
            fi
        elif [[ $line =~ "interface" ]]; then
            insideInterface=1
            interfaceName=`echo $line  | cut -d' ' -f2`
        fi
    done < "$scopeFile"
done
