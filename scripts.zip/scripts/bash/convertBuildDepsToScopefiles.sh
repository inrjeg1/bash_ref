#!/bin/bash

viewName=$(cleartool pwv -short)

if [[ $viewName == "** NONE **" ]]; then
    echo "This script needs to be run from a Clearcase view"
    exit 1
fi

if [[ ! -e '/tmp/scope_delta.txt' ]]; then
    echo "You first must execute the following command in a local BOA repo:"
    echo "scopeset delta -d . -f /tmp/scope_delta.txt -w /tmp/scope_warnings.txt"
    exit 1
fi

mkdir -p /tmp/LIL_scope

ccrscope -F -d /tmp/scope_delta.txt -o /tmp/LIL_scope -O write_touched_only
ls -1 /tmp/LIL_scope > /tmp/LIL_scopefiles.lst
/vobs/litho/scm/scopecontrol/interfaces/int/tst/scope_file_list.pl | grep -f /tmp/LIL_scopefiles.lst > /tmp/LIL_scopefiles_full_path.lst
sed -i 's/.txt$/.txt.2/' /tmp/LIL_scopefiles_full_path.lst
cleartool co -nc `cat /tmp/LIL_scopefiles_full_path.lst`
#
#mkdir -p /tmp/LIL_scope_warnings
#ccrscope -F -d /tmp/scope_warnings.txt -o /tmp/LIL_scope_warnings -O write_touched_only
#ls -1 /tmp/LIL_scope_warnings > /tmp/LIL_scope_warningsfiles.lst
#/vobs/litho/scm/scopecontrol/interfaces/int/tst/scope_file_list.pl | grep -f /tmp/LIL_scope_warningsfiles.lst > /tmp/LIL_scope_warningsfiles_full_path.lst
#sed -i 's/.txt$/.txt.2/' /tmp/LIL_scope_warningsfiles_full_path.lst
#cleartool co -nc `cat /tmp/LIL_scope_warningsfiles_full_path.lst`


echo -e "\nManual steps to be taken:"
echo "* Merge the scopefiles in /tmp/LIL_scope and filenames in /tmp/LIL_scopefiles_full_path.lst. For this you can use the following command:"
echo "/sdev_shared/fc062data/PTAD/scripts/bash/diffConvertedScopefiles.sh"

echo "* Run ccrscope -p"
