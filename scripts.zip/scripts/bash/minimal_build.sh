#!/bin/bash

#git clean -dfx
#/boa_proj_build/skersten/target-store/retrieve-targets.sh


gradle externalStub && 
gradle buildLibrariesLnx && 
gradle internalTestLnx_nodeps && 
gradle internalExecutablesLnx_nodeps
