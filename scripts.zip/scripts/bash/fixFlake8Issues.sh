#!/bin/bash

if [ $# -lt 1 ]; then
    echo "No input file provided"
    exit 0
fi

inputFile=$1
outputFile="${1}.output"

flake8Output=`flake8 $inputFile`

IFS=$'\r\n' GLOBIGNORE='*' command eval 'fOutput=(`printf "%s\n" "${flake8Output[@]}"`)'

nrLines=(`printf "%s\n" "${fOutput[@]}" | wc -l`)

echo $nrLines

for line in (`printf "%s\n" "${fOutput[@]}"`)
do
    echo $line
done


