#!/bin/bash


if [[ ($1 == "-h") || ($1 == "--help") ]]; then
    echo "Usage: $0 <review id> <files to upload>"
    exit 0
fi

if [[ ! ($1 =~ ^[0-9]+$) ]]; then
    echo "The first argument needs to be the review ID"
    exit 1
fi

if [[ $# -lt 2 ]]; then
    echo "Please provide at least on filename as input"
    exit 1
fi

reviewId=$1
fileNames=`echo "${@:2}" | tr " " "\n"`
current_stream=`cleartool lsstream | cut -d" " -f3`
cur_release=`ls /view/ | sort | grep pub_at_qbl | grep -v '@' |tail -1`

if [[ $current_stream =~  "at4.5.7" ]]; then
   cur_release="pub_at4.5.7_int"
elif [[ $current_stream =~ "at5.0" ]]; then
   cur_release="pub_at5.0_int"   
elif [[ $current_stream =~ "at6.0" ]]; then
   cur_release="pub_at6.0_int"   
elif [[ $current_stream =~ "at6.1" ]]; then
   cur_release="pub_at6.1_int"   
elif [[ $current_stream =~ "at6.2" ]]; then
   cur_release="pub_at6.2_int"
elif [[ $current_stream =~ "at6.3" ]]; then
   cur_release="pub_at6.3_int"
elif [[ $current_stream =~ "at7.2" ]]; then
   cur_release="pub_at7.2_int"
fi

echo " -->Using $cur_release as reference"

parentPath="/view/${cur_release}"

while read fileName; do
    echo -n "Uploading ${fileName} ... "
    ccollab adddiffs ${reviewId} ${parentPath}/${fileName} ${fileName}
    echo "done!"
    
done < <(echo "$fileNames")

