#!/bin/bash

ccset_view ptacken_lvl_at_qbl_LIL_v1_2_int
echo `pwd`





