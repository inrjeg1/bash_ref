#!/bin/bash

fileName="dummy_txt.txt"

function replaceString()
{
    myString="$@"
    #myString="oscar"
    #echo "myString: $myString"
    sed  -i '/\
lima\
mike/c\' $fileName


}


someString='interface KMLICOxCONTROLxNSLIB
{
  contains   KMLICO/com/ext/lib/bld_x86lnx/libKMLICO_asdGlobalWaferShapeDataAdapter.cpp.so
  contains   KMLICO/com/ext/lib/bld_x86lnx/libKMLICO_asdLogicalWaferPredicates.cpp.so
  contains   KMLICO/com/ext/lib/bld_x86lnx/libKMLICO_asdMdlLogging.cpp.so
  contains   KMLICO/com/ext/lib/bld_x86lnx/libKMLICO_asdTaskMode.cpp.so
  contains   KMLICO/com/ext/lib/bld_x86lnx/libKMLICO_asdTaskModeStore.cpp.so
  contains   KMLICO/com/ext/lib/bld_x86lnx/libKMLICO_asdVerticalCalculationsCoreDataAdapter.cpp.so
  provided_at  building_block
}'

#echo $someString

replaceString "$someString"


https://unix.stackexchange.com/questions/163428/replace-a-string-containing-newline-characters

