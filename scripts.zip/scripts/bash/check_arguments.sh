#!/bin/bash


function run_VDI
{
    echo "function"
    echo $@

}

echo "arg zero: $0"

if [[ $1 == "run"* ]]; then
   echo "AAAAAA"
   $1 "${@:2}"
   
fi


echo "all arguments: $@"

if [[ "$@" =~ 39 ]];
    then echo "TRUE"
fi

#if [[ $1 = "run"* ]]; then
#   $1 "${@:2}"


a=1
b=0

if [[ $a == 1 ]]; then
    echo "A IS TRUE"
fi


if [[ $b == 1 ]]; then
    echo "B IS TRUE"
fi

