#!/bin/bash

current_dir=`pwd`
current_dir_base=`basename $current_dir`
componentName=`echo $current_dir | rev | cut -d'/' -f4 | rev`


if [[ (($current_dir_base != "ddf") && \
       ($current_dir_base != "inc") && \
       ($current_dir_base != "lib") && \
       ($current_dir_base != "bin") && \
       ($current_dir_base != "tst")) ]]; then
    echo "You need to be in 'inc', 'lib', 'bin', 'tst' or 'ddf'"
    exit 1
fi


function changeIncludePath
{
    fileName=$1
    interfaceDir=$2
    includeName=$3

    echo "Checking out file: ${fileName}"
    cleartool co -nc $fileName

    echo -e "Adding interface name $interfaceDir to include ${includeName}\n"
    
    echo ${includeLine}
    echo ${newIncludeLine}
    
    sed -i -e "s@${includeLine}@${newIncludeLine}@" $fileName
}


allOccurrences=`find . -maxdepth 1 -type f -name "*" | xargs grep include | egrep -e "(typ.hpp|typ.h|met.hpp|met.h)" | cut -d'/' -f2- | grep -v '/'`


IFS='
'
for occurrence in $allOccurrences; do
    fileName=`echo $occurrence | cut -d':' -f1`
    includeLine=`echo $occurrence | cut -d':' -f2`
    includeName=`echo $includeLine | cut -d' ' -f2- | sed 's/"//g'`
    newIncludeLine=""

    ## GO TO XIFS
    cd ../../../xifs/
    
    ls | grep $componentName | while read interfaceDir; do
        
        if [[ -e "${interfaceDir}/${includeName}" ]]; then

            if [[ ! -e "${interfaceDir}/${fileName}" ]]; then
                newIncludeLine="#include \"${interfaceDir}/${includeName}\""

                cd $current_dir

                ## CHANGE THE INCLUDE
                changeIncludePath $fileName $interfaceDir $includeName
            fi
            break
        fi
    done
    
    ## GO TO CURRENT DIRECTORY
    cd $current_dir

done 
