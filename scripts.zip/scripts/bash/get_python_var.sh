#!/bin/bash

pythonVariable=$1

firstPart=`echo $pythonVariable | cut -d'.' -f1`
secondPart=`echo $pythonVariable | cut -d'.' -f2`

#output=$((python -c "import ${firstPart}; print ${firstPart}.${secondPart}") 2> &1)

#echo $output


python -c "import ${firstPart}; print ${firstPart}.${secondPart}"

