#!/bin/bash

currentDir=`pwd`
#otherCCDir="/view/ptacken_at6.3_dumbo_9449_SP11_int"
#otherCCDir="/view/orudenko_lvl_at_qbl_NPI_SP15"
#otherCCDir="/view/rjeganat_lvl_at_qbl_NPI_sp14_int"
#otherCCDir="/view/ptacken_lvl_at_qbl_ENGMv2_fix_int"
#otherCCDir="/view/ptacken_at6.3_dumbo_SP10_base_int"
#otherCCDir="/view/kvarbano_at6.3.0.b_p9611_sync_changes_from_9449"
#otherCCDir="/view/avalk_lvl_at_qbl_NPI_SP15_int"
#otherCCDir="/view/rjeganat_lvl_at_qbl_NPI_SP16_int"
otherCCDir="/view/ptacken_lvl_at_qbl_NPI_20_int"
#otherCCDir="/view/ptacken_at_qbl_FC062_lvl_NXT1470_int"


if [[ ! -d $otherCCDir ]]; then
    echo "Given view $otherCCDir not found!"
    exit 1
fi


searchDepth=1
do_copy=0

if [[ "$#" -gt 0 ]]; then
    
    if [[ "$@" =~ "DO_COPY" ]]; then
        do_copy=1
    fi
    anyNumber='^[0-9]+$'
    if [[ $1 =~ $anyNumber ]]; then
        searchDepth=$1
    else
        fileName=$1
        fileDir="./"
        if [[ $fileName =~ "/" ]]; then
            fileDir=`echo $fileName | rev | cut -d'/' -f2- | rev`
            fileName=`echo $fileName | rev | cut -d'/' -f1 | rev`
        fi
        cd $fileDir
        currentDir=`pwd`

        #if [[ -e $fileName ]]; then
            if [[ $do_copy == 1 ]]; then
                echo -n "Copying changes from ${otherCCDir}/${currentDir}/${fileName} ..."
                cleartool co -nc ./${fileName} > /dev/null 2>&1
                cat ${otherCCDir}/${currentDir}/${fileName} > ./${fileName}
                cleartool ci -nc ./${fileName} > /dev/null 2>&1
                echo "done!"
            else
                fileNotFound=0
                if [[ ! -e ${otherCCDir}/${currentDir}/${fileName} ]]; then
                    echo "ERROR: File not found: ${otherCCDir}/${currentDir}/${fileName}"
                    fileNotFound=1
                fi
                if [[ ! -e ${fileName} ]]; then
                    echo "ERROR: File not found:  ${fileName}"
                    fileNotFound=1
                fi
                if [[ $fileNotFound -eq 1 ]]; then
                    exit 1
                fi
                
                diffOutput=`diff ${otherCCDir}/${currentDir}/${fileName} ${fileName}`
                if [[ ! -z $diffOutput ]]; then
                    #kdiff3 ${otherCCDir}/${currentDir}/${fileName} ${fileName}
                    bcompare ${otherCCDir}/${currentDir}/${fileName} ${fileName}
                else
                    echo "  === File $fileName is equal to $otherCCDir ==="
                fi
            fi
            exit 0
        #elif [[ $do_copy == 0 ]]; then
#            echo "=== Invalid argument ==="
#            exit 1
#        fi
        
    fi
fi


allFilesOtherCC=`find ${otherCCDir}/${currentDir}/ -maxdepth $searchDepth | grep -v '/bld' | grep -v '/bld_x86lnx' | grep -v '\.contrib' | grep -v '\.cmake.state'`
allFilesCurrentCC=`find . -maxdepth $searchDepth | grep -v '/bld' | grep -v '/bld_x86lnx' | grep -v '\.contrib' | grep -v '\.cmake.state'`


## CHECK FOR DIFFS BETWEEN CURRENT CLEARCASE AND OTHER CLEARCASE PER FILE

diffsPerFileLinePrinted=0

function printDiffsPerFileLine()
{
    echo "============================================"
    echo "=              DIFFS PER FILE              ="
    echo "============================================"
    diffsPerFileLinePrinted=1
}

filesNotPresentInCurrentCC=""
filesNotPresentInOtherCC=""

IFS=''
while read fileName; do

    if [[ $fileName =~ "genmakefile" ]]; then
        echo -n ''
        #do nothing

    elif [[ -e ${otherCCDir}/${currentDir}/${fileName} || \
            -L ${otherCCDir}/${currentDir}/${fileName} ]]; then
        
        echo -n ''

        ##check if file is a file (iso e.g. a link)
        if [[ -L ${otherCCDir}/${currentDir}/${fileName} ]]; then
            
            if [[ ! -L ${fileName} ]]; then
                filesNotPresentInCurrentCC=`echo -e "${filesNotPresentInCurrentCC}\n== ${fileName} is a link in the other CC view! =="`
            fi
        fi

        if [[ -f ${otherCCDir}/${currentDir}/${fileName} ]]; then  

            diffOutput=`diff -y --suppress-common-lines --strip-trailing-cr ./${fileName} ${otherCCDir}/${currentDir}/${fileName}`

            if [[ ! -z $diffOutput ]]; then
                if [[ $diffsPerFileLinePrinted -eq 0 ]]; then
                    printDiffsPerFileLine
                fi
            
                echo -e "\n=== FILENAME: ${fileName} ==="
                
                if [[ $do_copy == 1 ]]; then
                    echo -n "Copying changes from ${otherCCDir}/${currentDir}/${fileName} ..."
                    cleartool co -nc ./${fileName} > /dev/null 2>&1
                    cat ${otherCCDir}/${currentDir}/${fileName} > ./${fileName}
                    cleartool ci -nc ./${fileName} > /dev/null 2>&1
                    echo "done!"
                else
                    echo "$diffOutput"
                    echo -e "=========================================\n"
                fi
            fi
        fi
    else
        filesNotPresentInOtherCC=`echo -e "${filesNotPresentInOtherCC}\n${fileName}"`
    fi
done < <(echo $allFilesCurrentCC)


## SHOW FILES PRESENT IN CLEARCASE BUT NOT IN BOA

if [[ ! -z $filesNotPresentInOtherCC ]]; then
    echo "============================================"
    echo "=         FILES NOT PRESENT IN OTHER CC    ="
    echo "============================================"
    
    echo -e "$filesNotPresentInOtherCC\n"
fi


## CHECK FOR FILES MISSING IN CLEARCASE

IFS=''
while read fileName; do

    newFileName=`echo ${fileName} | sed "s@${otherCCDir}/${currentDir}@.@"`
    
    if [[ ! (( -e  ${newFileName} ) ||
            ( -L  ${newFileName} )) ]]; then
               
        filesNotPresentInCurrentCC=`echo -e "${filesNotPresentInCurrentCC}\n${newFileName}"`
        
        if [[ -d ${fileName} ]]; then
            filesNotPresentInCurrentCC="${filesNotPresentInCurrentCC}/"
        fi
        
        
    fi
done < <(echo $allFilesOtherCC)


if  [[ ! -z $filesNotPresentInCurrentCC ]]; then
    echo "============================================"
    echo "=      FILES NOT PRESENT IN THIS CC       ="
    echo "============================================"
    
    echo -e "$filesNotPresentInCurrentCC\n"
fi

