#!/bin/bash

currentDir=`pwd`
currentDirBase=`basename $currentDir`
#boaDir="/boa_prd/ptacken/lil-development"
boaDir="/boa_prd/ptacken/lil-development-2"
#boaDir="/shared/nl011012_u/atlevel/Leveling/JKRJ/Twinrunr_tests"
#boaDir="/boa_prd/rjeganat/lil-development"


if [[ ! -d $boaDir ]]; then
    echo "Given BOA path $boaDir not found!"
    exit 1
fi


dirDepth=`/sdev_shared/fc062data/PTAD/scripts/bash/findDepth.sh`

if [[ $dirDepth -gt 0 ]]; then
    pathToDir=`echo $currentDir | rev | cut -d'/' -f-${dirDepth} | rev`
else
    pathToDir='.'
fi

searchDepth=1
do_copy=0

if [[ "$#" -gt 0 ]]; then
    
    if [[ "$@" =~ "DO_COPY" ]]; then
        do_copy=1
    fi
    anyNumber='^[0-9]+$'
    if [[ $1 =~ $anyNumber ]]; then
        searchDepth=$1
    elif [[ $1 != "DO_COPY" ]]; then
        fileName=$1
        fileDir="./"
        if [[ $fileName =~ "/" ]]; then
            fileDir=`echo $fileName | rev | cut -d'/' -f2- | rev`
            fileName=`echo $fileName | rev | cut -d'/' -f1 | rev`
        fi
        cd $fileDir
        currentDir=`pwd`
        
        
        dirDepth=`/sdev_shared/fc062data/PTAD/scripts/bash/findDepth.sh`

        if [[ $dirDepth -gt 0 ]]; then
            pathToDir=`echo $currentDir | rev | cut -d'/' -f-${dirDepth} | rev`
        else
            pathToDir='.'
        fi
        
        #if [[ -e $fileName ]]; then
            
            if [[ $do_copy -eq 1 ]]; then
                echo -n "Copying changes from ${boaDir}/${pathToDir}/${fileName} ..."
                cleartool co -nc ./${fileName} > /dev/null 2>&1
                cat ${boaDir}/${pathToDir}/${fileName} > ./${fileName}
                echo "done!"
            else
                diffOutput=`diff ${boaDir}/${pathToDir}/${fileName} ${fileName}`
                if [[ ! -z $diffOutput ]]; then
                    bcompare ${boaDir}/${pathToDir}/${fileName} ${fileName}
                    #kdiff3 ${boaDir}/${pathToDir}/${fileName} ${fileName}
                elif [[ -e ${boaDir}/${pathToDir}/${fileName} ]]; then
                    echo "  === File $fileName is equal to BOA ==="
                fi
            fi
            exit 0
#        elif [[ $do_copy == 0 ]]; then
#            echo "=== Invalid argument ==="
#            exit 1
#        fi
    fi
fi


allFilesBOA=`find ${boaDir}/${pathToDir}/ -maxdepth $searchDepth -mindepth 1 | grep -v gitignore | grep -v '/bld' | grep -v '/bld_x86lnx' | grep -v Makefile | grep -v targets.mk | grep -v xifs_ | grep -v '\.pyc' | grep -v '.valgrindrc' | grep -v 'xifs_'`
allFilesCC=`find . -maxdepth $searchDepth | grep -v '/bld' | grep -v '/bld_x86lnx' | grep -v 'cmake' | grep -v '\.contrib' |  grep -v targets.mk | grep -v '.valgrindrc' | grep -v 'xifs_'`


## CHECK FOR DIFFS BETWEEN BOA AND CLEARCASE PER FILE

diffsPerFileLinePrinted=0

function printDiffsPerFileLine()
{
    echo "============================================"
    echo "=              DIFFS PER FILE              ="
    echo "============================================"
    diffsPerFileLinePrinted=1
}

filesNotPresentInBOA=""
filesNotPresentInCC=""

IFS=''
while read fileName; do

    if [[ -e ${boaDir}/${pathToDir}/${fileName} || \
          -L ${boaDir}/${pathToDir}/${fileName} ]]; then
        
        echo -n ''
       # echo -e "\npathToDir: ${pathToDir}/${fileName}"
        
        pathToCheck="${pathToDir}/${fileName}"
        
        if [[ ( $pathToCheck =~  "com/./makefile" ) ||
              ( $pathToCheck =~ "com/./int/makefile" ) || 
              ( $pathToCheck =~ "com/./ext/makefile" ) ||
              ( $pathToCheck =~ "KVLICOconverters.zip" ) ]]; then
              continue
        fi

        ##check if file is a file (iso e.g. a link)
#        if [[ -L ${boaDir}/${pathToDir}/${fileName} ]]; then
#            
#            if [[ ! -L ${fileName} ]]; then
#                filesNotPresentInCC=`echo -e "${filesNotPresentInCC}\n== ${fileName} is a link in BOA! =="`
#            fi
        
       # if [[ ! $fileName =~ "makefile" ]];then
        
        
            if [[ (-f ${boaDir}/${pathToDir}/${fileName} ) || (-L ${boaDir}/${pathToDir}/${fileName})  ]]; then  

                diffOutput=`diff --strip-trailing-cr ./${fileName} ${boaDir}/${pathToDir}/${fileName}`

                if [[ ! -z $diffOutput ]]; then
                    if [[ $do_copy -eq 1 ]]; then
                        echo -n "Copying changes from ${boaDir}/${pathToDir}/${fileName} ..."
                        cleartool co -nc ./${fileName} > /dev/null 2>&1
                        cat ${boaDir}/${pathToDir}/${fileName} > ./${fileName}
                        echo "done!"
                    else
                        if [[ $diffsPerFileLinePrinted -eq 0 ]]; then
                            printDiffsPerFileLine
                        fi

                        echo -e "\n=== FILENAME: ${fileName} ==="

                        echo "$diffOutput"
                        echo -e "=========================================\n"
                    fi
                fi
            fi
        # fi
    else
        filesNotPresentInBOA=`echo -e "${filesNotPresentInBOA}\n${fileName}"`
    fi
done < <(echo $allFilesCC)


## SHOW FILES PRESENT IN CLEARCASE BUT NOT IN BOA

if [[ ! -z $filesNotPresentInBOA ]]; then
    echo "============================================"
    echo "=         FILES NOT PRESENT IN BOA         ="
    echo "============================================"
    
    echo -e "$filesNotPresentInBOA\n"
fi


## CHECK FOR FILES MISSING IN CLEARCASE

IFS=''
while read fileName; do

    newFileName=`echo ${fileName} | sed "s@${boaDir}/${pathToDir}@.@"`

    
    if [[ ! (( -e  ${newFileName} ) ||
            ( -L  ${newFileName} )) ]]; then
               
        filesNotPresentInCC=`echo -e "${filesNotPresentInCC}\n${newFileName}"`
        
        if [[ -d ${fileName} ]]; then
            filesNotPresentInCC="${filesNotPresentInCC}/"
        fi
        
        
    fi
done < <(echo $allFilesBOA)


if  [[ ! -z $filesNotPresentInCC ]]; then
    echo "============================================"
    echo "=      FILES NOT PRESENT IN ClearCase      ="
    echo "============================================"
    
    echo -e "$filesNotPresentInCC\n"
fi

