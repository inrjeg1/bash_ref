#!/bin/bash


alpha=":/usr/local/cadappl/cadlib/\                <"
bravo=":/usr/local/cadappl/cadlib/\                <"


if [[ "$alpha" != "$bravo" ]]; then
    echo "NOT EQUAL"
else
    echo "EQUAL"
fi



