#!/bin/bash

#-----------------------------------------------------------------------------#
#                                                                             #
#       Copyright (c) 2015, ASML Holding N.V. (including affiliates).         #
#                         All rights reserved                                 #
#                                                                             #
#-----------------------------------------------------------------------------#

export CADENV_HOME=$WORKSPACE/.caddir/RHEL6
export CADDIR=$CADENV_HOME
export GEM_HOME=$WORKSPACE/.gem
export GRADLE_USER_HOME=$WORKSPACE/.gradle_cache
export TMPDIR=/tmp

export PATH=/boa_prd/boa_ccaches/Template:$GEM_HOME/bin:/cadappl/bin:$CADDIR/cadbin:.:/bin:/usr/bin:/usr/sbin:/usr/local/bin:/sdev/user/bin:/sdev/user/bin/x86_32-linux:/opt/rational/clearcase/bin:$PATH
export LD_LIBRARY_PATH=$CADDIR/cadlib:/usr/local/lib:/lib:/usr/lib:/usr/X11R6/lib:/sdev/user/lib/x86_32-linux:/opt/rational/clearcase/shlib:/opt/rational/clearquest/shlib:$LD_LIBRARY_PATH

mkdir -p $CADENV_HOME
mkdir -p $GEM_HOME
mkdir -p $GRADLE_USER_HOME

jenkins-tooling/installers.sh installJdk
jenkins-tooling/installers.sh installPython
jenkins-tooling/installers.sh installGradle
jenkins-tooling/installers.sh installGit
jenkins-tooling/installers.sh installGcc
jenkins-tooling/installers.sh installBoost
jenkins-tooling/installers.sh installGtest
jenkins-tooling/installers.sh installGmock
jenkins-tooling/installers.sh installRuby
