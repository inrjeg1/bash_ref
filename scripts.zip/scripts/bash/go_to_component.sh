#!/bin/bash

repository=`/sdev_shared/fc062data/PTAD/scripts/bash/get_current_repository.sh`
viewName=$(cleartool pwv -short)
component=$1

if [[ "$viewName" != "** NONE **" ]]; then
    cd `xcd $component`
    echo $PWD
elif [[ $repository != "./" ]]; then
    echo "${repository}/$component"
else
    exit 1
fi
