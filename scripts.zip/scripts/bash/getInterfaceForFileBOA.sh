#!/bin/bash

if [[ $# -lt 1 ]]; then
    echo "Please provide a file name"
    exit 1
fi

fileName=$1
ccName=`/sdev_shared/fc062data/PTAD/scripts/bash/get_current_component_name.sh`
allComponents=`/sdev_shared/fc062data/PTAD/scripts/bash/allComponents.sh`
currentCC=`/sdev_shared/fc062data/PTAD/scripts/bash/get_current_component_name.sh`
currentRepo=`/sdev_shared/fc062data/PTAD/scripts/bash/get_current_repository.sh`
buildDependenciesFiles=''
viewName=$(cleartool pwv -short)

if [[ "$viewName" != "** NONE **" || 
      $currentRepo == "./" ]]; then
    echo "This script needs to be executed from a BOA repo"
    exit 1
fi


if [[ -z $currentCC ]]; then
    for component in $allComponents; do
       if [[ $fileName =~ "${component}/com/" ]]; then
            currentCC=$component
            break
        fi
    done
fi

fileName=`echo "$fileName" | rev | cut -d'/' -f1 | rev`

if [[ -z $currentCC ]]; then
    cd $currentRepo
    
    buildDependenciesFiles=`/sdev_shared/fc062data/PTAD/scripts/bash/find_grep.sh $fileName | grep "buildDependencies.gradle" | cut -d" " -f1 | sort | uniq`
else
    buildDependenciesFiles="${currentRepo}/${currentCC}/buildDependencies.gradle"
fi

IFS='
'
for buildDepsFile in $buildDependenciesFiles; do
    interfaceName=''
    insideProvidedScope=0
    while IFS='' read -r line || [[ -n "$line" ]]; do
        if [[ $line =~ $fileName ]]; then
             echo $interfaceName
             break
         elif [[ $insideProvidedScope -eq 1 ]]; then
             if [[ ($line =~ '{') && 
                   (! $line =~ "requiredInterfaces") &&
                   (! $line =~ "requiredTestInterfaces") ]]; then
                 interfaceName=`echo $line | sed 's/{//' | sed 's/ //g'`
             fi
         elif [[ $line =~ "providedInterfaces" ]]; then
             insideProvidedScope=1
         fi
    done < "$buildDepsFile"
done
