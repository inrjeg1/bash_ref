#!/bin/bash

failed=0

echo "PASS"

exit $failed


