#!/bin/bash

source "$(dirname $(ls -l $0 | tr -s ' ' | cut -d' ' -f$(test -h $0 && echo 11 || echo 9)))/inc"

get_tel()
{
   local tel=$(utel $1 2>/dev/null | grep '^'$1' .*' | tr "\t" ' ' | tr -s ' ' | cut -d' ' -f 2 | head -n 1)
   [ $? -ne 0 -o -z "$tel" ] && tel="...."
   echo $tel
}

get_name()
{
   local name=$(ypcat -k aliases 2>/dev/null | grep '^'$1' .*' | tr "\t" ' ' | tr -s ' ' | head -n 1)
   [ $? -ne 0 -o -z "$name" ] && name="$1"
   echo $name
}

show_user()
{
   if [ ! -z "$2" ]; then      
      printf "%-20s: %s (tel: %s)\n" "$1" "$(get_name $2)" "$(get_tel $2)"
   fi
}

check_rp()
{
   local RPNAME=${2}
   
   if [ "${SCM_WS}" == "/vobs/litho" ]; then
      RP=$(cat $(xcd ${1} 2>/dev/null)/.scm/location.bbl 2>/dev/null | grep "RP:" | cut -d' ' -f2)
      if [ ! -z "$RP" -a "$RP" != ${2} ]; then
         RPNAME=${RP}
         echo " #############################################################"
         echo " # Release Part info in release differs from ClearQuest..."
         echo " # - ClearQuest: ${2}"
         echo " # - Release   : ${RPNAME}"
         echo " #############################################################"
      fi
   fi
   printf "%-20s: %s\n" "Release Part" "${RPNAME}"
}

check_bb()
{
   local BBNR=${2}
   local BBNAME=${3}
   local BBOWNER=${4}
   local BBDELEGATE=${5}
   
   if [ "${SCM_WS}" == "/vobs/litho" ]; then
      BB=$(cat $(xcd ${1} 2>/dev/null)/.scm/location.bbl 2>/dev/null | grep "BBID:" | cut -d' ' -f2)
      if [ ! -z "$BB" -a "$BB" != ${2} ]; then
         local temp=$(cqfetch -fs '|' -rt BB -eq Number ${BB} -fld Name Owner Delegate)
         BBNR=$BB
         BBNAME=$(echo $temp | cut -d'|' -f1)
         BBOWNER=$(echo $temp | cut -d'|' -f2)
         BBDELEGATE=$(echo $temp | cut -d'|' -f3)

         echo " #############################################################"
         echo " # Building Block info in release differs from ClearQuest..."
         echo " # - ClearQuest   : ${2} ${3}"
         show_user " #    BB Owner" ${4}
         show_user " #    BB Delegate " ${5}
         echo " # - Release      : ${BBNR} ${BBNAME}"
         echo " #############################################################"
      fi
   fi

   printf "%-20s: %s\n" "Building Block" "${BBNR} > ${BBNAME}"
   show_user "BB Owner" ${BBOWNER}
   show_user "BB Delegate" ${BBDELEGATE}
}

write_fc()
{
   show_user "FC Architect(s)" ${1}
}


check_fc()
{
   local FCNR=${1}
   local temp=$(cqfetch -fs '|' -rt FC -eq Number ${FCNR} -fld Architects.login_name )

   for fc_arch in ${temp}; do
      write_fc ${fc_arch}
   done
}

check_layer()
{
   local CCname=${1}
   local temp=$(cqfetch -fs '|' -rt Component -eq Identifier ${CCname} -fld Layer.Name )

   for layer in ${temp}; do
      printf "%-20s: %s\n" "Layer" "${layer}"
   done
   
}

write_cc_set()
{
   
   if [ $SHORT ]; then   
      printf "%-20s: %s\n" "${1}" "${2}"
   else
      printf "%-20s: %s\n" "Component" "${1} > ${2}"
      show_user "CC Owner" ${3}
      show_user "CC Delegate" ${4}
      check_bb "${1}" "${5}" "${6}" "${7}" "${8}"
      printf "%-20s: %s '%s'\n" "Functional Cluster" "${9}" "${10}"
      check_fc ${9}
      check_layer "${1}"
      check_rp "${1}" "${11}"
      printf "%-20s: %s\n" "Assembly" "${12}"
      show_user "GL" ${13}
      echo
   fi
}

write_bb_set()
{
   
   if [ $SHORT ]; then   
      printf "%-20s: %s\n" "${1}" "${2}"
   else
      printf "%-20s: %s\n" "Building Block" "${1} > ${2}"
      show_user "BB Owner" ${3}
      show_user "BB Delegate" ${4}
      printf "%-20s: %s '%s'\n" "Functional Cluster" "${5}" "${6}"
      check_fc ${5}
      # check_layer "${1}"
      printf "%-20s: %s\n" "Release Part" "${7}"
      # check_rp "${1}" "${7}"
      printf "%-20s: %s\n" "Assembly" "${8}"
      echo
   fi
}


usage()
{
   show_usage f "Search for part of name" s "Short, only show component" b "Take building blocks as input instead of components" "<CC> [ <CC> ... ]" 
   exit
}

SEARCH="-eq"
SHORT=
BUILDING_BLOCK=

while getopts fhsb opt
do
   case $opt in
      's') SHORT=true ;;
      'f') SEARCH="-like" ;;
      'b') BUILDING_BLOCK=true ;;
      'h'|*) usage ;;
   esac
done
shift $[ $OPTIND - 1 ]

if [ -z "$1" ]; then
   usage
fi

FIELDS="Components.Identifier 
        Components.Name 
        Components.Owner 
        Components.Delegate 
        Number 
        Name 
        Owner 
        Delegate 
        FC.Number 
        FC.Name
        RP
        Assembly.Identifier
        Components.GL"

if [ $BUILDING_BLOCK ]; then
   FIELDS="Number 
           Name 
           Owner 
           Delegate 
           FC.Number 
           FC.Name
           RP
           Assembly.Identifier"
fi
       
while [ ! -z $1 ]
do
   FOUND=
   if [ ! $SHORT ]; then   
      echo "Search results for: $1"
      echo "---------------------------"   
   fi
   if [ ! $BUILDING_BLOCK ]; then
      while read line
      do
         eval write_cc_set \"$(echo $line | sed -e 's,|," ",g')\"
         FOUND=TRUE
      done < <(cqfetch -fs '|' -rt BB ${SEARCH} Components.Identifier $1 -fld $FIELDS)
   else
      while read line
      do
         eval write_bb_set \"$(echo $line | sed -e 's,|," ",g')\"
         FOUND=TRUE
      done < <(cqfetch -fs '|' -rt BB ${SEARCH} Number $1 -fld $FIELDS)
   fi
   [ ! $FOUND ] && printf "%-20s: Search did not return any results...\n" "$1"
   shift
done
