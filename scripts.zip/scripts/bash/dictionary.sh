#!/bin/bash

declare -A alphabet=(["a"]="alpha" ["b"]="bravo" ["c"]="charlie")

echo "${alphabet[b]}"
alphabet["d"]="${alphabet[d]}bladiebla"
alphabet["d"]="${alphabet[d]}bludojdiebla"
echo "${alphabet[d]}"

someNewElement="somethingElse"

if [[ "${alphabet[a]}" =~ "alpha" ]]; then
   alphabet["a"]="${alphabet[a]}${someNewElement}"
fi

echo "${alphabet[a]}"

if [[ "${alphabet[a]}" =~ "alpha" ]]; then
   alphabet["a"]="${alphabet[a]}${someNewElement}"
fi


echo "${alphabet[a]}"

