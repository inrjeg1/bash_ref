#!/bin/bash

if [[ $# -lt 1 ]]; then
    echo "Please provide an argument"
    exit 1
fi

allArgs=" $@"
currentPath=`pwd`
inBoa=0
inClearCase=0
specialArgs=''
searchArgs="$allArgs"

if [[ $currentPath =~ 'boa_prd' ]]; then
    inBoa=1

elif [[ $currentPath =~ 'vobs/litho' ]]; then
    inClearCase=1
fi

if [[ "$searchArgs" =~ ' -w ' ]]; then
    specialArgs="$specialArgs -w"
    searchArgs=`echo "$searchArgs" | sed 's/ -w//'`
fi
if [[ "$searchArgs" =~ ' -i ' ]]; then
    specialArgs="$specialArgs -i"
    searchArgs=`echo "$searchArgs" | sed 's/ -i//'`
fi
if [[ "$searchArgs" =~ ' -v ' ]]; then
    specialArgs="$specialArgs -v"
    searchArgs=`echo "$searchArgs" | sed 's/ -v//'`
fi
if [[ "$searchArgs" =~ ' -F ' ]]; then
    specialArgs="$specialArgs -F"
    searchArgs=`echo "$searchArgs" | sed 's/ -F//'`
fi
if [[ "$searchArgs" =~ ' -L ' ]]; then
    specialArgs="$specialArgs -L"
    searchArgs=`echo "$searchArgs" | sed 's/ -L//'`
fi


searchArgs=`echo "$searchArgs" | sed 's/^ //'`

nonBoaSearchCommand="find . -name \"*\" -follow | xargs grep -n -s $specialArgs "'"'""$searchArgs""'"'" | grep -v '^Binary file' | sed \"s/:/  /\" | sed \"s/:/  /\" | grep -v '\.o'"

if [[ $inBoa -eq 1 ]]; then
    git grep -n  $specialArgs "$searchArgs" | grep -v '^Binary file' | sed "s/:/  /" | sed "s/:/  /" | grep -v '\.o'

elif [[ $inClearCase -eq 1 ]]; then
    
    if [[ $currentPath == '/vobs/litho' ]]; then
    
        ccList=`ccget_buildscope | cut -d'/' -f2`
        for component in $ccList; do
            echo -e "\n  ===  Searching in $component  ===" 
            
            cd `xcd $component com`
            
            find . -name "*" -follow | xargs grep -n -s $specialArgs "$searchArgs" | grep -v '^Binary file' | sed "s/:/  /" | sed "s/:/  /" | grep -v '\.o' | grep -v '\.contrib'
        done

        cd `xcd /`
    else
        if [[ `ls .` =~ 'xifs' ]]; then
            cd com
        fi
        
        find . -name "*" -follow | xargs grep -n -s $specialArgs "$searchArgs" | grep -v '^Binary file' | sed "s/:/  /" | sed "s/:/  /" | grep -v '\.o' | grep -v '\.contrib'
        cd $currentPath
    fi
else 
    find . -name "*" -follow | xargs grep -n -s $specialArgs "$searchArgs" | grep -v '^Binary file' | sed "s/:/  /" | sed "s/:/  /" | grep -v '\.o'
fi

