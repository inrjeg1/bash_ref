#!/bin/bash

currentDir=$PWD
currentRepo=`/sdev_shared/fc062data/PTAD/scripts/bash/get_current_repository.sh`

viewName=$(cleartool pwv -short)

if [[ $viewName != "** NONE **" ]]; then
    echo "This script needs to be run from a BOA repo"
    exit 1
fi


if [[ $currentDir == $currentRepo ]]; then
    nedit buildDependenciesVersions.gradle &
else
    cd `/sdev_shared/fc062data/PTAD/scripts/bash/get_current_component.sh`
    nedit buildDependencies.gradle &
fi
