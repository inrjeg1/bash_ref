#!/bin/bash

new_dir="new_dir"

function create_new_file {
    cd $new_dir

    echo "Hello World!" > myNewFile.txt

    
}

create_new_file
