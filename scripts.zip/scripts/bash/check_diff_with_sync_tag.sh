#!/bin/bash

IFS=''
cat /home/ptacken/public/tmpd/both_added | while read fileName; do
    
    diffOutput=`git diff v2.1.0-ccpullwk1739-v07-02 $fileName`   

   # echo " ==== $fileName ==== "
   # echo $diffOutput
    
    if [[ ! -z $diffOutput ]]; then
        echo " ==== $fileName ==== "
        echo $diffOutput
        echo ''
    fi
done

