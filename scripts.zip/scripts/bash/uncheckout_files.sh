#!/bin/bash

fileList=`cat /home/ptacken/public/file_list.txt`

for fileName in $fileList; do
    component=`echo $fileName | cut -d'x' -f1`
    echo $component
    
   # cd `xcd $component com ext inc`
   # cleartool unco -rm $fileName

done

