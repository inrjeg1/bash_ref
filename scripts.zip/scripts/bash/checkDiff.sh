#!/bin/bash

d1="./dummy_txt.txt"
d2="./dummy_txt2.txt"

output=`diff $d1 $d2`

if [[ ! -z $output ]]; then
    bcompare $d1 $d2
fi

