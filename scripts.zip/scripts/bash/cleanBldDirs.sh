#!/bin/bash

currentDir=`pwd`
allBldDirs=`find . -mindepth 1 -maxdepth 10 -type l | grep "/bld" | grep -v "pkg"`

for dir in $allBldDirs; do
    echo "=== Cleaning $dir ==="
    rm -rf ${dir}/*
done

