#!/bin/bash

if [[ $# -lt 1 ]]; then
    echo "Usage: $0 <username>"
    exit 1
fi

username=$1

cd /shared/nl011022_u/test_data/TWINRUNR/SYSTEM

alldirs=`find . -mindepth 1 -maxdepth 1 -type d`

for dir in $alldirs; do
    if [[ $dir == "./m"???? ]]; then
        cd $dir
        findResults=`ls -a | grep $username`
        if [[ ! -z $findResults ]]; then
            for result in $findResults; do
                if [[ -d $result ]]; then
                    cd $result
                    if ls *mdl.gz 1> /dev/null 2>&1; then
                        for mdlFile in `ls *mdl.gz`; do
                            echo ${dir}/${result}/${mdlFile}
                        done
                    fi
                    cd ..
                fi
            done
        fi
        cd ..
    fi
done
