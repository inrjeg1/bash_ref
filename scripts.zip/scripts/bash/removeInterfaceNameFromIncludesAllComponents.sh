#!/bin/bash

componentList=`/sdev_shared/fc062data/PTAD/scripts/bash/allComponents.sh`
currentDir=`pwd`

if [[ ! $currentDir =~ "boa_prd" ]]; then
    echo "Not in a BOA repository, exiting now"
    exit 1
fi

for component in $componentList; do

    echo "Removing interface name from include for $component"
    cd `/sdev_shared/fc062data/PTAD/scripts/bash/get_current_repository.sh`
    
    cd ${component}/com/ext/inc/
    /sdev_shared/fc062data/PTAD/scripts/bash/removeInterfaceNameFromIncludes.sh
    
    cd ../lib/
    /sdev_shared/fc062data/PTAD/scripts/bash/removeInterfaceNameFromIncludes.sh
    
done
