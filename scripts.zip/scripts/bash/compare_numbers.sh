#!/bin/bash

a=2
if [[ $a -gt 1 ]]; then
    echo "$a is greater than 1"
else
    echo "$a is not greater than 1"
fi

