#!/bin/bash


a=''
b="_txt_"

a="${b}${a}"

echo $a

a="${b}${a}"

echo $a


if [[ ! $a =~ "__txt_" ]]; then
    echo "NOT FOUND"

fi
