#!/bin/bash

username=`whoami`

if [[ $# -gt 0 ]]; then
    username=$1
fi

cd /shared/nl011022_u/test_data/TWINRUNR/FGT

alldirs=`find . -mindepth 1 -maxdepth 1 -type d`

for dir in $alldirs; do
    if [[ $dir == "./m"???? ]]; then
        cd $dir
        findResults=`ls -a | grep $username`
        if [[ ! -z $findResults ]]; then
            for result in $findResults; do
                echo "${dir}/${result}/result.html"
            done
        fi
        cd ..
    fi
done
