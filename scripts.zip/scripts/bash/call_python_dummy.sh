#!/bin/bash


python -c "\
import sys;\
sys.path.insert(0, '../jenkins-tooling');\
import qualityChecks; \
print qualityChecks.executeCheckLibRef"

