#!/bin/bash

component="kvliwc"

if ! (cd new_dir; dummy_script.sh 3); then
   echo -e "  ===== Running local tests for ${component} =====\n"
else
   echo "PASSED"
fi



