#!/bin/bash

#inputText=$1
#filteredText=`echo $inputText | cut -d' ' -f2-`
#git blame $filteredText | awk -F ' 2' '{print 2$2}' | sort

inputText=$1
filteredText=`echo $inputText | cut -d' ' -f2-`
git blame -e $filteredText | awk -F '>' '{print $2$1">"}' | sort
