#!/bin/bash

awk '{print $argv, $argv}'
