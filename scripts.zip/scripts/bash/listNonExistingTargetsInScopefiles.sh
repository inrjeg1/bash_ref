#!/bin/bash

viewName=$(cleartool pwv -short)

if [[ $viewName == "** NONE **" ]]; then
    echo "This script needs to be executed from a Clearcase view"
    exit 1
fi

if [[ $# -lt 1 ]]; then
    echo "Scopefile is needed as argument (Pass 'all' to check all scopefiles in the buildscope)"
    exit 1
elif [[ $1 == "all" ]]; then
    echo "=== all --> Checking all scopefiles ==="
    allScopefiles=`/sdev_shared/fc062data/PTAD/scripts/bash/getAllScopefilesInBuildscope.sh`
else
    allScopefiles=$1
fi



currentDir=`pwd`
NotExistingFilesFound=0

function checkIfFileIsInMakefile()
{
    search_word=`basename $1`
    full_path=$2

    searchResult=`find . -name "makefile*" | xargs grep $search_word`
    
    if [[ -z $searchResult ]]; then
        echo "   === NOT FOUND: $full_path ==="
        NotExistingFilesFound=1
    fi
}

function checkIfFileExists()
{
    full_path=$1
    search_word=`basename $1`

    searchResult=`find . | grep $search_word`

    if [[ -z $searchResult ]]; then
        echo "   === NOT FOUND: $full_path ==="
        NotExistingFilesFound=1
    fi
}

exceptionList="\
.pyc\
"

function listNotExistingFilesForScopefile()
{
    while read line; do

        if [[ $line == "interface "*  ]]; then
            currentScope="interface"
            interfaceName=`echo $line | rev | cut -d' ' -f1 | rev`
            componentName=`/sdev_shared/fc062data/PTAD/scripts/bash/getComponent.sh $interfaceName`

            echo "checking $line"

        elif [[ $line =~ "component " || $line =~ "building_block" ]]; then
           currentScope="component"

        elif [[ $line =~ "contains" ]]; then

            if [[ $currentScope != "component" ]]; then

                fileName=`echo $line | rev | cut -d' ' -f1 | rev`
                
                inExceptionList=0
                for exception in $exceptionList; do
                    if [[ $fileName =~ $exception ]]; then
                        inExceptionList=1
                        break
                    fi
                done
                if [[ $inExceptionList -eq 1 ]]; then
                    continue
                fi

                cd `xcd $componentName com`

                search_word=`basename $fileName`

                if [[ $line =~ "/bld" ]]; then
                    checkIfFileIsInMakefile $search_word $fileName

                else
                    searchResult=`find . | grep $search_word`
                    checkIfFileExists $fileName
                fi

                cd $currentDir
            fi
        fi
    done <`echo $1`
}

for scopefile in $allScopefiles; do
    listNotExistingFilesForScopefile $scopefile
done


if [[ $NotExistingFilesFound -eq 1 ]]; then
    echo "To remove files from scopefiles:"
    echo "sed -i '@<filename>@d' $1"
fi
