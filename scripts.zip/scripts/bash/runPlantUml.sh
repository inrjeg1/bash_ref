#!/bin/bash

function runPlantUml
{
    fileName=$1

    imageName=`cat $fileName | head -1 | cut -d' ' -f2 | cut -d'.' -f1`
    java -jar /home/ptacken/Userdata/PlantUml/plantuml.jar $fileName
    eog "./${imageName}.png" &
}

runPlantUml $1
