#!/bin/bash

myString="alpha bravo charlie delta echo foxtrott golf hotel"

myString2="${myString// //}"

echo $myString2


