#!/bin/bash

cd /vobs/litho/xifs
mv LZLAxSCAN LZLAxSCAN_old
mkdir LZLAxSCAN
cd LZLAxSCAN
cp -r /view/jkrielen_at6.3_dumbo_LS_no_orion_int/vobs/litho/xifs/LZLAxSCAN/* .
cd ..
mv LZDRxSCAN LZDRxSCAN_old
mkdir LZDRxSCAN
cd LZDRxSCAN
cp -r /view/jkrielen_at6.3_dumbo_LS_no_orion_int/vobs/litho/xifs/LZDRxSCAN/* .
cd ..
