#!/bin/bash

viewName=$(cleartool pwv -short)

if [[ $viewName == "** NONE **" ]]; then
    echo "This script needs to be run from a Clearcase view"
    exit 1
fi

allCheckedOutFiles=`cleartool lsco -avobs -cview -s`

for file in $allCheckedOutFiles; do

    diffOutput=`cleartool diff -pred $file`
    if [[ $diffOutput == "Files are identical" ]]; then
        echo "File $file is identical to predecessor, performing uncheckout"
        cleartool uncheckout -rm $file
    elif [[ $diffOutput == "Directories are identical" ]]; then
        echo "Directory $file is identical to predecessor, performing uncheckout"
        cleartool uncheckout -rm $file
    fi

done


