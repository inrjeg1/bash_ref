#!/bin/bash

failed=1

echo "FAIL"

exit $failed

