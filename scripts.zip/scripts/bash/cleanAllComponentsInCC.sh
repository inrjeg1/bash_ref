#!/bin/bash

ccList=`ccget_buildscope | cut -d'/' -f2`
bbList=''

for component in $ccList; do
    echo -e "\n  ===  Cleaning component $component  ===" 

    cd `xcd $component`
    
    ccmake clean all
    
    /sdev_shared/fc062data/PTAD/scripts/bash/cleanBldDirs.sh
    
    cd ..
    
    currentDir=`pwd`
    echo -e "\n  ===  Building block to clean: $currentDir  ==="
    
    if [[ ! $bbList =~ $currentDir ]]; then
        echo "Cleaning building block..."
        
        ccmake clean all
        
        bbList="${currentDir}${bbList}"
    else
        echo "Building block already cleaned"
    fi
    
done
