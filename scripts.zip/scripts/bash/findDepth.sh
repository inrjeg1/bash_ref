#!/bin/bash

currentRepo=`/sdev_shared/fc062data/PTAD/scripts/bash/get_current_repository.sh`
viewName=$(cleartool pwv -short)

## TOO SLOW
#if [[ $currentRepo != "None" ]]; then
#    allComponents=`/sdev_shared/fc062data/PTAD/scripts/bash/allComponents.sh | tr '\n' '@'`
#elif [[ $viewName != "** NONE **" ]]; then
#    allComponents=`ccget_buildscope | cut -d'/' -f2`
#fi

allComponents=`/sdev_shared/fc062data/PTAD/scripts/bash/allComponents.sh | tr '\n' '@'`

currentDir=`pwd`
depthFound=0

for depth in {1..20..1}; do
    dirName=`echo $currentDir | rev | cut -d'/' -f${depth} | rev`
    
    if [[ ( ! -z $dirName ) && \
          ( $allComponents =~ $dirName ) ]]; then
        echo $depth
        depthFound=1
        break
    fi
done

if [[ $depthFound -eq 0 ]]; then
    echo 0
fi
