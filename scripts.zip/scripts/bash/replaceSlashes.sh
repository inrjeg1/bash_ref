#!/bin/bash

dummyFile='dummy_txt.txt'


a='a/b/c/d'


b=`echo $a | sed 's@/@\\\/@g'`
echo $a
echo $b

sed -i '/$b/d' $dummyFile




