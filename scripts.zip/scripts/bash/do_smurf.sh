#!/bin/bash

echo -e '\033[0;34mSMURFING...\033[m'

shopt -s expand_aliases

alias ccd='cd `xcd !*`'
alias ct='cleartool'
alias C='/sdev_shared/fc062data/PTAD/scripts/bash/compare_to_clearcase.sh'
alias C2='/sdev_shared/fc062data/PTAD/scripts/bash/compare_to_clearcase2.sh'
alias dif='/sdev_shared/fc062data/PTAD/scripts/bash/dif_clearcase.sh'
alias cb='/sdev_shared/fc062data/PTAD/scripts/bash/compare_to_boa.sh'
alias n='/sdev_shared/fc062data/PTAD/scripts/tcsh/nedit_files'
alias dif_view3='/sdev_shared/fc062data/PTAD/scripts/tcsh/diff_with_view3'
alias findg='/sdev_shared/fc062data/PTAD/scripts/bash/find_grep.sh'
alias findf='find . | grep'
alias findm='/sdev_shared/fc062data/PTAD/scripts/tcsh/find_grep_select_file makefile'
alias gdot='git difftooltooltool origin/master'
alias gcom='git checkout origin/master --'
alias f='ls -a | grep'
alias co='git checkout'
alias gdot='git difftool origin/master'
alias gdt='git difftool'
alias dif_view='/sdev_shared/fc062data/PTAD/scripts/tcsh/diff_with_view'
alias vt='cleartool lsvtree -graphical'
alias uploadFilesToCodeCollaborator='/sdev_shared/fc062data/PTAD/scripts/bash/addFilesToCcollabWithVersions.sh'

alias lib='cd `/sdev_shared/fc062data/PTAD/scripts/bash/get_current_component.sh`; cd com/ext/lib'
alias tst='cd `/sdev_shared/fc062data/PTAD/scripts/bash/get_current_component.sh`; cd com/int/tst'
alias blamesort='/sdev_shared/fc062data/PTAD/scripts/bash/blamesort.sh'
alias get_all_scopefiles='/sdev_shared/fc062data/PTAD/scripts/bash/getAllScopefilesInBuildscope.sh'

#########################################################


for scopefile in `get_all_scopefiles`; do
    #echo "S: $scopefile"
    output=`cat $scopefile | grep -n VELIRFxBOOSTxNSLIB`
    if [[ ! -z $output ]]; then
        echo "S: $scopefiles"
    fi
done

