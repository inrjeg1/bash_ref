#!/bin/bash

echo $pyBinding
