#!/bin/bash

currentDir=`pwd`

previousDir=''

for depth in {1..20..1}; do
    dirName=`echo $currentDir | rev | cut -d'/' -f${depth} | rev`
    if [[ ! -z $dirName  ]]; then
        searchResult=`find . -mindepth 1 -maxdepth 1 -type d | cut -d'/' -f2 | grep -w com`
        if [[ $searchResult == "com" ]]; then
            basename $PWD
            break
        elif [[ $previousDir == "com" ]]; then
            echo $dirName
            break
        fi
        previousDir=$dirName
    fi
done
