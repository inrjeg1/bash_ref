<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="en">


<body>

 <!-- === DELIVERY CHECKS ======================================================================= //-->
                <h4>Delivery Checks</h4>
                <pre><font color="#990000"><b>CWBD not executed!</b></font> fi_mk_bl quick mode is used, "cwbd_adm info" results:<br /><b>Toolrun ID Version Toolrun start       Toolrun stop        Status      W D Tool name
========== ======= =================== =================== =========== = = ==============================</b>
  23917661 0.6     2020-02-10 18:38:07 2020-02-10 18:38:07 <font color="#990000">UNRESOLVED</font>      LO_FC_LOat_Confidence
  23906779 0.5     2020-02-10 13:33:59 2020-02-10 13:33:59 UNTESTED        LO_FC_LOat_Smoke
  23917607 0.2     2020-02-10 18:37:56 2020-02-10 18:38:03 <font color="#990000">UNRESOLVED</font>      TICP_SY_datplus_test_NXE
  23917610 0.2     2020-02-10 18:38:03 2020-02-10 18:38:06 <font color="#990000">UNRESOLVED</font>      TICP_SY_datplus_test_NXT
  23917664 0.7     2020-02-10 18:38:08 2020-02-10 18:38:11 <font color="#990000">FAIL</font>            change_reviews
  23917669 0.5     2020-02-10 18:38:13 2020-02-10 18:38:13 <font color="#990000">FAIL</font>            changes_implemented
  23917667 0.3     2020-02-10 18:38:11 2020-02-10 18:38:11 <font color="#009900">PASS</font>            check_baselined
  23906867 0.3     2020-02-10 13:36:30 2020-02-10 13:36:32 <font color="#009900">PASS</font>            check_depint
  23906954 0.7     2020-02-10 13:37:09 2020-02-10 13:37:12 <font color="#009900">PASS</font>            check_leafdirs
  23907816 0.3     2020-02-10 13:37:12 2020-02-10 14:07:03 <font color="#009900">PASS</font>            check_libref
  23906770 0.2     2020-02-10 13:32:23 2020-02-10 13:32:23 UNTESTED        check_sqr
  23654233 0.1     2020-01-23 17:17:40 2020-01-23 17:17:40 <font color="#009900">PASS</font>            check_vp_interface
  23654180 0.3     2020-01-23 17:12:01 2020-01-23 17:12:10 <font color="#009900">PASS</font>            check_xGN
  23906781 0.6     2020-02-10 13:33:59 2020-02-10 13:33:59 UNTESTED        check_xlinks
  23906945 0.3     2020-02-10 13:36:33 2020-02-10 13:37:08 <font color="#009900">PASS</font>            clone_check
  23906855 0.1     2020-02-10 13:35:50 2020-02-10 13:36:29 <font color="#009900">PASS</font>            forgotten_mkelems
  23906863 0.1     2020-02-10 13:36:29 2020-02-10 13:36:30 <font color="#009900">PASS</font>            full_build
  23906777 0.1     2020-02-10 13:33:57 2020-02-10 13:33:57 UNTESTED        lost_and_found
  23906775 0.4     2020-02-10 13:33:57 2020-02-10 13:33:57 UNTESTED        maction_check
  23906952 0.3     2020-02-10 13:37:08 2020-02-10 13:37:09 <font color="#009900">PASS</font>            makefile_check
  23917659 0.1     2020-02-10 18:38:06 2020-02-10 18:38:06 <font color="#990000">UNRESOLVED</font>      metro_predelivery_test
  23906870 0.4     2020-02-10 13:36:32 2020-02-10 13:36:33 <font color="#009900">PASS</font>            pkg_contents_export_check
  23906841 0.5     2020-02-10 13:34:41 2020-02-10 13:35:50 <font color="#009900">PASS</font>            scope_control
  23911967 3.1     2020-02-10 14:07:04 2020-02-10 15:31:44 <font color="#990000">UNRESOLVED</font>      tics
  23917605 0.5     2020-02-10 15:31:45 2020-02-10 18:37:55 <font color="#990000">UNRESOLVED</font>      tics_gcc_8
  23906783 0.3     2020-02-10 13:33:59 2020-02-10 13:33:59 UNTESTED        validate_xsd
  23906766 0.4     2020-02-10 13:31:52 2020-02-10 13:31:52 UNTESTED        xcdrc_map
         0 0.0     2020-02-11 14:36:29                     <font color="#990000">FAIL</font>            FINAL VERDICT                 

Last cwbd testrun finished on 2020-02-10 18:38:13 was FULL
</pre>
</body>
</html>

