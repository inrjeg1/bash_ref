#include <iostream>
#include <boost/shared_ptr.hpp>

class Bottom
{
public:
   class Delegate
   {
   public: 
      virtual void onSucces() const = 0;
      virtual void onFailure() const = 0;
   };

   Bottom(Delegate& delegate_)
   : delegate(delegate_)
   {}

   void request()
   {
      std::cout << "Request of Bottom is called" << std::endl;
   }

   virtual void onSucces() const
   {
      delegate.onSucces();
   }

   virtual void onFailure() const
   {
      delegate.onFailure();
   }

private:
   Delegate& delegate;   
};

class Top : public Bottom::Delegate
{
public:
   Top()
      : bottom(Bottom(*this))
   {}

   void request()
   {
      std::cout << "Request of top called" << std::endl;
      bottom.request();
   }

   void onSucces() const
   {
      std::cout << "Hoera on success" << std::endl;
   }

   void onFailure() const
   {
      std::cout << "Fout" << std::endl;
   }

public:
   Bottom bottom;   

};

int main()
{
   Top top;
   top.request();

   top.bottom.onSucces();
   top.bottom.onFailure();


   return 0;
}

