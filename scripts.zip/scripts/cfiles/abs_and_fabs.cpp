#include <iostream>
#include <cmath>


int main()
{
    double a = 0.021830281;
    double b = 0.021830282;

    if (std::abs(a - b) > 0.000000000001)
    {
        std::cout << "TRUE\n";
    }
    else
    {
        std::cout << "FALSE\n";
    }
    
    if (std::abs(b - a) > 0.000000000001)
    {
        std::cout << "TRUE\n";
    }
    else
    {
        std::cout << "FALSE\n";
    } 

    return 0;
}

