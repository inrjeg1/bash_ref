#include <iostream>


/* NOT WORKING! */

void myFunction(int ***someArray)
{
    
    int intArray[7] = {1, 3, 5, 7, 9};
    *someArray = intArray;

}



int main()
{
    int *someArray;

    myFunction((int***) &someArray);

    std::cout << someArray[0] << std::endl;
    
    return 0;
}
