#include <iostream>

class A
{
public:
virtual void a() = 0;

};


class B : public A
{
public:
void a(){std::cout << "B" << std::endl;}
};


class C : public B
{
public:
void a(){std::cout << "C" << std::endl;}
};

int main()
{
    A* a = new C();
    a->a();
    
    return 0;
}

