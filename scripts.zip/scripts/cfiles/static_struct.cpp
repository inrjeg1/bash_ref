#include <iostream>


typedef struct
{
    double a;
} someStruct;


int main()
{
    someStruct s;
    someStruct t;
    
    t.a = 8.3947;
    s = t;
    std::cout << s.a << std::endl;
        
    return 0;
}
