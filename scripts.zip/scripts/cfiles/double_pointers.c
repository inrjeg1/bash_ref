#include <stdio.h>

double global_d = 3.14159265358979;

void fill_double_pointer(double **double_pointer_x,
                         double **double_pointer_y)
{
    double local_d = 1.77245385;

    *double_pointer_x = &local_d;
    *double_pointer_y = &global_d;
}

void do_other_stuff()
{
    double e = 1.34739749;
    double f = 2.93749374;
    double g = 3.9375937;
    double h = 4.9374937;
    double i = 35.93874397;
    double j = 6.0483075;
    double k = 7.964975403;
}

int main()
{
    double *double_p_x = NULL;
    double *double_p_y = NULL;
      
    fill_double_pointer(&double_p_x, &double_p_y);
    do_other_stuff();
    
    printf("LOCAL: %f\nGLOBAL: %f\n", *double_p_x, *double_p_y);

    return 0;
}
