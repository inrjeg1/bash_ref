#include <stdio.h>


typedef enum
{
    BLUE,
    RED,
    GREEN
} Color;


void printColor()
{
    Color c = GREEN;
    printf("%d\n", (int)c);

}

int main()
{
    printColor();
    return 0;
}




