#include <boost/shared_ptr.hpp>

class SimpleAlgo
{
public:
    virtual int computeRandomNumber(int arbitraryInt) const = 0;
};

typedef boost::shared_ptr<SimpleAlgo> SimpleAlgoPtr;

