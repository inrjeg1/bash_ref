#include <iostream>

using namespace std;

template <typename T>
T multiplyStuff(T a, T b)
{
    return a * b;
}

template <typename T>
class TemplateClass
{
public:
    TemplateClass(T a_, T b_) 
    : a(a_), b(b_) {}

    T getMax()
    {
        return a > b? a : b;
    }

private:
    T a;
    T b;
};


template <>
class TemplateClass <double>
{
public:
    TemplateClass(double a_, double b_)
    : a(a_), b(b_) {}
    
    double getMin()
    {
        return a < b? a : b;
    }
    
private:
    double a;
    double b;
};


int main()
{
    int a = 5;
    int b = 6;
    TemplateClass<int> t1(a, b);
    cout << t1.getMax() << endl;
    
    double c = 1.5;
    double d = 3.0;
    TemplateClass<double> t2(c, d);
    cout << t2.getMin() << endl;

    TemplateClass<float> t3(c, d);
    cout << t3.getMax() << endl;
    

    return 0;
}


