#include <iostream>

using namespace std;

void passDoublePointer(int **double_pointer)
{
    **double_pointer += 1;
}

void testAssignment()
{
    int a = 9;

    int* p;
    *p = 4;
    
    int** pp = &p;
    cout << **pp << endl;

    passDoublePointer(pp);
    cout << **pp << endl;
}

void checkIfNull(int **double_pointer)
{
    if(double_pointer == NULL)
    {
        cout << "It's NULL\n";
    }
    else
    {
        cout << "NOT NULL\n";
    }

}

void testNull()
{
    int **pp = NULL;
    checkIfNull(pp);
    
    int* p;
    *p = 10;
    
 //   pp = &p;
    
  //  checkIfNull(pp);
}


int main()
{   
  //  testAssignment();
    testNull();    

    return 0;
}

