#include <iostream>

using namespace std;

void functionWithStatic()
{
    static int a = 0;
    
    a += 1;
    
    cout << a << endl;
}


int main()
{
    functionWithStatic();
    functionWithStatic();

    return 0;
}
