#include <iostream>
#include <vector>

using namespace std;


void createVectorOfVectorsWithSetLength()
{
   vector<vector<int> > a(0, vector<int>(30));

   vector<int> b;
   b.push_back(12);
   b.pu
   

   //cout << a[15] << endl;

}

void createVectorWithDifferentTypes()
{
 /*   std::vector<double> v1;
    v1.push_back(3.14);
    v1.push_back(1.59);
    
    cout << "v1 " << v1[1] << endl;
 */

   // std::vector<int, float> v2;
}


int main()
{
 //   std::vector<int> v;
 //   cout << "v " << v.size() << endl;

    //createVectorWithDifferentTypes();

   createVectorOfVectorsWithSetLength();

    return 0;
}
