#include <iostream>

using namespace std;

void checkAuke()
{
    void **cc = NULL;
    void ***ccc = &cc;

    int one = 1;
    int two = 2;
    int three = 3;

    int* values[] = {&one, &two, &three};

    cout << "values: " << values << endl;
    cout << "values[1]: " << values[1] << endl;
    cout << "*values[1]: " << *values[1] << endl;

    void* values_void[] = {static_cast<void*>(values[0]),
                         static_cast<void*>(values[1]),
                         static_cast<void*>(values[2])};

    void** void_pp = static_cast<void**>(values_void);

    *ccc = void_pp;

    int secondRetrieved = *(static_cast<int*>(cc[1]));
    cout << "First retrieved: " << *(static_cast<int*>(cc[0])) << endl;
    cout << "Second retrieved: " << secondRetrieved << endl;
    cout << "Third retrieved: " << *(static_cast<int*>(cc[2])) << endl;
}

typedef struct
{
    int* array;
} IntStruct;

void myCheck()
{
    IntStruct intStruct;
   // intStruct.array = new int[5];

    int *array;
    array = new int[5];
    array[3] = 4;
    
    intStruct.array = array;
    
    cout << intStruct.array[3] << endl;

}

int main()
{
    //myCheck();
   checkAuke();

    return 0;
}
