#include <iostream>
#include <boost/make_shared.hpp>
#include "classForTutorial.hpp"

class SimpleAlgoImpl : public SimpleAlgo
{
public:
    int computeRandomNumber(int arbitraryInt) const
    {
        return arbitraryInt * arbitraryInt;
    }
};

int main()
{
    SimpleAlgoPtr c = boost::make_shared<SimpleAlgoImpl>();
    std::cout << c->computeRandomNumber(25) << std::endl;

    return 0;
}

