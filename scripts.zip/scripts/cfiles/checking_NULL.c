#include <stdio.h>

void check_for_NULL(int *pointer)
{
    if (!pointer)
    {
        if (NULL == pointer)
        {
            printf("pointer is NULL\n");
        }
    }
    else
    {
        if (NULL != pointer)
        {
            printf("pointer is NOT NULL\n");
        }
    }
}

int main()
{
    int *a = NULL;
    check_for_NULL(a);
    int b = 0;
    a = &b;
    check_for_NULL(a);

    return 0;
}
