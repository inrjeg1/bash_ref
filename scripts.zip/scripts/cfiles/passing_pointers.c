#include <stdio.h>


void funcA(int *a, int *b)
{
    *a = 1;
    *b = 2;
    
    printf("a: %d\nb: %d\n", *a, *b);
}


int main(void)
{
    int a =0;
    int b =0;

    funcA(&a, &b);
    
    printf("A: %d\nB: %d\n", a, b);

    return 0;

}
