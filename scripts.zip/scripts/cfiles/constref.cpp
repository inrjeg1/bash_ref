#include <iostream>

using namespace std;

struct StructA
{
    StructA(int a_)
    : a(&a_)
    {}
    
    int* a;
};

StructA changeConstRef(const StructA& someStruct)
{
    *someStruct.a = 6;
    
    return someStruct;
}

int main()
{
    StructA structA(5);
    
    StructA structB = changeConstRef(structA);

    cout << *structA.a << endl;
}





