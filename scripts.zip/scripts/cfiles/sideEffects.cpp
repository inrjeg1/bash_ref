#include <iostream>

using namespace std;

int main()
{
    unsigned int a = 0U;
    unsigned int b = 3U;
    unsigned int c = 4U;
 
    a = (b, 0U, c);
    
    cout << a << " " << b << endl;
    
    return 0;
}
