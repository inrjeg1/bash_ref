#include <iostream>
#include <string.h>

using namespace std;

void printString(string myString)
{
    cout << myString << endl;
}


void concatenateStrings()
{
    string someString = "ABC DEFG";
    printString(someString + " XYZ");
}


int main()
{
    concatenateStrings();
    return 0;
}
