#include <boost/shared_ptr.hpp>
#include <boost/make_shared.hpp>

#include <iostream>

using namespace std;

class A
{
public:
    A(int a_)
    : a(a_) 
    {}

    int getA()
    {
        return a;
    }
    
    void setA(int newA)
    {
        a = newA;
    }

private:
    int a;
};


class B
{
public:
    B(boost::shared_ptr<A> AObject_)
    {
       AObject = boost::make_shared<A>(AObject_->getA());
    }

    boost::shared_ptr<A> AObject;
};


class C
{
public:
    C(boost::shared_ptr<A> AObject_)
    : AObject(AObject_)
    {}

    boost::shared_ptr<A> AObject;
};


int main()
{
    //A
    boost::shared_ptr<A> a1 = boost::make_shared<A>(9);
    boost::shared_ptr<A> a2 = a1;
    
    a2->setA(10);
    cout << a1->getA() << endl;
    
    //B
    boost::shared_ptr<B> b1 = boost::make_shared<B>(a1);
    cout << b1->AObject->getA() << endl;
    a1->setA(11);
    cout << b1->AObject->getA() << endl;
    
    // C
    boost::shared_ptr<C> c1 = boost::make_shared<C>(a1);
    cout << c1->AObject->getA() << endl;
    a1->setA(12);
    cout << c1->AObject->getA() << endl;

    return 0;
}

