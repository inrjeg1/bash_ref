

class Alpha
{
public:
    Alpha(int someVar);
   
    void printVar();
    
    
private:
    const int variableAlpha;
};

