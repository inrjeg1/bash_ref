#include <iostream>
#include "constructorInitialization.hpp"


using namespace std;

Alpha::Alpha(int someVar)
    : variableAlpha(someVar)
{
    
}

void Alpha::printVar()
{
    cout << "Value: " << variableAlpha << endl;
}


int main()
{
    Alpha alpha(8);// = Alpha(8);
    alpha.printVar();
    
    return 0;
}

