#include <stdio.h>


int receiving_array(int some_array[])
{
   some_array[1] = 8;

   return 0;
}


int main()
{
   int some_array[3] = {0};
   
   receiving_array(some_array);

   printf("Array1: %d\nArray2: %d\n" , some_array[0], some_array[1]);

   return 0;
}

