#include <iostream>

using namespace std;

int main()
{   
    cout << sizeof(void*) << endl;

    return 0;
}

