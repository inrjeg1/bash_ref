#include <iostream>

using namespace std;


void func_a(bool equal_numbers)
{
   cout << "EQAL: " << equal_numbers << endl;
}

int main()
{
   int a = 1;
   int b = 2;
   int c = 2;
   
   func_a(a==c);
   
   return 0;   
}
