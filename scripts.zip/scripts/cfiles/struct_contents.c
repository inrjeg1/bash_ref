//#include <iostream>
#include <stdio.h>
//using namespace std;


typedef struct {
   double b_double;
   int b_int;
   double b_array[10];
} B;

typedef struct {
   B b;
   double a_double;
} A;


int main()
{
   A a = {0};
   a.b.b_array[7] = 2;
   B copy = a.b;
   a.b.b_array[7] = 5.3;
   
   
   printf("%f \n", a.b.b_array[7]);
   //cout << "Fifth element: " << a.b.b_array[7] << endl;
    printf("%f \n", copy.b_array[7]);
   //cout << "Fifth element: " << copy.b_array[7] << endl;

   return 0;
}
