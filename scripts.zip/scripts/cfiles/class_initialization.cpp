#include <iostream>

using namespace std;

class A
{
public:
    A(int i)
    {
        cout << "i: " << i << endl;
    }

};


int main()
{
    A a(4);
    
    return 0;
}

