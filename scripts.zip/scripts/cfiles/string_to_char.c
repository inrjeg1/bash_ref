#include <stdio.h>


int print_chars(char* char_string)
{
   printf("String: %s\n", char_string);

   return 0;
}


int main()
{
   char *some_string = "CHAR_STRING";
   print_chars(some_string);

   return 0;
}
