#include <iostream>

using namespace std;

class B
{
public:
    int getNumber()
    {
        return 15;
    }
};

class A
{
public:
    A()
    {
        myNumber = getNumberFromB();
    }

    void showNumber()
    {
        cout << "myNumber " << myNumber << endl;    
    }

private:
    int myNumber;

    int getNumberFromB()
    {
        B b;
        return b.getNumber();  
    }
};


int main()
{
    A a;
    a.showNumber();
    
    return 0;
}
