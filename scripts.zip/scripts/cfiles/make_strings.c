#include <string.h>
#include <stdio.h>


void function_with_string(char *string_val)
{
    string_val = "AWESOME!";
}


int main()
{
/*   char chars_digits[100] = "\0";
   char digits[100];
   int is_true = 12;
 
   sprintf(digits, "%d", is_true);  
   strcat(chars_digits, "chars");
   strcat(chars_digits, " "); 
   strcat(chars_digits, digits);
    
   printf("%s\n", chars_digits);
*/

   char *some_string = malloc(256 * sizeof(char));
   
   function_with_string(some_string);
   
   printf("%s\n", some_string);
   
   
   return 0;
}
