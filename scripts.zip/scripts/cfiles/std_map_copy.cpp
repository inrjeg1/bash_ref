#include <iostream>
#include "boost/unordered_map.hpp"
#include <string.h>

using namespace std;

typedef boost::unordered_map<string, double> Map;

int main()
{
    Map map1, map2, map3;
    
    map1["a"] = 1.5;
    map1["b"] = 2.5;
    map1["c"] = 3.5;

    map3["d"] = 7.5;

    map2.insert(map1.begin(), map1.end());
    
    cout << map2["a"] << endl << map2["b"] << endl << map2["c"] << endl << endl;
    
    map2.clear();
    map2.insert(map3.begin(), map3.end());
    
    cout << map2["a"] << endl << map2["b"] << endl << map2["c"] << endl << map2["d"] << endl;

    return 0;
    
    
}
