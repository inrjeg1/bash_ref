#include <iostream>

using namespace std;

class A
{
public:
    A(){}
    void operator() (int number)
    {
        cout << "number: " << number << endl;
    }
};

void callFunctor(A& a)
{
    a(8);
}

int main()
{
    A myclass;
    
    callFunctor(myclass);

    return 0;
}
