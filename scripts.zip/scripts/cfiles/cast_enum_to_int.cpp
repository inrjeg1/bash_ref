#include <iostream>

using namespace std;

typedef enum
{
    char_a,
    char_b
} enum_A;

typedef enum
{
    alpha,
    beta
} enum_B;

int main()
{
    enum_A a;
    enum_B b;
    
    a = char_b;
    b = beta;
    
    if ( static_cast<int>(a) == static_cast<int>(b))
    {
        cout << "EQUAL\n";
    }

    return 0;
}
