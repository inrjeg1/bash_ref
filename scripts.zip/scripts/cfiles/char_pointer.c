#include <stdio.h>



void func_a(char *a)
{
   printf("char a: %s\n", a);

}


void func_b(const char b[10])
{
   printf("char b: %s\n", b);
}

void end_character()
{
   char a[2] = "";
   int i = 0;  
   
   
   for(i=0; a[i] == '\0'; i++)
   {
      printf("%c  %d\n", a[i], (int)a[i]);
   }

}


int main()
{
/*   char *c = "small";
   char *d = "veryverylarge";
   
   func_a(d);
   func_b(d); */
   
/*   end_character(); */

   double a = 12345678;
   
   double b = 1e-9 * a;
   double c = a / 1E9;
   
   printf("b: %f\nc: %f\n", b,c);
   

   

   return 0;
}
