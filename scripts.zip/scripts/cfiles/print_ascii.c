#include <stdio.h>

int main()
{
   int i = 0;
   
   for (i =0; i< 255; i++)
   {
      printf("%d\t%c\n", i, i);
   }
   return 0;
}
