#include <iostream>

using namespace std;


typedef struct {
   bool b_bool;
   double b_double;
   int b_int;
   double b_array[10];
} B;

typedef struct {
   B b;
   double a_double;
} A;




int main()
{
   A a;
 /*  a.a_double = 9.343;
  
   for(int i=0; i< 10; i++)
   {
      a.b.b_array[i] = i + 3.14159265358979323846264338327950288419716939937510;
   }
   */
   a = {0};
   a.b.b_array[7] = 2;
   B copy = a.b;
   a.b.b_array[7] = 4.45;
   

   

   return 0;
}
