#include <stdio.h>

int return_true()
{
   return (1 == 1);
}

int return_false()
{
   return (1 != 1);
}

int main()
{
   int val_true = return_true();
   int val_false = return_false();

   printf("True: %d\nFalse: %d\n", val_true, val_false);

   return 0;
}


