#include <iostream>
#include <cmath>

using namespace std;


void compareDoubles(double a, double b)
{
    double epsilon = 1.0e-25;

    if (abs(a - b) < epsilon)
    {
        cout << "equal\n";
    }
    else
    {
        cout << "NOT equal\n";
    }
}


int main()
{
    double a = 12;
    double b = 6;
    double c = 3;
    double d = 2;
    
    double f = a / b;
    int g = 1;
    
    double h = (double)(f - g);
    
    compareDoubles(h, d - g);
        
    return 0;
}
