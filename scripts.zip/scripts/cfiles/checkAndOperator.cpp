#include <iostream>

using namespace std;

int main()
{
    bool a = true;
    bool b = false;
    bool c = true;
    
    cout << "A: " << a << endl;
    
    a &= c;
    cout << "A: " << a << endl;
    
    a &= b;
    cout << "A: " << a << endl;
    
    
    return 0;
}
    
