#include <iostream>

struct X{};
struct Y{};
struct Z{};

template <typename T>
void print(const T& input)
{
   std::cout << "hallo" << std::endl;
}

template <>
void print<X>(const X& input)
{
   std::cout << "hallo2" << std::endl;
}

template <>
void print<Y>(const Y& input)
{
   std::cout << "hallo3" << std::endl;
}

class Example
{
public:
   template <typename T>
   static void print(const T& data)
   {
      std::cout << "hallo" << std::endl;
   }
};

template <>
void Example::print<X>(const X& data)
{
   std::cout << "hallo2" << std::endl;
}

template <>
void Example::print<Y>(const Y& data)
{
   std::cout << "hallo3" << std::endl;
}


struct WCS{};


template <typename Direction>
class Quantity
{
public:
   double x;
   double y;
};

template <typename Direction>
class VectorComponent
{
public:
   double x;
   double y;
};

template <template <typename> class T = void>
class XYVector
{
public:
   XYVector(){}

   XYVector(double x_, double y_) : x(x_), y(y_)
   {}

   double getDistance()
   {
      return x * x + y * y;
   }

private:
   double x;
   double y;
};


template<>
class XYVector<VectorComponent>
{
public:
   XYVector(){}

   XYVector(
      const VectorComponent<X>& x_,
      const VectorComponent<Y>& y_)
   : x(x_), y(y_)
   {}

   double getDistance()
   {
      return 0;
   }

private:
   VectorComponent<X> x;
   VectorComponent<Y> y;
};

template<>
class XYVector<Quantity>
{
public:
   XYVector(){}

   XYVector(
      const Quantity<X>& x_,
      const Quantity<Y>& y_)
   : x(x_), y(y_)
   {}

   double getDistance()
   {
      return 0;
   }

private:
   Quantity<X> x;
   Quantity<Y> y;
};



int main()
{

   print(X());
   print(Y());
   print(Z());

   Example::print(X());
   Example::print(Y());
   Example::print(Z());

   XYVector<Quantity> quantity;
   //XYVector doubleXy;
   XYVector<VectorComponent> vectorcomponent;

   return 0;
}
