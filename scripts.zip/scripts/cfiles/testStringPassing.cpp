#include <iostream>
#include <string>

using namespace std;

int someFunc(string myString)
{
    cout << myString << endl;
    return 0;
}

int main()
{
    string someString ("Hello World!");
    someFunc(someString);    

    return 0;
}


