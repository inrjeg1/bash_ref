#include <stdio.h>


typedef struct
{
   int bmw;
   int vw  ;
   int audi ;
}cars;


typedef struct
{
    int a ;
    int b ;
    int c ;
    cars car_list;
}alphabet;


static cars car_list = {0};

int funcB(int *some_car)
{
    *some_car = 9;
 
}


int funcA(alphabet* abc)
{
   printf("car_list.bmw1: %d\n", car_list.bmw);
   /*funcB(&(abc->car_list.audi));*/
    
   funcB(&car_list.bmw);
   printf("car_list.bmw2: %d\n", car_list.bmw);
}


void testB_print_cars(cars *some_cars)
{
   printf("first: %d\n", some_cars->bmw);

}


void testB()
{
   cars some_cars;
   some_cars.bmw = 1;
   some_cars.vw = 2;
   some_cars.audi = 3;
   
   testB_print_cars(&some_cars);
   
}


int main()
{

  alphabet abc;
   abc.a = 1;
   abc.car_list.audi = 12;
 //  funcA(&abc); 
   /*printf("value: %d \n", abc.car_list.audi);*/


/*=========================*/
   
   testB();



   return 0;
}
