#include <iostream>

class A
{
public:
     A()
    {
    }
};

class B
{

public:
    typedef A C;
   
    B(C classA)
    {}

};

int main()
{

    B b(A());

    return 0;
}

