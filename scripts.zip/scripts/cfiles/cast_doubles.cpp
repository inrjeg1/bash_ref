#include <iostream>

using namespace std;

int main()
{
    double d = 0.75;
    double e = 0.1;
    
    int i = static_cast<int>((d - e) * 100);
    
    cout << i << endl;

    return 0;
}
