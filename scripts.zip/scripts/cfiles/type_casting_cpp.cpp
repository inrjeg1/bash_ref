#include <iostream>
#include <vector>

using namespace std;

void fillVector(vector<float>& float_vector)
{
    float_vector.push_back(34.3947);
    float_vector.push_back(7834.89);
}


void vectorStuff()
{
    vector<float> f_vector;
    fillVector(f_vector);
    
    cout << f_vector.size() << endl;;

    //int *d_size = &(f_vector.size());
/*     
    const int a = 1;
    int &b = const_cast<int&>(a);
    cout << " B: " << b <<  endl;
    
 */  //  cout << "size double: " << d_size << endl;

/*      int c = 95;
    double d = static_cast<double>(c);
    
    cout << "D: " << d << endl;
 */
 
 
    int a = 7;
    int b = 2;
    
    double c = 1.0 * a / b;
    double d = a / b;
    double e = static_cast<double>(1.0 * a / b);

    cout << "C: " << c << endl;
    cout << "D: " << d << endl;
    cout << "E: " << e << endl;

    unsigned int x = 7;
    int y = (signed) x;
    cout << "Y: " << y << endl;
    

    unsigned int m = static_cast<unsigned>(2 / -1);
    
    cout << "M: " << m << endl;
}

void boolToInt()
{
    bool alpha = true;
    bool bravo = false;
    int charlie = alpha;
    int delta = bravo;
    
    cout << alpha << endl << bravo << endl;
    cout << charlie << endl << delta << endl;
}


int main()
{
//    vectorStuff();

    boolToInt();

    return 0;
}
