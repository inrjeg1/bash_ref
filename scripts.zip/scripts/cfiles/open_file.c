#include <stdio.h>
#include <stdlib.h>

#define MY_FILE "my_file.txt"


int main()
{
   FILE *file = NULL;

   file = fopen(MY_FILE, "w");



   return 0;
}
