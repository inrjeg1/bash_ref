#include <iostream>
#include <cmath>

using namespace std;

const int SECONDS_IN_MILLI(1000);

int main()
{

    double dTime = 1.23455;

    int intTime = lround(dTime * SECONDS_IN_MILLI);
    
    cout << "TIME " << intTime << endl;

    cout << "DOUBLE? " << dTime * SECONDS_IN_MILLI << endl;

    return 0;
}

