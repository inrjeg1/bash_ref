#include <stdio.h>

typedef struct
{
    int x;
    int y;
    double xy[5];
} Substruct;

typedef struct
{
    int a;
    double d;
    char c;
    float f;
    Substruct s;
} A;

int main()
{
    A a = {0};
    

    printf ("%d\n", a.s.xy[3]);
    return 0;
}


