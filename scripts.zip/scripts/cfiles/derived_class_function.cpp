#include <iostream>

using namespace std;


class A
{
public:
    virtual void printString() = 0;

    void printString(double doubleVar)
    {
        cout << "Double: " << doubleVar << endl;
    }
    
    void printString(int intVar)
    {
        cout << "Int: " << intVar << endl;
    }  
};

class B: public A 
{
public:
    using A::printString;
    
    void printString()
    {
        cout << "Override\n";
    }
};


int main()
{
    B b;
    b.printString(1);

    return 0;
}
