#include <stdio.h>


int main()
{
   float a;
   float b;
   
   float c = a - b;
   float d = b - a;
   
   float e = c - d;
   
   printf("A: %f\nB: %f\nC: %f\nD: %f\nE: %f\n", a, b, c, d, e);  
   
   

   return 0;
}

