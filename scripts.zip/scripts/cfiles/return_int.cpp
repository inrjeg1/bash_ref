#include <iostream>

using namespace std;

int* getInt()
{
    return new int(1);
}

int main()
{
    int* a = getInt();

    cout << *a << endl;

    return 0;
}
