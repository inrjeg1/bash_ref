#include <iostream>

using namespace std;

class MyClass
{
public:
    MyClass& operator=(MyClass other)
    {
        performSwap(*this, other);
        return *this;
    }

    friend void performSwap(MyClass& a, MyClass& b)
    {
        std::swap(a.someInt, b.someInt);
    }

    int someInt;
};


int main()
{
    MyClass a;
    a.someInt = 9;
    
    MyClass b;
    b = a;
    
    cout << "a int: " << a.someInt  << endl; 
    cout << "b int: " << b.someInt  << endl;
    
}


