#include <stdio.h>

typedef enum
{
   alpha,
   bravo,
   charlie,
   delta

} enumA;

int main()
{
    enumA myEnum;
    
    int a = 2;
    
   // printf("%d\n", a);
    myEnum = delta;
    
    printf("%d\n", myEnum);
    
    return 0;
}

