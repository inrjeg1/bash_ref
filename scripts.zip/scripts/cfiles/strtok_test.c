#include <stdio.h>

int main()
{
   char* str = "aap,noot,mies,wim";
   
   
