#include <iostream>
#include <vector>
#include <boost/foreach.hpp>

const unsigned int MAX_SIZE= 20;

class myClass
{
public:
    myClass()
    {
                                    
    }

    static std::vector<int> getArray()
    {
        std::vector<int> a;
        a.push_back(1);
        a.push_back(2);
        a.push_back(3);
        a.push_back(4);
        a.push_back(5);
       
        return a;
    }

};

void performBoostForeach()
{

    BOOST_FOREACH(int i, myClass::getArray())
    {
        std::cout << i << " ";
    }
    std::cout << std::endl;
}


int main()
{    
    performBoostForeach();
    
    return 0;
}
