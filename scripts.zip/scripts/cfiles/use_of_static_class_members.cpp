#include <iostream>

using namespace std;


class ClassA
{
public:

        
    static void setNum(int someNum)
    {
        num = someNum;
    }
        
        
    static bool getStaticBool()
    {
        return staticBool;
    }
    
    static bool increment()
    {
       num++;
    }
    
    void setBool(bool newValue)
    {
        setStaticBool(newValue);
    }

private:

    static int num ;
    static bool staticBool;
    
    static void setStaticBool(bool newValue)
    {
        staticBool = newValue;
    }

};

bool ClassA::staticBool = false;

int ClassA::num = 2;

int main()
{
//    ClassA::setStaticBool(true);
//    bool b = ClassA::getStaticBool();
    
//    cout << b << endl;

    ClassA::setNum(9);

  //  ClassA::increment();
    
    ClassA a;
    a.setBool(true);
    
    cout << a.getStaticBool() << endl;
    
    return 0;
}

