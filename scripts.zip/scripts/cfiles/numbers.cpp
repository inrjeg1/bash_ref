#include <iostream>
#include <stdlib.h>
#include <math.h>

using namespace std;


int main()
{
   static const double epsilon = 1.0e-9;
   
   double a = -0.3;
   double b = -0.2;
   
   cout << fabs(a - b) << endl;;
   /*
   
   if (a < b)
   {
      cout << "TRUE" << endl;
   }
   else
   {
      cout << "FALSE" << endl;
   }
      

   if ((b - a) > epsilon)
   {
      cout << "SMALLER"  << endl;
   }
   else
   {
      cout << "GREATER" << endl;
   }   
   
*/

   return 0;
}

