#include <iostream>

using namespace std;

typedef struct 
{
    int a;
    int b;
} StructAlpha;

int main()
{
    StructAlpha myStruct = {1, 9};
    
    cout << myStruct.b << endl;
    
    return 0;
}
