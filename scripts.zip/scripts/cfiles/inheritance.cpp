#include <iostream>

using namespace std;

class A
{
public:
    A(int v_a_): v_a(v_a_) {}
protected:
    int return_v_a()
    {
        return v_a;
    }
    
    virtual void printSomething() const = 0;
    
int v_a;
};


class B : protected A
{
public:
    B() : A(8) {}
    int get_v_a()
    {
        return return_v_a();
    }
protected:
   virtual void printSomething() const
   {
      cout << "printing\n";
   }
};

class C : protected B
{
public:
    virtual void printSomethingFromB()
    {
        printSomething();
    }
};


int main()
{
    B b;
    cout << b.get_v_a() << endl;

    C().printSomethingFromB();
    return 0;
}

