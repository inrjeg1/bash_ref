#include <stdio.h>


int main()
{
   double start = 0.03999950000000000727151672208492527715862;
   double end = 0.05000000000000000277555756156289135105908;
   
   double bottom = 0.05;
   
   double result = (bottom - start) / (end - start);
   
   printf("result: %3.40f\n", result);
   printf("end-start: %3.40f\n", end -start);
   printf("bottom-start: %3.40f\n", bottom -start);


   if (bottom == end)
   {
      printf("yes\n");
   }
   else
   {
      printf("no\n");
   }

   return 0;
}
