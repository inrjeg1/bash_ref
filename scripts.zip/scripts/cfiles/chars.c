#include <stdio.h>
#include <string.h>


void fillMyChar(char *myChar, int char_size)
{
    strncpy(myChar, "ABCDEFGH", char_size-1);
    myChar[char_size-1] = '\0';
}


int main()
{
    char myChar[20];
    fillMyChar(myChar, sizeof(myChar));

    printf("%s\n", myChar);

    return 0;
}

