#include <stdio.h>

struct 
{
   char *name;
   int age;
} Cow;



int main()
{

   Cow.name = "aldjf";
   Cow.age = 34;
   
   printf("Name: %s\nAge: %d\n", Cow.name, Cow.age);

   return 0;
}
