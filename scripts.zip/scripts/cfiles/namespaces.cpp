#include <iostream>

using namespace std;

namespace A
{

int functionA()
{
   cout << "Within namespace A\n";
}

namespace B
{
   int functionAB()
   {
      cout << "Within namespace A::B\n"; 
   }
}
namespace C
{
   using namespace B;
   
   int functionAC()
   {
      cout << "Calling from namesapce C: ";
      functionAB();
   }

}
}

namespace D
{
   using namespace A::C;
   
   int functionD()
   {
      functionAC();
   }

}

int main()
{
   using namespace D;
   functionD();
   
   return 0;
}
