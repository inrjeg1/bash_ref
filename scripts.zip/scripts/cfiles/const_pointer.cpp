#include <iostream>

using namespace std;

const int global = 7;

void checkConstPointer(const int*& i)
{
    i = &global;
}

int main()
{
    int i = 3;
    const int* p = &i;
   
    checkConstPointer(p);    

    cout << *p << endl;

    return 0;
}
