#include <stdio.h>

typedef struct {

   int some_array[14];
} STRUCT_A;

typedef enum
{
   A_option1,
   A_option2,
   A_option3
} A;


int main()
{
   int size_int = sizeof(int);
   int size_double = sizeof(double);
   int size_uchar = sizeof(char);
   int size_enum = sizeof(A);
   
   printf("INT\t%d\nDOUBLE\t%d\nUCHAR\t%d\nENUM\t%d\n", size_int, size_double, size_uchar, size_enum); 
   
   STRUCT_A *some_struct= {0};
      
   int struct_size = (unsigned int)((char*)(some_struct->some_array) - (char*)some_struct);
   int struct_size2 = sizeof(STRUCT_A);
  
   printf("struct_size\t%d\n", struct_size2);

   return 0;
}
