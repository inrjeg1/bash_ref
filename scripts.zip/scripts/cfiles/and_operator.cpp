#include <iostream>

using namespace std;


int main()
{
    bool a = true;
    bool b = false;
    
    bool c = true;
    bool d = true;
    
    cout << d << endl;
    
    d &= c;
    cout << d << endl;
    
    d &= b;
    cout << d << endl;
    
    d &= a;
    cout << d << endl;
    
    return 0;
}
