#include <iostream>
#include <string.h>

using namespace std;

void printConstChar(const char* c)
{
    cout << c << endl;
}


int main()
{
    string s = "Hello World!";
    const char* c = s.c_str();
    
    printConstChar(s.c_str());
    
    
    return 0;
}
