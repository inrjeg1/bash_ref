#include <iostream>
#include <complex>

using namespace std;


int main()
{
    double a = 4.5;
    double b = 2.6;
    
    cout << norm(a - b) << endl;
    
    return 0;
}
