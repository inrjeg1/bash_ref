#include <iostream>
#include <boost/none.hpp>
#include <boost/optional.hpp>

using namespace std;

void functionB(const boost::optional<int>& IntInput)
{
    if (IntInput)
    {
        cout << "IntInput " << IntInput.get() << endl;
    }
    else
    {
        cout << "None found\n";
    }
}

void functionA(const boost::optional<int>& myInt)
{
    functionB(myInt);    
}

int main()
{
    functionA(boost::none);
    functionA(5);

    return 0;
}
