#include <iostream>
#include <string.h>
#include "boost/unordered_map.hpp"

using namespace std;

typedef boost::unordered_map<string, int> Map;


void getMapElements()
{
    Map map1;
    map1["a"] = 5;
    map1["b"] = 16;
    map1["c"] = 27;

    cout << map1.size() << endl;
    cout << map1.begin()->first << " " << map1.begin()->second << endl;
}

Map returnMap()
{

    Map map1;
    map1["a"] = 5;
    map1["b"] = 16;
    map1["c"] = 27;
    
    return map1;
   
}

Map returnMap2()
{
    Map map1;
    map1["b"] = 18;
    
    return map1;
}

void clearMap()
{
    Map map1 = returnMap();
    
    cout << map1["b"] << endl;
    
    map1.clear();
    
    cout << map1["b"] << endl;
    
    
}

int main()
{
//     Map b = returnMap();
//     cout << b["a"] << " " << b["b"] << " " << b["c"] << " "<< endl;
//     
//     b = returnMap2();
//     cout << b["a"] << " " << b["b"] << " " << b["c"] << " "<< endl;
    
    clearMap();
    
    return 0;
}

