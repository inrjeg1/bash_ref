#include <iostream>
#include <boost/array.hpp>
#include <algorithm>

using namespace std;

int main()
{
    const int arraySize = 10;
    typedef boost::array<bool, arraySize> boolArray;
    
    boolArray b;
    b.assign(false);
    
    b[0] = true;
    
    cout << "size:" << b.size() << endl;;
    cout << b[0] << " " << b[1] << endl; 
    cout << " 5:" << b[5]<< " 6:"  << b[6] << " 7:" << b[7] << " 8:"  << b[8] << " 9:"  << b[9] << endl;


    if (b[0])
    {
        cout << "TRUE" << endl;
    }

    return 0;
}
