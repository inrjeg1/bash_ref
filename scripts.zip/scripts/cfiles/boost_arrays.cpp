#include <iostream>

#include <boost/foreach.hpp>


using namespace std;

int main()
{

    int a[] = {1, 2, 3};
    
    BOOST_FOREACH(int f, a)
    {
        std::cout << f << endl;
    }
    
    

    return 0;
    
}
