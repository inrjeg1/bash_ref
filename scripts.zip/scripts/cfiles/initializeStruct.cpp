#include <iostream>

using namespace std;


struct A
{
    A(int f_)
    : f(f_) {}

    int f;
};

int main()
{
    A a(7);
    
    cout << a.f << endl;

    return 0;   
}
