#include <boost/array.hpp>
#include <iostream>

using namespace std;

typedef struct
{
   double x;
   double y;

} xyvect;


int main()
{
   boost::array<xyvect, 30> bool_array = {0.0};
   
  
   for (int i =0; i <30; i++)
   {
      double a_x = bool_array[i].x;
      double a_y = bool_array[i].y;
   
      cout << "i:\t" << a_x << "\t" << a_y << "\n";
   }
   cout << bool_array.size() << endl;

   return 0;
}


