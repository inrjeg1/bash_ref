#!/bin/bash
set -e

cadenv -r 2.7_32 python
cadenv -r 1.2.3 behave

# TEMPORATY HACK TO GET 32bit PYTHON
export PATH=/cadappl/python/2.7_32/python/bin:$PATH

echo ""
echo "Installing stubs..."
echo ""

python link_stubs.py

echo ""
echo "Running behave..."
echo ""

export LD_LIBRARY_PATH=stubs/:../../../ext/lib/bld_x86lnx/:$LD_LIBRARY_PATH

../bld_x86lnx/size_getter > sizes.txt
../bld_x86lnx/size_getter_va > sizes-va.txt

python tests.py "$@"

rm sizes.txt
rm sizes-va.txt
