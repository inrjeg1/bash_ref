#!/bin/bash


# Python path should link to so's

# path waar python zoekt naar modules
# From tst:
export PYTHONPATH=`readlink -f bld_x86lnx/`:$PYTHONPATH

cd bld_x86lnx/
ln -sf WCSToWSCSConverter.cpp.so WCSToWSCSConverter.so
readlink -f WCSToWSCSConverter.so

cd /boa_prd/ptacken/lil-development/KVLIWC/com/int/tst
# for Fakes
export LD_LIBRARY_PATH=/boa_prd/ptacken/lil-development/build/xlib_x86lnx-global:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH=`readlink -f ../lib/bld_x86lnx/`:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH=`readlink -f bld_x86lnx/`:$LD_LIBRARY_PATH

# boost python
export LD_LIBRARY_PATH=~skersten/lib:$LD_LIBRARY_PATH


python call_convert_wcs_to_wscs.py
