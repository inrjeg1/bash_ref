#!/bin/csh


set project_path = "/boa_prd/ptacken/d/d/d/lil-1/"

set component_path = `echo $argv | sed 's/ /\//g'`

#cd "$project_path/$component_path"

(echo "$project_path/$component_path")
