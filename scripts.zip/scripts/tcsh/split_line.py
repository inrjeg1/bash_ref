#!/usr/bin/env python

sentence = "one.two.three.four"

s1 = sentence.split('.')

for word in s1:
   print word
 
from ctypes import Structure, c_int, c_double
import math

class KMMAxLOG_seq_info_scans_t(Structure):
   _fields_ = [('expected', c_int),
               ('queued', c_int),
               ('retrieved', c_int),
               ('stored', c_int),
               ('cleaned', c_int),
               ('filler0', c_int)]
   

class KMMAxLOG_seq_info_cowa_t(Structure):
   _fields_ = [('scans', KMMAxLOG_seq_info_scans_t),
               ('modeled', c_int),
               ('filler0', c_int)]


cowa_info = KMMAxLOG_seq_info_cowa_t()
cowa_info.scans.cleaned = 4



cowa_info = (getattr(cowa_info, 'scans'))

cowa_info = (getattr(cowa_info, 'stored'))

print cowa_info

